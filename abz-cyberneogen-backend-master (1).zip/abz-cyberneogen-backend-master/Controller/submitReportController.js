import { report } from "process";
import Report from "../Model/submitReport.js";
import { uploadFileToCloudinary,deleteFileFromCloudinary } from "../config/cloudinary.js";
import fs from "fs";

export const addReport = async (req, res) => {
  try {
    const { program, reportTitle, vulnerabilityType, affected_asset, cvss_score,
      similar_cve_reference, severity, vulnerability_details, reproduction_steps,
      import_explanation, mitigation_recommendation, private_nate_to_cyberveo,
      additional_information } = req.body;

    const report = new Report({
      program, reportTitle, vulnerabilityType, affected_asset,
      cvss_score, similar_cve_reference, severity,
      vulnerability_details, reproduction_steps,
      import_explanation, mitigation_recommendation,
      private_nate_to_cyberveo,
      additional_information: {
        tags_lable: additional_information?.tags_lable,
        reference_link: additional_information?.reference_link,
      },
      status: 'New', // Default status
    });

    if (req.file) {
      const uploadResults = await uploadFileToCloudinary(req.file.path, "Reports");
      report.file = uploadResults[0].secure_url;
      report.logoPublicId = uploadResults[0].public_id;
      fs.unlinkSync(req.file.path);
    }

    const saved = await report.save();
    res.status(200).json({ success: true, message: "Report created successfully", data: saved });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
};


export const getAllreport = async(req,res)=>{
  try {
    const report = await Report.find()
    if(!report){
      res.status(404).json({
        success:false,
        message:"reports Not Found"
      })}
      res.status(200).json({success:true,message:"Get All Reports",data:report})
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
}

export const getReportById = async(req,res)=>{
  try {
    const {_id}=req.params
    const report = await Report.findById(_id)
    if(!report){
      res.status(404).json({
        success:false,
        message:"Report Not Found"
      })
    }
    res.status(200).json({
      success:true,
      data:report
    })
  } catch (error) {
    console.log(error);
    res.status(400).json({ success: false, error: error.message });
  }
}


export const updateReport = async (req, res) => {
  try {
    const { _id } = req.params;

    const {
      program,
      reportTitle,
      vulnerabilityType,
      affected_asset,
      cvss_score,
      similar_cve_reference,
      severity,
      vulnerability_details,
      reproduction_steps,
      import_explanation,
      mitigation_recommendation,
      private_nate_to_cyberveo,
      additional_information,
    } = req.body;

    const report = await Report.findById(_id);
    if (!report) {
      return res.status(404).json({ success: false, error: "Report not found" });
    }

    // Update basic fields if provided
    report.program = program || report.program;
    report.reportTitle = reportTitle || report.reportTitle;
    report.vulnerabilityType = vulnerabilityType || report.vulnerabilityType;
    report.affected_asset = affected_asset || report.affected_asset;
    report.cvss_score = cvss_score || report.cvss_score;
    report.similar_cve_reference = similar_cve_reference || report.similar_cve_reference;
    report.severity = severity || report.severity;
    report.vulnerability_details = vulnerability_details || report.vulnerability_details;
    report.reproduction_steps = reproduction_steps || report.reproduction_steps;
    report.import_explanation = import_explanation || report.import_explanation;
    report.mitigation_recommendation = mitigation_recommendation || report.mitigation_recommendation;
    report.private_nate_to_cyberveo = private_nate_to_cyberveo || report.private_nate_to_cyberveo;

    if (additional_information) {
      report.additional_information = {
        tags_lable: additional_information?.tags_lable || report.additional_information?.tags_lable,
        reference_link: additional_information?.reference_link || report.additional_information?.reference_link,
      };
    }

    if (req.file) {
      if (report.logoPublicId) {
        await deleteFileFromCloudinary(report.logoPublicId);
      }
      const uploadResults = await uploadFileToCloudinary(req.file.path, "Reports");
      report.file = uploadResults[0].secure_url;
      report.logoPublicId = uploadResults[0].public_id;

      fs.unlinkSync(req.file.path);
    }
    const updated = await report.save();
    res.status(200).json({
      success: true,
      message: "Report updated successfully",
      data: updated,
    });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
};

export const deleteReport = async(req,res)=>{
  try {
    const {_id}=req.params;
    const deletereport = await Report.findById(_id);
    if(!deletereport){
      res.status(404).json({
        success:false,
        message:"Report Not Found"
      })
    }
    if (deletereport.logoPublicId) {
          await deleteFileFromCloudinary(deletereport.logoPublicId);
        }
        await deletereport.deleteOne();
    res.status(200).json({
      success:true,
      message:"Delete Report Successfully",
      data:deletereport
    })
  } catch (error) {
    console.log(error);
    res.status(400).json({ success: false, error: error.message });
  }
}