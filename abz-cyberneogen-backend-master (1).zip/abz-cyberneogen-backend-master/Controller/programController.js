import Company from '../Model/company.js';
import { Program } from '../Model/program.js'
import { User } from '../Model/user.js';
import {uploadFileToCloudinary,deleteFileFromCloudinary} from '../config/cloudinary.js'


export const createProgram = async (req, res) => {
  try {
    const { name, company, description, endDate, startDate } = req.body;
    const checkCompany = await User.findById({_id:company})
    if(!checkCompany){
      res.status(404).json({
        success:false,
        message:"Company Not found"
      })
    }

    let logoUrl = "";
    let logoPublicId = "";
   
    const program = new Program({
      name,
      company,
      description,
      startDate,
      endDate,
      logoUrl,
      logoPublicId,
      status:'active'
    })
     if (req.file) {
      const uploadResult = await uploadFileToCloudinary(req.file.path, "Programs");
      program.logoUrl = uploadResult[0].secure_url;
      program.logoPublicId = uploadResult[0].public_id;
    }
    const saved = await program.save();
    res.status(200).json({
      success: true,
      message: "Program created successfully",
      data: saved,
    });
  } catch (error) {
    console.error("Program creation error:", error);
    res.status(400).json({ success: false, error: error.message });
  }
};

export const getPrograms = async (req, res) => {
  try {

    const total = await Program.countDocuments({ status: "active" });

    const programs = await Program.find({status:"active"})
      .populate("company", "name email logoUrl")

    res.status(200).json({
      success: true,
      total,
      data: programs,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};




export const getProgramById = async (req, res) => {
    try {
        const program = await Program.findById(req.params._id).populate("company");

        if (!program) return res.status(404).json({ error: 'Program not found' });
        return  res.json({
            success: true,
            data: program
        })
      res.status(200).json({success:true,data:program})
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

export const updateProgram = async (req, res) => {
  try {
    const { _id } = req.params;
    const { name, company, description, startDate, endDate,program_type,status } = req.body;

    const program = await Program.findById(_id);
    if (!program) {
      return res.status(404).json({ success: false, message: "Program not found" });
    }

    if (name) program.name = name;
    if (status) program.status = status;
    if(program_type) program.program_type=program_type;
    if (company) program.company = company;
    if (description) program.description = description;
    if (startDate) program.startDate = startDate;
    if (endDate) program.endDate = endDate;

    if (req.file) {
      if (program.logoPublicId) {
        await deleteFileFromCloudinary(program.logoPublicId);
      }
      const uploadResult = await uploadFileToCloudinary(req.file.path, "Programs");
      program.logoUrl = uploadResult[0].secure_url;
      program.logoPublicId = uploadResult[0].public_id;
    }
    const updated = await program.save();
    res.status(200).json({
      success: true,
      message: "Program updated successfully",
      data: updated,
    });
  } catch (error) {
    res.status(400).json({ success: false, error: error.message });
  }
};

export const getAllActiveProgram = async (req, res) => {
  try {
    const activePrograms = await Program.find({ status: "active" });
    const totalActive = await Program.countDocuments({ status: "active" });

    if (!activePrograms || activePrograms.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No active programs found",
        total: 0,
      });
    }

    res.status(200).json({
      success: true,
      message: "Active programs fetched successfully",
      totalActive,
      data: activePrograms,
    });
  } catch (error) {
    res.status(400).json({
      success: false,
      message: error.message,
    });
  }
};

export const deleteProgram = async (req, res) => {
  try {
    const { _id } = req.params;

    const program = await Program.findById(_id);
    if (!program) {
      return res.status(404).json({ success: false, message: "Program not found" });
    }

    if (program.logoPublicId) {
      await deleteFileFromCloudinary(program.logoPublicId);
    }
    await program.deleteOne();

    res.status(200).json({
      success: true,
      message: "Program deleted successfully",
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
};
