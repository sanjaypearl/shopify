import Contact from '../Model/contactUs.js';


export const contactUs = async (req, res) => {
  try {
    const { name, email, subject } = req.body;

    if (!name || !email || !subject) {
      return res.status(400).json({
        success: false,
        message: 'Please provide name, email, and subject',
      });
    }

    const newContact = new Contact({ name, email, subject });
    const saved = await newContact.save();

    res.status(201).json({
      success: true,
      message: 'Your message has been submitted successfully',
      data: saved,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Something went wrong',
      error: error.message,
    });
  }
};


export const getAllContacts = async (req, res) => {
  try {
    const messages = await Contact.find().sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      message: 'All contact messages retrieved successfully',
      data: messages,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve contact messages',
      error: error.message,
    });
  }
};

