import { User } from '../Model/user.js'
import { hashPassword, comparePassword } from '../config/bcrpt.js';
import { generateToken } from '../config/jwt.js';
import Report  from '../Model/submitReport.js';
import { uploadFileToCloudinary, deleteFileFromCloudinary } from "../config/cloudinary.js";
import {getClientIp}  from '../config/getClientIp.js'
import { getLocationFromIp } from "../config/getLocationFromIp.js";
import { Program } from '../Model/program.js';
import { Researcher } from '../Model/researcher.js';
import treasurer from '../Model/treasurer.js';
import  company  from '../Model/company.js';

export const registerUser = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    if (role === "admin") {
      return res.status(403).json({
        success: false,
        message: "Admin registration is not allowed.",
      });
    }
    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: "Please fill all the fields.",
      });
    }
    const existingUser = await User.findOne({ email }).select('-password');
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: "User already exists.",
      });
    }
    const hashedPassword = await hashPassword(password);
    const createdUser = await User.create({
      name,
      email,
      password: hashedPassword,
      role,
    });
    if (role === "researcher") {
      await Researcher.create({
        researcherId: createdUser._id,
        name: createdUser.name,
        email: createdUser.email,
        password: createdUser.password,
        role: createdUser.role
      });
    }
    if (role === "treasurer") {
      await treasurer.create({
        treasurerId: createdUser._id,
        name: createdUser.name,
        email: createdUser.email,
        password: createdUser.password,
        role: createdUser.role
      });
    }
    if (role === "company") {
      await company.create({
        companyId: createdUser._id,
        name: createdUser.name,
        email: createdUser.email,
        password: createdUser.password,
        role: createdUser.role
      });
    }
    res.status(201).json({
      success: true,
      message: `${role.charAt(0).toUpperCase() + role.slice(1)} registered successfully.`,
      data: createdUser,
    });
  } catch (err) {
    console.error("Registration Error:", err);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};




export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and password are required",
      });
    }
    let user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password",
      });
    }

    const isMatch = await comparePassword(password, user.password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: "Invalid email or password",
      });
    }

    const ip = getClientIp(req);
    const userAgent = req.headers["user-agent"];
    const loginTime = new Date();
    const location = await getLocationFromIp(ip);

    user.lastLogin = {
      ip,
      userAgent,
      time: loginTime,
      location,
    };
    await user.save();

    const token = generateToken({ id: user._id});

    res.status(200).json({
      success: true,
      message: `${user.name} login successful`,
      data: {
        ...user._doc,
        userToken: token,
        lastLogin: user.lastLogin,
      },
    });
  } catch (error) {
    console.error("Login Error:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};





export const getAllUsers = async (req, res) => {
  try {
    // Optional: restrict access to admin only
    // if (req.user.role !== 'admin') {
    //   return res.status(403).json({ success: false, message: 'Access denied' });
    // }

    const users = await User.find({ role: { $ne: 'admin' } }).select('-password');

    const totalUser = await User.countDocuments({ role: 'user' });
    const totalTreasurer = await User.countDocuments({ role: 'treasurer' });
    const totalCompany = await User.countDocuments({ role: 'company' });
    const totalResearcher = await User.countDocuments({ role: 'researcher' });
    const total = await User.countDocuments();
  

    res.status(200).json({
      success: true,
      data: {
        users
      },
      totals: {
        totalUser,
        totalTreasurer,
        totalCompany,
        totalResearcher,
        total
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

export const getUserById = async (req, res) => {
  try {
    const userId = req.params.id;
    const user = await User.findById({ _id: userId }).select("-password");
    if (!user) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    res.status(200).json({ success: true, data: user });
  } catch (err) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// export const updateUser = async (req, res) => {
//   try {
//     const { name, email, role } = req.body;
//     const userId = req.params.id;

//     // // Only allow self or admin
//     // if (req.user.role !== 'admin' && req.user._id.toString() !== req.params.id) {
//     //   return res.status(403).json({ success: false, message: 'Access denied' });
//     // }

//     const user = await User.findById({_id:userId});
//     console.log(user)
//     if (!user) return res.status(404).json({ success: false, message: 'User not found' });

//     user.name = name || user.name;
//     user.email = email || user.email;
//     if (role && req.user.role === 'admin') user.role = role;

//     await user.save();
//     res.status(200).json({ success: true, message: 'User updated', data: user });
//   } catch (err) {
//     console.log(err)
//     res.status(500).json({ success: false, message: 'Server error' });
//   }
// };

export const deleteUser = async (req, res) => {
  try {
    const _id = req.params;
    // if (req.user.role !== 'admin') {
    //   return res.status(403).json({ success: false, message: 'Access denied' });
    // }
    const deleted = await User.findByIdAndDelete(_id);
    if (!deleted) return res.status(404).json({ success: false, message: 'User not found' });
    if (deleted.profilePicture && deleted.profilePicture.public_id) {
          await deleteFileFromCloudinary(deleted.profilePicture.public_id);
        }
    res.status(200).json({ success: true, message: 'User deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};

export const changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const userId = req.params.id;
    const user = await User.findById({ _id: userId });

    const isMatch = await comparePassword(currentPassword, user.password);
    if (!isMatch) {
      return res
        .status(401)
        .json({ success: false, message: "Incorrect current password" });
    }

    user.password = await hashPassword(newPassword);
    await user.save();

    res
      .status(200)
      .json({ success: true, message: "Password updated successfully" });
  } catch (err) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};



export const updateUserProfile = async (req, res) => {
  try {
    const { _id } = req.params;
    const { name, email, role, status } = req.body;

    const user = await User.findById(_id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    // Update basic fields
    if (name) user.name = name;
    if (email) user.email = email;
    if (role) user.role = role;
    if (typeof status !== "undefined") user.status = status;

    // Handle logo upload
    if (req.file) {
      const uploadedImage = await uploadFileToCloudinary(req.file, "user_logos");
      user.logoUrl = uploadedImage[0].secure_url;
      user.logoPublicId = uploadedImage[0].public_id;
      try {
        fs.unlinkSync(req.file.path);
      } catch (err) {
        console.error("Failed to delete local file:", err.message);
      }
    }
    const updatedUser = await user.save();
    const companyDoc = await company.findOne({ companyId: _id });
    if (companyDoc) {
      if (name) companyDoc.name = name;
      if (email) companyDoc.email = email;
      if (typeof status !== "undefined") companyDoc.status = status;
      if (req.file) {
        companyDoc.logoUrl = user.logoUrl;
        companyDoc.logoPublicId = user.logoPublicId;
      }
      await companyDoc.save();
    }
    const researcherDoc = await Researcher.findOne({ researcherId: _id });
    if (researcherDoc) {
      if (name) researcherDoc.name = name;
      if (email) researcherDoc.email = email;
      if (typeof status !== "undefined") researcherDoc.status = status;
      if (req.file) {
        researcherDoc.logoUrl = user.logoUrl;
        researcherDoc.logoPublicId = user.logoPublicId;
      }
      await researcherDoc.save();
    }

    const treasurerDoc = await treasurer.findOne({ treasurerId: _id });
    if (treasurerDoc) {
      if (name) treasurerDoc.name = name;
      if (email) treasurerDoc.email = email;
      if (typeof status !== "undefined") treasurerDoc.status = status;
      if (req.file) {
        treasurerDoc.logoUrl = user.logoUrl;
        treasurerDoc.logoPublicId = user.logoPublicId;
      }
      await treasurerDoc.save();
    }

    return res.status(200).json({
      success: true,
      message: "User and associated profile(s) updated successfully",
      data: updatedUser,
    });
  } catch (err) {
    console.error("Error updating user profile:", err.message);
    return res.status(500).json({
      success: false,
      message: "Server error",
      error: err.message,
    });
  }
};




// getAll company researcher and program........

export const getAllControlOnAdminSide = async (req, res) => {
  try {
    const companies = await User.find({ role: "company" }).select("-password");
    const researchers = await User.find({ role: "researcher" }).select("-password");
    const treasurer = await User.find({ role: "treasurer" }).select("-password");

    res.status(200).json({
      success: true,
      message: "Data fetched successfully",
      data: {
        companies,
        researchers,
        treasurer
      },
    });
  } catch (error) {
    console.error("Error in getAllControlOnAdminSide:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch data",
      error: error.message,
    });
  }
};


export const getAllCompanies = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;
    
    
    const companies = await User.find({ role: 'company' })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .select('-password')
      .lean()
      .exec();
    
    if (!companies || companies.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'No companies found',
      });
    }
    const totalCompany = await User.countDocuments({ role: 'company' }).exec();
    
    return res.status(200).json({
      success: true,
      message: 'Companies fetched successfully',
      data: companies,
      totalCompany,
      page,
      limit,
    });
  } catch (error) {
    console.error('Error fetching companies:', error);
    return res.status(500).json({
      success: false,
      message: error.message || 'Internal server error',
    });
  }
};


export const getTotalCounts = async(req,res)=>{
  try {
    const totalUsers = await User.countDocuments({ role: 'user' });
    const totalCompanies = await User.countDocuments({ role: 'company' });
    const totalResearchers = await User.countDocuments({ role: 'researcher' ,status: 'active'});
    const totalTreasurers = await User.countDocuments({ role: 'treasurer' });
    const totalReports = await Report.countDocuments();
    const totalPrograms = await Program.countDocuments({ status: 'active' });

    res.status(200).json({
      success: true,
      data: {
        totalUsers,
        totalCompanies,
        totalResearchers,
        totalTreasurers,
        totalReports,
        totalPrograms
      }
    });
  } catch (error) {
    console.error("Error fetching total counts:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message
    });
  }
}

