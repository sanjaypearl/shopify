export const getClientIp = (req) => {
  const forwarded = req.headers["x-forwarded-for"];
  if (forwarded) {
    const ipList = forwarded.split(",");
    return ipList[0].trim();
  }

  return req.socket?.remoteAddress || req.connection?.remoteAddress;
};
