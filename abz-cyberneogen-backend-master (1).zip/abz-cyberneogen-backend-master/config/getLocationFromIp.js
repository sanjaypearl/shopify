import axios from "axios";

export const getLocationFromIp = async (ip) => {
  try {
    console.log("Fetching location for IP:", ip); // Debug

    const response = await axios.get(`https://ipapi.co/${ip}/json`);
    console.log("API Response:", response.data); // Debug

    const { city, region, country_name } = response.data;
    return `${city || "Unknown"}, ${region || "Unknown"}, ${country_name || "Unknown"}`;
  } catch (err) {
    console.log("Location fetch error:", err.message);
    return "Unknown";
  }
};
