import { Router } from 'express';
import {
  getCompanyById,
  updateCompany,
  deleteCompany,
  getAllCompanies
} from '../Controller/companyController.js';
import { upload } from '../middleware/multer.js';
import { protect, adminOnly } from '../middleware/isAdmin.js.js';

const router = Router();

// // Create

// Read
router.get('/getAllCompanies',getAllCompanies);
// router.get('/getAllCompanies',protect,adminOnly, getAllCompanies);
router.get('/getCompanyById/:_id', getCompanyById);

// Update
router.put('/updateCompany/:_id',upload.single('logoUrl'), updateCompany);
// router.put('/updateCompany/:id',protect,adminOnly, updateCompany);

// Delete
router.delete('/deleteCompany/:_id',deleteCompany);
// router.delete('/deleteCompany/:id',protect,adminOnly, deleteCompany);

export default router;
