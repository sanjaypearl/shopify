import { Router } from "express";
import { upload } from "../middleware/multer.js";
import { addReport ,getAllreport,getReportById,updateReport,deleteReport} from "../Controller/submitReportController.js";

const router = Router();
router.post("/submitreport", upload.single("file"), addReport);
router.put("/updateReport/:_id", upload.single("file"), updateReport);
router.get('/getAllReport',getAllreport)
router.get('/getReportById/:_id',getReportById)
router.delete('/deleteReport/:_id',deleteReport)

export default router;
