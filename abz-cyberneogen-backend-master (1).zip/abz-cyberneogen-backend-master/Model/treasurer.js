import mongoose from 'mongoose';

const treasurerSchema = new mongoose.Schema({
  treasurerId:{
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  name: {
    type: String,
    trim: true,
  },

  email: {
    type: String,
    unique: true,
    lowercase: true,
  },

  password: {
    type: String,
    minlength: 6,
  },

  phone: {
    type: String,
  },

  role: {
    type: String,
    default: 'treasurer',
    enum: ['treasurer'],
  },

  logoUrl: {
    type: String,
  },

  status: {
    type:String,
    enum:['active','inactive'],
    default: 'active',
  },

  verifiedByAdmin: {
    type: Boolean,
    default: false,
  },

}, { timestamps: true });


const Treasurer = mongoose.model('Treasurer', treasurerSchema);
export default Treasurer;
