// models/Program.js
import mongoose from 'mongoose';

const programSchema = new mongoose.Schema(
  {
    name: {
      type: String,
    },
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },

    reportsReceived: {
      type: Number,
      default: 0,
    },
    // reportsChange: {
    //   type: String,
    // },
    description: { type: String },
    researchersCount: { type: Number, default: 0 },
    submissions: { type: Number, default: 0 },
    verifiedVulnerabilities: { type: Number, default: 0 },
    logoUrl: { type: String },
    program_type: {
      type: Boolean,
      default: false
    },
    status:{
      type:String,
      enum:['active','inactive','paused'],
      default:'active'
    },
    startDate: {
      type: Date,
      required: true,
    },
    endDate: {
      type: Date,
      required: true,
    },
    logoPublicId: {
      type: String,
    },
  },
  { timestamps: true }
)

export const Program = mongoose.model('Program', programSchema);
