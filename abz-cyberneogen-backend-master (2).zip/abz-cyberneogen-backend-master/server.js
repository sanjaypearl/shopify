import express from 'express';
import dotenv from "dotenv";
import { connectDB } from './Database/Database.js';
import apiRoutes from './Route/index.js';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url'; // ✅ for __dirname in ES6

dotenv.config();
const app = express();
connectDB();



app.use(cors({
  origin: process.env.FRONTEND_URL, // Allow all origins, adjust as needed
  methods: ['GET', 'POST', 'PUT', 'DELETE'], // Allowed HTTP methods
  allowedHeaders: ['Content-Type', 'Authorization'], // Allowed headers
}));
app.use(express.json()); // ⬅️ this parses JSON bodies
app.use(express.urlencoded({ extended: true }));

// ✅ Get __dirname for ES6
// const __filename = fileURLToPath(import.meta.url);
// const __dirname = path.dirname(__filename);

// // ✅ Serve static files correctly
// console.log("first",(path.join(__dirname, 'uploads')))

// app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/uploads', express.static('uploads'));


// API routes
app.use('/api', apiRoutes);

app.set("trust proxy", true);


const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log('Server is running on port ' + PORT);
});
