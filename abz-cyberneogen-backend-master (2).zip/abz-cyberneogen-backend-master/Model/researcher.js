import mongoose from 'mongoose';

const researcherSchema = new mongoose.Schema(
  {
    researcherId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    name: {
      type: String,
    },
    email: {
      type: String,
      unique: true,
      trim: true,
      lowercase: true,
      match: [
        /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
        'Please enter a valid email address',
      ],
    },
    password: {
      type: String,
      minlength: 6,
    },
    logoUrl: {
      type: String,
    },
    reportsSubmitted: { type: Number, default: 0 },
    reportsAccepted: { type: Number, default: 0 },
    acceptanceRate: { type: Number, default: 0 },
    role: {
      type: String,
      enum: ['researcher'],
      default: 'researcher',
    },
   
    specializations: [String], // e.g. Web Apps, APIs
    skills: [String],          // e.g. Python, Burp Suite, JavaScript
    topOwasp: [String],        // e.g. OWASP Top 10

    certifications: [
      {
        name: String,
        issuer: String,
        year: String,
      }
    ],
    status: {
      type: String,
      enum: ['active', 'inactive'],
      default: 'active',
    },

    // Payment Information
    paymentMethod: {
      type: String, // e.g. PayPal
    },
    paypalEmail: {
      type: String,
      lowercase: true,
    },
    taxInfo: {
      type: String, // e.g. "W9 (US Taxpayer)"
    },
    taxStatus: {
      type: String, // e.g. "Submitted and verified"
    }
  },
  {
    timestamps: true,
  }
);
researcherSchema.methods.updateAcceptanceRate = function () {
  this.acceptanceRate =
    this.reportsSubmitted > 0
      ? Math.round((this.reportsAccepted / this.reportsSubmitted) * 100)
      : 0;
};

export const Researcher = mongoose.model('Researcher', researcherSchema);
