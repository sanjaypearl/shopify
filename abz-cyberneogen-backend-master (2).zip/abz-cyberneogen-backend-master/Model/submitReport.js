import mongoose from "mongoose";

const AdditionalInformationSchema = new mongoose.Schema({
  tags_lable: String,
  reference_link: String,
});

const ReportSchema = new mongoose.Schema({
  submittedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  program: String,
  reportTitle: { type: String, required: true },
  vulnerabilityType: { type: String, required: true },
  affected_asset: { type: String, required: true },
  cvss_score: String,
  similar_cve_reference: String,
  severity: { type: String, enum: ["low", "medium", "high", "critical"], required: true },
  vulnerability_details: { type: String, required: true },
  reproduction_steps: { type: String, required: true },
  import_explanation: String,
  mitigation_recommendation: String,
  private_nate_to_cyberveo: String,
  additional_information: AdditionalInformationSchema,
  logoPublicId: String,
  status:{type:String, enum: ["New", "In Review", "Received", "Validated", "Rejected"], default:'New'},
  file: String,
}, { timestamps: true });

export default mongoose.model("Report", ReportSchema);
