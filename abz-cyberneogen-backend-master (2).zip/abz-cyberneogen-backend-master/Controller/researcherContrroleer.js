import { User } from "../Model/user.js";
import { Researcher } from "../Model/researcher.js";
import { uploadFileToCloudinary, deleteFileFromCloudinary } from "../config/cloudinary.js";
import fs from 'fs';


export const updateResearcher = async (req, res) => {
  try {
    const { _id } = req.params;

    const {
      name,
      username,
      bio,
      phone,
      country,
      timeZone,
      language,
      specializations,
      skills,
      topOwasp,
      paymentMethod,
      paypalEmail,
      taxInfo,
      status,
      certifications
    } = req.body;

    let researcher = await Researcher.findOne({researcherId:_id});

    if (!researcher) {
      return res.status(404).json({
        success: false,
        message: "Researcher Profile Not Found"
      });
    }

    researcher.username = username || researcher.username;
    researcher.name = name || researcher.name;
    researcher.bio = bio || researcher.bio;
    researcher.phone = phone || researcher.phone;
    researcher.country = country || researcher.country;
    researcher.timeZone = timeZone || researcher.timeZone;
    researcher.language = language || researcher.language;
    researcher.specializations = specializations || researcher.specializations;
    researcher.skills = skills || researcher.skills;
    researcher.topOwasp = topOwasp || researcher.topOwasp;
    researcher.paymentMethod = paymentMethod || researcher.paymentMethod;
    researcher.paypalEmail = paypalEmail || researcher.paypalEmail;
    researcher.taxInfo = taxInfo || researcher.taxInfo;
    researcher.status = status || researcher.status;
    researcher.certifications = certifications || researcher.certifications;


    if (req.file) {
      const uploadResult = await uploadFileToCloudinary(req.file, "researcher_logos");
      researcher.logoUrl = uploadResult[0].secure_url;
      researcher.logoPublicId = uploadResult[0].public_id;

      fs.unlinkSync(req.file.path);
    }

    await researcher.save();

    res.status(200).json({
      success: true,
      message: "Researcher profile updated successfully",
      data: researcher,
    });

  } catch (err) {
    console.error("Update error:", err);
    res.status(500).json({
      success: false,
      message: "Internal server error",
      error: err.message
    });
  }
};



export const deleteResearch = async (req, res) => {
  try {
    const { _id } = req.params;

    const deletedUser = await User.findByIdAndDelete(_id);

    if (!deletedUser) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    const deletedResearcher = await Researcher.findOneAndDelete({ researcherId: _id });

    if (
      deletedUser.profilePicture &&
      deletedUser.profilePicture.public_id
    ) {
      await deleteFileFromCloudinary(deletedUser.profilePicture.public_id);
    }

    res.status(200).json({
      success: true,
      message: 'Researcher and associated profile deleted successfully',
      data: {
        userId: deletedUser._id,
        researcherDeleted: !!deletedResearcher,
      },
    });
  } catch (error) {
    console.error('Delete Researcher Error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
};

export const getAllResearcher = async(req,res)=>{
  try {
    const getResearch = await Researcher.find().select('-password')
    if(!getResearch){
      res.status(404).json({
        success:false,
        message:"Researcher Not Found"
      })
    }
    res.status(200).json({
      success:true,
      message:"Get All Researcher Successfully",
      data:getResearch
    })
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
}


export const getResearcherById = async (req, res) => {
  try {
    const { _id } = req.params;

    const researcher = await Researcher.findOne({ researcherId: _id }).select('-password');

    if (!researcher) {
      return res.status(404).json({
        success: false,
        message: "Researcher not found"
      });
    }

    res.status(200).json({
      success: true,
      data: researcher
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
}
