import Company from "../Model/company.js";
import { User } from "../Model/user.js";
import { uploadFileToCloudinary, deleteFileFromCloudinary } from "../config/cloudinary.js";
import fs from 'fs';




export const updateCompany = async (req, res) => {
  try {
    const {
      name,
      email,
      website,
      industry,
      location,
      foundedYear,
      employeeSize,
      status,
      companyDescription,
      role
    } = req.body;

    const { _id } = req.params;

    let companySettings = await Company.findOne({ companyId: _id });
    if (!companySettings) {
      return res.status(404).json({
        success: false,
        message: 'Company profile not found',
      });
    }

    companySettings.name = name || companySettings.name;
    companySettings.email = email || companySettings.email;
    companySettings.status = status || companySettings.status;
    companySettings.website = website || companySettings.website;
    companySettings.industry = industry || companySettings.industry;
    companySettings.location = location || companySettings.location;
    companySettings.foundedYear = foundedYear || companySettings.foundedYear;
    companySettings.employeeSize = employeeSize || companySettings.employeeSize;
    companySettings.companyDescription = companyDescription || companySettings.companyDescription;

  
    if (req.file) {
      const uploadResult = await uploadFileToCloudinary(req.file, "company_logos");
      companySettings.logoUrl = uploadResult[0].secure_url;
      companySettings.logoPublicId = uploadResult[0].public_id;

      fs.unlinkSync(req.file.path);
    }
    await companySettings.save();
    const user = await User.findById({_id: companySettings.companyId});
    console.log("User found:", user);
    if (user) {
      user.name = name || user.name;
      user.email = email || user.email;
      user.status = status || user.status;
      if (role) user.role = role;
      await user.save();
    }

    res.status(200).json({
      success: true,
      message: 'Company profile updated successfully',
      data: companySettings
    });

  } catch (err) {
    console.error('Update company error:', err);
    res.status(500).json({
      success: false,
      message: 'Internal Server Error',
      error: err.message
    });
  }
};

export const getAllCompanies = async (req, res) => {
  try {
    const companies = await Company.find().select('-password');
    const totalCompany = await Company.countDocuments();
    if (!companies || companies.length === 0) {
      return res.status(404).json({ success: false, message: 'No companies found' })
    }
    res.status(200).json({ success: true, message: "Companies Get Successfully", data: companies, totalCompany });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};


export const getCompanyById = async (req, res) => {
  try {
    const company = await Company.findOne({ companyId: req.params._id }).select('-password');
    if (!company) {
      return res.status(404).json({ success: false, message: 'Company not found' });
    }
    res.status(200).json({ success: true, data: company });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};


export const deleteCompany = async (req, res) => {
  try {
    const { _id } = req.params;

    const deletedCompany = await Company.findByIdAndDelete(_id);
    if (!deletedCompany) {
      return res.status(404).json({ success: false, message: 'Company not found' });
    }
    const deletedUser = await User.findByIdAndDelete(deletedCompany.companyId);
    if (deletedCompany.logoPublicId) {
      await deleteFileFromCloudinary(deletedCompany.logoPublicId);
    }
    res.status(200).json({
      success: true,
      message: 'Company and associated user deleted successfully',
      data: {
        companyId: deletedCompany._id,
        userId: deletedUser ? deletedUser._id : null,
      },
    });
  } catch (error) {
    console.error('Delete Company Error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
};




