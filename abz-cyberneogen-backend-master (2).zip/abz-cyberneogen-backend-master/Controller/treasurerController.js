import Treasurer from "../Model/treasurer.js";
import { hashPassword } from '../config/bcrpt.js';
import { uploadFileToCloudinary, deleteFileFromCloudinary } from "../config/cloudinary.js";


export const getAllTreasurer = async (req, res) => {
    try {
        const treData = await Treasurer.find().select('-password')
        if (!treData) {
            res.status(404).json({
                success: false,
                message: "Treasurer Not Found!"
            })
        }
        res.status(200).json({
            success: true,
            message: "Get All Treasurer Successfully!",
            data: treData
        })

    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Internal Server Error',
            data: null
        })

    }
}

export const TreaDataById = async (req, res) => {
    try {
        const { _id } = req.params
        const treData = await Treasurer.findById({treasurerId:_id}).select('-password')
        if (!treData) {
            res.status(404).json({
                success: false,
                message: "Treasurer Is Not Found!"
            })
        }
        res.status(200).json({
            success: true,
            message: "Get Treasurer ById Successfully!",
            data: treData
        })

    } catch (error) {
        res.status(500).json({
            success: false,
            message: "Internal Server Error",
            data: null
        })
    }
}

export const updateTreasurer = async (req, res) => {
    try {
        const { _id } = req.params;
        const { name, phone, email, role, verifiedByAdmin, status } = req.body;
        const existTre = await Treasurer.findOne({treasurerId:_id})
        if (!existTre) {
            res.status(404).json({
                success: false,
                message: "Treasurer Not Found!..."
            })
        }
        if (name) existTre.name = name;
        if (email) existTre.email = email;
        if (phone) existTre.phone = phone;
        if (role) existTre.role = role;
        if (verifiedByAdmin) existTre.verifiedByAdmin = verifiedByAdmin;
        if (status) existTre.status = status;
        if (req.file) {
            const uploadedImage = await uploadFileToCloudinary(req.file, 'treasurerImg')
            existTre.logoUrl = uploadedImage[0].secure_url;
            existTre.logoPublicId = uploadedImage[0].public_id;
        }
        await existTre.save()
        res.status(200).json({
            success:true,
            message:"Teasurer Is Updated Successfully!",
            data:existTre
        })
    } catch (error) {
        console.log(error);
        res.status(500).json({
            success: false,
            message: "Internal Server Error",
            data: null
        })
    }
}

export const treDelete = async (req, res) => {
  try {
    const { _id } = req.params;

    const deletedTreasurer = await Treasurer.findByIdAndDelete({treasurerId:_id});

    if (!deletedTreasurer) {
      return res.status(404).json({
        success: false,
        message: "Treasurer not found",
      });
    }

    if (deletedTreasurer.profilePicture && deletedTreasurer.profilePicture.public_id) {
      await deleteFileFromCloudinary(deletedTreasurer.profilePicture.public_id);
    }

    if (deletedTreasurer.userId) {
      const deletedUser = await User.findByIdAndDelete(deletedTreasurer._id);
        if (!deletedUser) {
            return res.status(404).json({
            success: false,
            message: "User not found",
            });
        }
      
      if (deletedUser?.profilePicture?.public_id) {
        await deleteFileFromCloudinary(deletedUser.profilePicture.public_id);
      }
    }

    res.status(200).json({
      success: true,
      message: "Treasurer and associated user deleted successfully",
      data: deletedTreasurer,
    });

  } catch (error) {
    console.error("Error deleting treasurer:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};