import express from 'express'
import * as treasurerController from '../Controller/treasurerController.js'
import {upload} from '../middleware/multer.js'

const router = express.Router();

router.get('/getAllTreasurer',treasurerController.getAllTreasurer)
router.get('/TreaDataById/:_id',treasurerController.TreaDataById)
router.put('/updateTreasurer/:_id',upload.single('logoUrl'),treasurerController.updateTreasurer)
router.delete('/treDelete/:_id',treasurerController.treDelete)

export default router;