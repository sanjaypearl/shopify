import express from 'express';
import userRoutes from './user.js';
import userKYCRoute from './userKYC.js';
import Program  from '../Route/program.js';
import contactUs from './contactUs.js'
import submitReport from './submitReport.js'
import company from './company.js'
import researcher from './researcher.js';
import treasurer from './treasurer.js';




const router = express.Router();

router.use('/user', userRoutes);
router.use('/userKYC', userKYCRoute);
router.use('/program', Program);
router.use('/contact', contactUs);
router.use('/report', submitReport);
router.use('/company', company);
router.use('/researcher', researcher);
router.use('/treasurer',treasurer)


export default router;
