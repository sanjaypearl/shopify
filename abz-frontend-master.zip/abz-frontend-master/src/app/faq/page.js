import Faq from "@/components/FaqComponents/Faq";

const page = () => {
  return (
    <div>
      <Faq />
    </div>
  );
};

export default page;
