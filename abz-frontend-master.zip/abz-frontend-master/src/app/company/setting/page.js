import CompanySetting from "@/components/Company/Setting/CompanySetting";
import React from "react";

const page = () => {
  return (
    <div>
      <CompanySetting />
    </div>
  );
};

export default page;
