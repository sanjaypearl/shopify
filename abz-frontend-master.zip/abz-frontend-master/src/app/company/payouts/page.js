import CompanyPayout from "@/components/Company/Payouts/CompanyPayout";
import React from "react";

const page = () => {
  return (
    <div>
      <CompanyPayout />
    </div>
  );
};

export default page;
