// app/page.js
export default function HomePage() {
  return (
    <div>
      <h1 className="text-3xl font-bold w-full">Welcome to the assets Pagee</h1>
      <p>This page uses the global layout.</p>
    </div>
  );
}
