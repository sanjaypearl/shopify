import Researchers from "@/components/Company/Researchers/Researchers";
import React from "react";

const page = () => {
  return (
    <div>
      <Researchers />
    </div>
  );
};

export default page;
