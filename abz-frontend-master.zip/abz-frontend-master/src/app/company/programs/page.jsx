import ProgramsList from "@/components/Company/Programs/ProgramsList";
import React from "react";

const page = () => {
  return (
    <div>
      <ProgramsList />
    </div>
  );
};

export default page;
