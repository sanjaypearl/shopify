import FeaturedBlogs from "@/components/Blog/FeaturedBlogs";

const page = () => {
  return (
    <div>
      <FeaturedBlogs />
    </div>
  );
};

export default page;
