import ResearcherProgram from "@/components/Researcher/ResearcherProgram";
import React from "react";

const page = () => {
  return (
    <div>
      <ResearcherProgram />
    </div>
  );
};

export default page;
