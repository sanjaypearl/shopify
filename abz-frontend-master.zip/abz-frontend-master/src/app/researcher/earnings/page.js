import ResearcherEarningsDashboard from "@/components/Researcher/ResearcherEarningsDashboard";
import React from "react";

const page = () => {
  return (
    <div>
      <ResearcherEarningsDashboard />
    </div>
  );
};

export default page;
