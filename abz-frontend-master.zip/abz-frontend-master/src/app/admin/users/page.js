import ManageUser from "@/components/AdminComponents/ManageUsers/ManageUser";

const page = () => {
  return (
    <div>
      <ManageUser />
    </div>
  );
};

export default page;
