
"use client";

// import ManageReport from "@/components/AdminComponents/Report/ManageReport";
import ReportDetail from "@/components/AdminComponents/Report/ReportDetail";
import React from "react";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Page = () => {
  return (
    <div>

      <ToastContainer position="bottom-left" autoClose={3000} />

      <ReportDetail />
      {/* <ManageReport /> */}
    </div>
  );
};

export default Page;
