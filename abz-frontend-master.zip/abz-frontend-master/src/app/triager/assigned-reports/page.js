import AssignedReports from "@/components/TriagerComponents/AssignedReports";
import React from "react";

const page = () => {
  return (
    <div>
      <AssignedReports />
    </div>
  );
};

export default page;
