import TriagerDashboard from "@/components/TriagerComponents/TriagerDashboard";
import React from "react";

const page = () => {
  return (
    <div>
      <TriagerDashboard />
    </div>
  );
};

export default page;
