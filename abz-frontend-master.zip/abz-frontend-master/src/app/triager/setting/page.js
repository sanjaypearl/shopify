import React from "react";
import TriageSettings from "../../../components/TriagerComponents/TriageSettings";

const page = () => {
  return (
    <div>
      <TriageSettings />
    </div>
  );
};

export default page;
