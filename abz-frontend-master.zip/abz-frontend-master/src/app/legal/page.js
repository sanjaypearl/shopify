import TermsOfService from "@/components/LegalComponents/TermsOfService";

const page = () => {
  return (
    <div>
      <TermsOfService />
    </div>
  );
};

export default page;
