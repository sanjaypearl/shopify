import { createSlice } from "@reduxjs/toolkit";
import { fetchResearchers } from "../actions/researcherAction";

const initialState = {
  data: [],
  loading: false,
  error: null,
};

const researcherSlice = createSlice({
  name: "researcher",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchResearchers.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchResearchers.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload || [];
      })
      .addCase(fetchResearchers.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || "Something went wrong";
      });
  },
});

export default researcherSlice.reducer;
