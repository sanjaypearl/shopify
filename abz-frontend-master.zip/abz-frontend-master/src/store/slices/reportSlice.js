// src/store/slices/reportSlice.js
import { createSlice } from "@reduxjs/toolkit";
import { fetchReports, createReport } from "../actions/reportAction";

const initialState = {
  data: [], // list of reports
  loading: false, // fetchReports status
  error: null, // fetchReports error
  createStatus: "idle", // "idle" | "loading" | "succeeded" | "failed"
  createError: null, // createReport error
  lastCreated: null, // last created report payload
};

const reportSlice = createSlice({
  name: "report",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    // fetchReports
    builder
      .addCase(fetchReports.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchReports.fulfilled, (state, action) => {
        state.loading = false;
        state.data = action.payload || [];
      })
      .addCase(fetchReports.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload || "Failed to load reports";
      });

    // createReport
    builder
      .addCase(createReport.pending, (state) => {
        state.createStatus = "loading";
        state.createError = null;
      })
      .addCase(createReport.fulfilled, (state, action) => {
        state.createStatus = "succeeded";
        state.lastCreated = action.payload || null;
        // add created report to front of data list if valid object
        if (action.payload && action.payload._id) {
          state.data = [action.payload, ...(state.data || [])];
        }
      })
      .addCase(createReport.rejected, (state, action) => {
        state.createStatus = "failed";
        state.createError = action.payload || "Failed to submit report";
      });
  },
});

export default reportSlice.reducer;
