// src/store/actions/programAction.js
import { createAsyncThunk } from "@reduxjs/toolkit";
import DataService from "@/services/Axios/axiosInterceptor";

export const fetchPrograms = createAsyncThunk(
  "program/getPrograms",
  async (_, { rejectWithValue }) => {
    try {
      const res = await DataService.getAllActiveProgram();

      return res.data?.data || res.data || [];
    } catch (err) {
      return rejectWithValue(
        err.response?.data?.message || err.message || "Failed to fetch programs"
      );
    }
  }
);
