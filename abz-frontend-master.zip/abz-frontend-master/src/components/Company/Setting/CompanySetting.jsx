"use client";

import { useState, useEffect } from "react";
import DataService from "@/services/Axios/axiosInterceptor";
import { toast } from "react-toastify";

export default function CompanySetting() {
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState({
    name: "",
    email: "",
    role: "",
    status: "",
    industry: "",
    description: "",
    logoUrl: null,
  });

  const [recentActivity, setRecentActivity] = useState([]);

  // Fetch company data
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        setLoading(true);
        const user = JSON.parse(localStorage.getItem("user"));
        const companyId = user?.data?._id;

        if (!companyId) {
          toast.error("No company ID found!");
          return;
        }

        const res = await DataService.getCompanyById(companyId);
        if (res.data?.data) {
          const company = res.data.data;
          setProfile({
            name: company.name || "",
            email: company.email || "",
            role: company.role || "",
            status: company.status || "",
            industry: company.industry || "",
            description: company.description || "",
            logoUrl: company.logoUrl || null,
          });
        }

        // Placeholder activity — replace with API later
        setRecentActivity([
          { id: 1, text: "Company profile updated", date: "2 hours ago" },
          { id: 2, text: "Posted new job: Frontend Developer", date: "1 day ago" },
          { id: 3, text: "5 new applicants for Backend Developer", date: "3 days ago" },
        ]);
      } catch (err) {
        console.error(err);
        toast.error("Failed to load profile");
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, []);

  const handleChange = (field, value) => {
    setProfile((prev) => ({ ...prev, [field]: value }));
  };

  const handleLogoChange = (e) => {
    if (e.target.files[0]) {
      setProfile((prev) => ({ ...prev, logoUrl: e.target.files[0] }));
    }
  };

  const handleSubmit = async () => {
    try {
      setLoading(true);
      const user = JSON.parse(localStorage.getItem("user"));
      const companyId = user?.data?._id;
      if (!companyId) {
        toast.error("No company ID found!");
        return;
      }

      const formData = new FormData();
      formData.append("name", profile.name);
      formData.append("email", profile.email);
      formData.append("role", profile.role);
      formData.append("status", profile.status);
      formData.append("industry", profile.industry);
      formData.append("description", profile.description);

      if (profile.logoUrl instanceof File) {
        formData.append("logoUrl", profile.logoUrl);
      }

      await DataService.updateCompanyById(companyId, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      toast.success("Profile updated successfully!");
    } catch (error) {
      console.error(error);
      toast.error("Failed to update profile");
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <p className="p-6 text-gray-500">Loading...</p>;
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen grid grid-cols-3 gap-6">
      {/* Left Column - Profile */}
      <div className="col-span-2 bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-2xl font-bold mb-4">Company Settings</h2>

        <div className="grid grid-cols-3 gap-8">
          {/* Logo Section */}
          <div className="col-span-1 bg-blue-50 flex flex-col items-center p-4 rounded">
            <img
              src={
                profile.logoUrl instanceof File
                  ? URL.createObjectURL(profile.logoUrl)
                  : profile.logoUrl || "/logo.png"
              }
              alt="Logo"
              className="w-24 h-24 rounded-full border border-gray-300 object-cover"
            />
            <label className="bg-blue-500 mt-2 text-white px-3 py-1 rounded text-sm cursor-pointer">
              Change Logo
              <input
                type="file"
                className="hidden"
                onChange={handleLogoChange}
                accept="image/png, image/jpeg"
              />
            </label>
            <p className="text-xs text-gray-500 mt-1">
              Recommended: 400x400 JPG or PNG
            </p>
          </div>

          {/* Form Section */}
          <div className="col-span-2 space-y-4">
            <div>
              <label className="text-sm font-medium">Company Name</label>
              <input
                value={profile.name}
                onChange={(e) => handleChange("name", e.target.value)}
                className="w-full mt-1 border border-gray-300 px-3 py-2 rounded"
              />
            </div>

            <div>
              <label className="text-sm font-medium">Email</label>
              <input
                value={profile.email}
                onChange={(e) => handleChange("email", e.target.value)}
                className="w-full mt-1 border border-gray-300 px-3 py-2 rounded"
                type="email"
              />
            </div>

            <div>
              <label className="text-sm font-medium">Role</label>
              <input
                value={profile.role}
                onChange={(e) => handleChange("role", e.target.value)}
                className="w-full mt-1 border border-gray-300 px-3 py-2 rounded"
              />
            </div>

            <div>
              <label className="text-sm font-medium">Status</label>
              <input
                value={profile.status}
                onChange={(e) => handleChange("status", e.target.value)}
                className="w-full mt-1 border border-gray-300 px-3 py-2 rounded"
              />
            </div>

            <div>
              <label className="text-sm font-medium">Industry</label>
              <input
                value={profile.industry}
                onChange={(e) => handleChange("industry", e.target.value)}
                className="w-full mt-1 border border-gray-300 px-3 py-2 rounded"
                placeholder="Enter your industry"
              />
            </div>

            <div>
              <label className="text-sm font-medium">Description</label>
              <textarea
                value={profile.description}
                onChange={(e) => handleChange("description", e.target.value)}
                className="w-full mt-1 border border-gray-300 px-3 py-2 rounded"
                rows={4}
                placeholder="Describe your company"
              />
            </div>

            <div className="flex gap-2">
              <button
                className="bg-gray-100 px-4 py-2 rounded text-sm"
                onClick={() => window.location.reload()}
              >
                Cancel
              </button>
              <button
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 text-sm"
                onClick={handleSubmit}
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Right Column - Quick Actions & Recent Activity */}
      <div className="col-span-1 space-y-6">
        {/* Quick Actions */}
        <div className="bg-white p-4 rounded-lg shadow-sm">
          <h3 className="text-lg font-semibold mb-3">Quick Actions</h3>
          <div className="space-y-2">
            <button className="w-full bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 text-sm">
              Create Job Posting
            </button>
            <button className="w-full bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 text-sm">
              View Applicants
            </button>
            <button className="w-full bg-purple-500 text-white px-4 py-2 rounded hover:bg-purple-600 text-sm">
              Update Company Info
            </button>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white p-4 rounded-lg shadow-sm">
          <h3 className="text-lg font-semibold mb-3">Recent Activity</h3>
          <ul className="space-y-3">
            {recentActivity.length > 0 ? (
              recentActivity.map((item) => (
                <li key={item.id} className="text-sm border-b pb-2 last:border-none">
                  <p className="text-gray-800">{item.text}</p>
                  <span className="text-xs text-gray-500">{item.date}</span>
                </li>
              ))
            ) : (
              <p className="text-sm text-gray-500">No recent activity</p>
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}
