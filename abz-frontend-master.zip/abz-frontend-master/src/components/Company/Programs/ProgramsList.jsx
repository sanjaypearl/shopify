"use client";

import React, { useEffect, useState } from "react";
import { PlusCircle, Filter } from "lucide-react";
import NewProgramModal from "@/components/Programs/Programs";
import DataService from "@/services/Axios/axiosInterceptor";
import { toast } from "react-toastify";

const statusColors = {
  active: "text-green-600",
  paused: "text-orange-500",
  draft: "text-gray-500",
  completed: "text-blue-600",
};

const ProgramCard = ({
  name,
  status,
  description,
  updatedAt,
  researchersCount,
  submissions,
  verifiedVulnerabilities,
  logoUrl,
  company,
}) => (
  <div className="border border-gray-300 rounded-lg bg-white p-4 shadow-sm">
    <div className="flex justify-between items-start">
      <div>
        <h3 className="font-semibold text-lg flex items-center gap-2">
          {name}
          <span
            className={`text-xs font-medium ${
              statusColors[status?.toLowerCase()] || "text-gray-500"
            }`}
          >
            ● {status}
          </span>
        </h3>
        <p className="text-sm text-gray-600 mt-1">{description}</p>
        {company && (
          <p className="text-sm text-gray-500 mt-1 italic">by {company.name}</p>
        )}
      </div>
      <div className="text-sm text-gray-500">
        Last updated: {new Date(updatedAt).toLocaleDateString()}
      </div>
    </div>

    <div className="flex justify-between mt-4 items-center flex-wrap gap-4">
      <div className="flex items-center gap-2">
        <div className="flex -space-x-2">
          <img
            src={logoUrl}
            alt="logo"
            className="w-8 h-8 rounded-full border-2 border-white"
          />
        </div>
        <span className="text-sm text-gray-700">
          {researchersCount} researchers participating
        </span>
      </div>
      <div className="flex items-center gap-4 text-sm">
        <span className="text-gray-700 font-medium">{submissions} submissions</span>
        <span className="text-gray-700 font-medium">{verifiedVulnerabilities} verified</span>
        <button className="bg-white border border-gray-300 text-blue-600 hover:bg-gray-100 px-3 py-1.5 rounded-md text-sm font-medium">
          View Details
        </button>
      </div>
    </div>
  </div>
);

const ProgramsList = () => {
  const [showModal, setShowModal] = useState(false);
  const [programs, setPrograms] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("All");

  const fetchPrograms = async () => {
    try {
      const response = await DataService.getAllActiveProgram();
      if (response.data.success) {
        setPrograms(response.data.data);
      }
    } catch (error) {
      toast.error("Failed to load programs");
    }
  };

  useEffect(() => {
    fetchPrograms();
  }, []);

  const handleCreate = (newProgram) => {
    setPrograms((prev) => [newProgram, ...prev]);
  };

  // Filtered programs based on search term and status
  const filteredPrograms = programs.filter((program) => {
    const matchesSearch =
      program.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      program.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      selectedStatus === "All" || program.status?.toLowerCase() === selectedStatus.toLowerCase();

    return matchesSearch && matchesStatus;
  });

  return (
    <main className="max-w-6xl mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-xl font-semibold">Programs</h2>
          <p className="text-sm text-gray-500">
            Manage your vulnerability disclosure program
          </p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm flex items-center gap-1"
        >
          <PlusCircle size={16} />
          Create New Program
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-md shadow-sm border border-gray-300 mb-6 flex flex-wrap gap-4 items-center">
        <input
          type="text"
          placeholder="Search programs..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="border border-gray-300 px-3 py-2 rounded-md text-sm w-full md:w-1/3"
        />
        <select
          value={selectedStatus}
          onChange={(e) => setSelectedStatus(e.target.value)}
          className="border border-gray-300 px-3 py-2 rounded-md text-sm"
        >
          <option value="All">All Statuses</option>
          <option value="Active">Active</option>
          <option value="Paused">Paused</option>
          <option value="Completed">Completed</option>
          <option value="Draft">Draft</option>
        </select>
        <button className="ml-auto bg-gray-100 border border-gray-300 px-3 py-2 rounded-md text-sm flex items-center gap-1">
          <Filter size={16} />
          More Filter
        </button>
      </div>

      {/* Program Cards */}
      <div className="space-y-4">
        {filteredPrograms.map((program) => (
          <ProgramCard
            key={program._id}
            name={program.name}
            status={program.status}
            description={program.description}
            updatedAt={program.updatedAt}
            researchersCount={program.researchersCount}
            submissions={program.submissions}
            verifiedVulnerabilities={program.verifiedVulnerabilities}
            logoUrl={program.logoUrl}
            company={program.company}
          />
        ))}
      </div>

      {/* Pagination (static for now) */}
      <div className="flex justify-between items-center text-sm text-gray-600 mt-6">
        <p>Showing {filteredPrograms.length} programs</p>
        <div className="flex items-center gap-1">
          <button className="px-2 py-1 rounded bg-gray-100 border border-gray-300">1</button>
          <button className="px-2 py-1 rounded hover:bg-gray-100">2</button>
          <button className="px-2 py-1 rounded hover:bg-gray-100">›</button>
          <button className="px-2 py-1 rounded hover:bg-gray-100">»</button>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <NewProgramModal onClose={() => setShowModal(false)} onSave={handleCreate} />
      )}
    </main>
  );
};

export default ProgramsList;
