import React from "react";
import NavigationSidebar from "./NavigationSidebar";

const Companydashboard = () => {
  return (
    <div>
      <NavigationSidebar />
    </div>
  );
};

export default Companydashboard;
