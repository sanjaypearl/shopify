"use client";

import { useEffect, useState } from "react";
import { Bar } from "react-chartjs-2";
import "chart.js/auto";
import { FaBuilding, FaCheck, FaBan } from "react-icons/fa";
import DataServices from "@/services/Axios/axiosInterceptor";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const ManageCompanies = () => {
  const [companiesData, setCompaniesData] = useState([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");
  const [industryFilter, setIndustryFilter] = useState("All");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [logoPreview, setLogoPreview] = useState(null);

  const [newCompany, setNewCompany] = useState({
    name: "",
    email: "",
    password: "",
    role: "",
    status: "active",
  });

  const [updatedCompany, setUpdatedCompany] = useState({
    _id: null,
    name: "",
    email: "",
    industry: "",
    logoUrl: null,
    role: "",
    status: "active",
  });

  const fetchCompanies = async () => {
    try {
      const res = await DataServices.getAllCompany();
      const data = res?.data?.data;
      if (data) setCompaniesData(data);
    } catch (error) {
      console.error("Error fetching companies", error);
      toast.error("Failed to fetch companies.");
    }
  };

  useEffect(() => {
    fetchCompanies();
  }, []);

  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setUpdatedCompany({ ...updatedCompany, logoUrl: file });
      setLogoPreview(URL.createObjectURL(file));
    }
  };

  const submitCompany = async () => {
    try {
      if (updatedCompany._id) {
        // UPDATE
        const payload = new FormData();
        payload.append("name", updatedCompany.name);
        payload.append("email", updatedCompany.email);
        payload.append("industry", updatedCompany.industry || "");
        payload.append("status", updatedCompany.status);

        if (
          updatedCompany.logoUrl &&
          typeof updatedCompany.logoUrl !== "string"
        ) {
          payload.append("logoUrl", updatedCompany.logoUrl);
        }

        const res = await DataServices.updateCompanyById(
          updatedCompany.companyId || updatedCompany._id,
          payload
        );
        toast.success(res?.data?.message || "Company updated");
      } else {
        // CREATE
        if (!newCompany.name || !newCompany.email || !newCompany.password) {
          toast.warn("Please fill in all required fields.");
          return;
        }
        const payload = {
          name: newCompany.name,
          email: newCompany.email,
          password: newCompany.password,
          role: "company",
          status: newCompany.status,
        };
        if (logoPreview) {
          payload.logoUrl = logoPreview;
        }
        await DataServices.addCompany(payload);
        toast.success("Company added successfully!");
      }

      await fetchCompanies();

      setNewCompany({
        name: "",
        email: "",
        password: "",
        role: "",
        status: "active",
      });

      setUpdatedCompany({
        _id: null,
        name: "",
        email: "",
        industry: "",
        logoUrl: null,
        role: "",
        status: "active",
      });

      setLogoPreview(null);
      setIsModalOpen(false);
    } catch (err) {
      console.error("Submit failed", err);
      toast.error("Failed to submit company.");
    }
  };

  const filteredCompanies = companiesData.filter((company) => {
    const matchStatus =
      statusFilter === "All" || company.status === statusFilter;
    const matchIndustry =
      industryFilter === "All" || company.industry === industryFilter;
    const matchSearch = company.name
      ?.toLowerCase()
      .includes(search.toLowerCase());
    return matchStatus && matchIndustry && matchSearch;
  });

  const industries = [
    ...new Set(companiesData.map((c) => c.industry).filter(Boolean)),
  ];

  const totalCompanies = companiesData.length;
  const activeCompanies = companiesData.filter(
    (c) => c.status === "active"
  ).length;
  const suspendedCompanies = companiesData.filter(
    (c) => c.status === "suspended"
  ).length;

  const barChartData = {
    labels: industries,
    datasets: [
      {
        label: "Companies",
        data: industries.map(
          (ind) => companiesData.filter((c) => c.industry === ind).length
        ),
        backgroundColor: "#3B82F6",
      },
    ],
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center">
          <div className="bg-white p-6 rounded shadow-lg w-full max-w-md">
            <h2 className="text-lg font-semibold mb-4">
              {updatedCompany._id ? "Edit Company" : "Add New Company"}
            </h2>

            <div className="space-y-3">
              <input
                type="text"
                placeholder="Name"
                value={
                  updatedCompany._id ? updatedCompany.name : newCompany.name
                }
                onChange={(e) =>
                  updatedCompany._id
                    ? setUpdatedCompany({
                        ...updatedCompany,
                        name: e.target.value,
                      })
                    : setNewCompany({
                        ...newCompany,
                        name: e.target.value,
                      })
                }
                className="w-full border p-2 rounded"
              />

              <input
                type="email"
                placeholder="Email"
                value={
                  updatedCompany._id ? updatedCompany.email : newCompany.email
                }
                onChange={(e) =>
                  updatedCompany._id
                    ? setUpdatedCompany({
                        ...updatedCompany,
                        email: e.target.value,
                      })
                    : setNewCompany({
                        ...newCompany,
                        email: e.target.value,
                      })
                }
                disabled={!!updatedCompany._id}
                className="w-full border p-2 rounded"
              />

              {!updatedCompany._id && (
                <>
                  <input
                    type="password"
                    placeholder="Password"
                    value={newCompany.password}
                    onChange={(e) =>
                      setNewCompany({
                        ...newCompany,
                        password: e.target.value,
                      })
                    }
                    className="w-full border p-2 rounded"
                  />
                  <input
                    type="text"
                    value="company"
                    disabled
                    className="w-full border p-2 rounded bg-gray-100"
                  />
                </>
              )}

              <select
                value={
                  updatedCompany._id ? updatedCompany.status : newCompany.status
                }
                onChange={(e) =>
                  updatedCompany._id
                    ? setUpdatedCompany({
                        ...updatedCompany,
                        status: e.target.value,
                      })
                    : setNewCompany({
                        ...newCompany,
                        status: e.target.value,
                      })
                }
                className="w-full border p-2 rounded"
              >
                <option value="active">active</option>
                <option value="suspended">suspended</option>
              </select>

              {updatedCompany._id && (
                <>
                  <input
                    type="text"
                    placeholder="Industry"
                    value={updatedCompany.industry}
                    onChange={(e) =>
                      setUpdatedCompany({
                        ...updatedCompany,
                        industry: e.target.value,
                      })
                    }
                    className="w-full border p-2 rounded"
                  />

                  {(logoPreview ||
                    (typeof updatedCompany.logoUrl === "string" &&
                      updatedCompany.logoUrl)) && (
                    <img
                      src={
                        logoPreview ||
                        `${updatedCompany.logoUrl}?t=${Date.now()}`
                      }
                      alt="Logo Preview"
                      className="w-12 h-12 rounded-full object-cover"
                    />
                  )}

                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoChange}
                    className="w-full"
                  />
                </>
              )}
            </div>

            <div className="flex justify-end mt-4 gap-2">
              <button
                onClick={() => {
                  setIsModalOpen(false);
                  setNewCompany({
                    name: "",
                    email: "",
                    password: "",
                    role: "",
                    status: "active",
                  });
                  setUpdatedCompany({
                    _id: null,
                    name: "",
                    email: "",
                    industry: "",
                    logoUrl: null,
                    role: "",
                    status: "active",
                  });
                  setLogoPreview(null);
                }}
                className="px-4 py-2 border rounded"
              >
                Cancel
              </button>
              <button
                onClick={submitCompany}
                className={`px-4 py-2 text-white rounded ${
                  updatedCompany._id ? "bg-green-600" : "bg-blue-600"
                }`}
              >
                {updatedCompany._id ? "Update" : "Add"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-xl font-semibold">Manage Companies</h2>
          <p className="text-sm text-gray-500">
            View and manage all registered companies
          </p>
        </div>
        <button
          onClick={() => {
            setNewCompany({
              name: "",
              email: "",
              password: "",
              role: "",
              status: "active",
            });
            setUpdatedCompany({
              _id: null,
              name: "",
              email: "",
              industry: "",
              logoUrl: null,
              role: "",
              status: "active",
            });
            setLogoPreview(null);
            setIsModalOpen(true);
          }}
          className="bg-blue-600 text-white px-4 py-2 rounded"
        >
          Add New Company
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded p-4 mb-4 shadow-sm grid grid-cols-1 md:grid-cols-4 gap-4">
        <select
          className="border p-2 rounded"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="All">All Status</option>
          <option value="active">active</option>
          <option value="suspended">suspended</option>
        </select>
        <select
          className="border p-2 rounded"
          value={industryFilter}
          onChange={(e) => setIndustryFilter(e.target.value)}
        >
          <option value="All">All Industries</option>
          {industries.map((ind, i) => (
            <option key={i} value={ind}>
              {ind}
            </option>
          ))}
        </select>
        <input
          type="text"
          className="border p-2 rounded col-span-2"
          placeholder="Search companies..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Table */}
      <div className="bg-white rounded shadow overflow-x-auto">
        <table className="w-full text-sm table-auto">
          <thead className="bg-gray-100 text-gray-600 font-medium">
            <tr>
              <th className="p-3 text-left">Company</th>
              <th>Industry</th>
              <th>Email</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredCompanies.map((c, i) => (
              <tr key={i} className="border-t">
                <td className="p-3 flex items-center gap-2">
                  <img
                    src={c.logoUrl}
                    alt={c.name}
                    className="w-8 h-8 rounded-full object-cover"
                  />
                  {c.name}
                </td>
                <td>{c.industry || "-"}</td>
                <td>{c.email}</td>
                <td>
                  <span
                    className={`font-semibold flex items-center gap-1 ${
                      c.status === "active" ? "text-green-600" : "text-red-500"
                    }`}
                  >
                    {c.status}
                  </span>
                </td>
                <td>
                  <button
                    onClick={() => {
                      setUpdatedCompany({ ...c });
                      setNewCompany({
                        name: "",
                        email: "",
                        password: "",
                        role: "",
                        status: "active",
                      });
                      setLogoPreview(null);
                      setIsModalOpen(true);
                    }}
                    className="text-blue-500 hover:underline"
                  >
                    Edit
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Stats */}
      <div className="grid md:grid-cols-3 gap-4 mt-6">
        <div className="bg-blue-100 p-4 rounded shadow flex items-center gap-4">
          <FaBuilding className="text-2xl text-blue-500" />
          <div>
            <p className="text-sm text-gray-500">Total Companies</p>
            <h3 className="text-xl font-semibold">{totalCompanies}</h3>
          </div>
        </div>
        <div className="bg-green-100 p-4 rounded shadow flex items-center gap-4">
          <FaCheck className="text-2xl text-green-500" />
          <div>
            <p className="text-sm text-gray-500">Active</p>
            <h3 className="text-xl font-semibold">{activeCompanies}</h3>
          </div>
        </div>
        <div className="bg-red-100 p-4 rounded shadow flex items-center gap-4">
          <FaBan className="text-2xl text-red-500" />
          <div>
            <p className="text-sm text-gray-500">Suspended</p>
            <h3 className="text-xl font-semibold">{suspendedCompanies}</h3>
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="mt-6 bg-white p-4 rounded shadow">
        <h3 className="font-semibold mb-2 text-md">Companies by Industry</h3>
        <Bar data={barChartData} height={200} />
      </div>

      <ToastContainer position="top-left" autoClose={3000} />
    </div>
  );
};

export default ManageCompanies;
