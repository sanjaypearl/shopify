"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { FiSearch, FiBell } from "react-icons/fi";
import { FaPlus, FaBug } from "react-icons/fa";
import DataService from "@/services/Axios/axiosInterceptor";
import SubmitReportForm from "@/components/AdminComponents/Report/ManageReport";

const Header = () => {
  const [admin, setAdmin] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [userRole, setUserRole] = useState(null);

  // Fetch logged-in user details
  const fetchAdminById = async () => {
    const user = JSON.parse(localStorage.getItem("user"));
    const adminId = user?.data?._id;
    const role = user?.data?.role?.toLowerCase();
    setUserRole(role);

    if (!adminId) return;

    try {
      const response = await DataService.getAdminById(adminId);
      const adminData = response.data?.data;
      if (adminData) {
        setAdmin(adminData);
      }
    } catch (error) {
      console.error("Error fetching admin:", error);
    }
  };

  useEffect(() => {
    fetchAdminById();
  }, []);

  // Role-based header configuration
  const headerOptions = {
    admin: [{ type: "search" }, { type: "notifications" }],
    company: [{ type: "newProgram" }, { type: "notifications" }],
    treasurer: [{ type: "notifications" }],
    researcher: [{ type: "notifications" }, { type: "submitReport" }],
  };

  // Render header item
  const renderHeaderItem = (item) => {
    switch (item.type) {
      case "search":
        // Admin-only search box (same as your admin header)
        return (
          <div className="relative w-full max-w-md">
            <FiSearch className="absolute top-2.5 left-3 text-gray-400" />
            <input
              type="text"
              placeholder="Search reports, companies, users..."
              className="w-full pl-10 pr-4 py-2 rounded-md border border-gray-300 
                         focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
            />
          </div>
        );
      case "notifications":
        return (
          <button className="p-2 rounded-full hover:bg-gray-100 relative">
            <FiBell size={18} />
            <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full" />
          </button>
        );
      case "newProgram":
        return (
          <button className="bg-blue-500 text-white text-sm font-medium px-4 py-2 rounded-md hover:bg-green-600 transition">
            <FaPlus className="inline mr-1" /> New Program
          </button>
        );
      case "submitReport":
        return (
          <button
            className="bg-blue-500 text-white text-sm font-medium px-4 py-2 rounded-md hover:bg-blue-600 transition"
            onClick={() => setShowModal(true)}
          >
            <FaBug className="inline mr-1" /> Submit Report
          </button>
        );
      default:
        return null;
    }
  };

  const itemsToRender = headerOptions[userRole] || [];

  return (
    <header className="bg-white px-6 py-4 flex justify-between items-center shadow-sm">
      {showModal && <SubmitReportForm onClose={() => setShowModal(false)} />}

      {/* Left - Logo */}
      <div className="flex items-center gap-2">
        <Image src="/logoo.png" alt="Logo" width={24} height={24} />
        <div className="text-lg font-semibold leading-tight">CyberNeoGen</div>
      </div>

      {/* Center - Dynamic Items */}
      <div className="flex-1 flex justify-end mr-4 mt-1 gap-4">
        {itemsToRender.map((item, index) => (
          <div key={index}>{renderHeaderItem(item)}</div>
        ))}
      </div>

      {/* Right - User Info */}
      <div className="flex items-center gap-4">
        <Image
          src={admin?.profilePicture || "/person.jpg"}
          alt={admin?.name || "User"}
          width={35}
          height={35}
          className="rounded-full object-cover"
        />
        <div className="text-sm">
          <div className="font-semibold text-black">
            {admin?.name || "Loading..."}
          </div>
          <div className="text-gray-500 text-xs capitalize">
            {userRole || "Role"}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
