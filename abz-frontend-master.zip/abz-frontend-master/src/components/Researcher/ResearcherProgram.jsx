"use client";
import React, { useEffect, useState } from "react";
import { CalendarDays, Clock } from "lucide-react";
import { useDispatch, useSelector } from "react-redux";
import { fetchPrograms } from "@/store/actions/programAction";

export default function ResearcherProgram() {
  const dispatch = useDispatch();
  const {
    data: programs,
    loading,
    error,
  } = useSelector((state) => state.program);

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  // Fetch programs from Redux store
  useEffect(() => {
    dispatch(fetchPrograms());
  }, [dispatch]);

  const totalPages = Math.ceil((programs?.length || 0) / itemsPerPage);
  const currentData =
    programs?.slice(
      (currentPage - 1) * itemsPerPage,
      currentPage * itemsPerPage
    ) || [];

  if (loading) {
    return <p className="text-center py-10">Loading programs...</p>;
  }

  if (error) {
    return <p className="text-center text-red-500 py-10">{error}</p>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 font-sans">
      <h1 className="text-2xl font-bold mb-1">Bug Bounty Programs</h1>
      <p className="text-sm text-gray-500 mb-6">
        Browse and submit to public vulnerability disclosure programs
      </p>

      {/* Filter */}
      <div className="flex flex-wrap justify-between gap-4 items-center mb-6">
        <div className="flex flex-wrap gap-4">
          <input
            type="text"
            placeholder="Search by name or keyword..."
            className="border border-gray-300 px-4 py-2 rounded-md w-64 text-sm"
          />
          <select className="border border-gray-300 px-4 py-2 rounded-md text-sm">
            <option>All Industries</option>
          </select>
          <select className="border border-gray-300 px-4 py-2 rounded-md text-sm">
            <option>All Scopes</option>
          </select>
          <select className="border border-gray-300 px-4 py-2 rounded-md text-sm">
            <option>Any Amount</option>
          </select>
        </div>
        <div className="flex items-center gap-4">
          <select className="border border-gray-300 px-4 py-2 rounded-md text-sm">
            <option>Recently Updated</option>
          </select>
          <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 text-sm">
            Submit Report
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {currentData.map((item) => (
          <div
            key={item._id}
            className="border border-gray-300 rounded-lg p-4 bg-white shadow-sm"
          >
            <div className="flex items-start justify-between">
              <div className="flex gap-3">
                <img
                  src={item.logoUrl}
                  alt={item.name}
                  className="w-10 h-10 rounded-md object-contain"
                />
                <div>
                  <h2 className="text-md font-semibold">{item.name}</h2>
                  <p className="text-sm text-gray-500">{item.company?.name}</p>
                </div>
              </div>
              <span className="text-sm text-gray-500 capitalize">
                {item.status}
              </span>
            </div>

            <p className="text-sm text-gray-700 mt-3">{item.description}</p>

            <div className="flex items-center gap-2 text-xs text-gray-500 mt-2">
              <CalendarDays className="w-4 h-4" />
              <span>
                {new Date(item.startDate).toLocaleDateString()} -{" "}
                {new Date(item.endDate).toLocaleDateString()}
              </span>
            </div>

            <div className="flex items-center gap-4 text-xs text-gray-500 mt-1">
              <span>Reports: {item.reportsReceived}</span>
              <span>Researchers: {item.researchersCount}</span>
              <span>Submissions: {item.submissions}</span>
            </div>

            <button className="mt-4 w-full bg-gray-300 text-gray-800 font-bold py-2 rounded hover:bg-gray-400 text-sm">
              View Details
            </button>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className="flex justify-between items-center mt-6">
        <p className="text-sm text-gray-600">
          Showing {currentData.length} of {programs?.length || 0} programs
        </p>

        <div className="flex gap-2">
          {[...Array(totalPages)].map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentPage(i + 1)}
              className={`px-3 py-1 rounded border border-gray-300 text-sm ${
                currentPage === i + 1
                  ? "bg-blue-600 text-white"
                  : "bg-white text-gray-800"
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
