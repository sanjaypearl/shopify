"use client";
import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchResearchers } from "@/store/actions/researcherAction";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

const chartData = {
  labels: [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ],
  datasets: [
    {
      label: "Total Reports",
      data: [10, 14, 12, 9, 18, 16, 20, 24, 22, 15, 10, 12],
      backgroundColor: "#3B82F6",
      barThickness: 12,
    },
    {
      label: "Accepted Reports",
      data: [4, 8, 6, 5, 10, 9, 15, 20, 18, 11, 6, 8],
      backgroundColor: "#F97316",
      barThickness: 12,
    },
  ],
};

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: "bottom",
      labels: { boxWidth: 12, boxHeight: 12, padding: 20 },
    },
  },
  scales: {
    x: { stacked: false, grid: { display: false } },
    y: { stacked: false, beginAtZero: true, ticks: { stepSize: 5 } },
  },
};

const getStatusColor = (status) => {
  switch (status) {
    case "Accepted":
      return "text-green-600";
    case "Triaging":
      return "text-yellow-600";
    case "Resolved":
      return "text-emerald-600";
    case "Duplicate":
      return "text-yellow-500";
    case "Rejected":
      return "text-red-600";
    default:
      return "text-gray-600";
  }
};

const getSeverityColor = (severity) => {
  switch (severity) {
    case "Critical":
      return "text-red-600";
    case "High":
      return "text-orange-600";
    case "Medium":
      return "text-yellow-500";
    case "Low":
      return "text-blue-600";
    default:
      return "text-gray-600";
  }
};

export default function ResearcherReports() {
  const dispatch = useDispatch();
  const { data = [], loading, error } = useSelector((state) => state.report);

  const [filters, setFilters] = useState({
    program: "All Programs",
    severity: "All Severities",
    status: "All Statuses",
    sort: "Newest First",
  });

  useEffect(() => {
    dispatch(fetchResearchers());
  }, [dispatch]);

  return (
    <div className="p-6 bg-white min-h-screen">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-semibold">My Reports</h2>
        <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
          Submit New Report
        </button>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {["program", "severity", "status", "sort"].map((key, idx) => (
          <select
            key={idx}
            className="border border-gray-300 px-3 py-2 rounded text-sm"
            value={filters[key]}
            onChange={(e) =>
              setFilters((prev) => ({ ...prev, [key]: e.target.value }))
            }
          >
            {key === "program" && (
              <>
                <option>All Programs</option>
                {/* Could be dynamically mapped */}
                {[...new Set(data.map((r) => r.program))].map((p) => (
                  <option key={p}>{p}</option>
                ))}
              </>
            )}
            {key === "severity" && (
              <>
                <option>All Severities</option>
                <option>Critical</option>
                <option>High</option>
                <option>Medium</option>
                <option>Low</option>
              </>
            )}
            {key === "status" && (
              <>
                <option>All Statuses</option>
                <option>Accepted</option>
                <option>Triaging</option>
                <option>Resolved</option>
                <option>Duplicate</option>
                <option>Rejected</option>
              </>
            )}
            {key === "sort" && (
              <>
                <option>Newest First</option>
                <option>Oldest First</option>
              </>
            )}
          </select>
        ))}
      </div>

      {/* Report Table */}
      <div className="border border-gray-300 rounded-md overflow-hidden">
        <div className="divide-y">
          {loading && <div className="p-4">Loading...</div>}
          {error && <div className="p-4 text-red-500">{error}</div>}
          {!loading &&
            !error &&
            data.length > 0 &&
            data.map((report) => (
              <div
                key={report._id}
                className="grid grid-cols-5 items-center px-4 py-3 text-sm hover:bg-gray-50"
              >
                <div className="col-span-2">{report.reportTitle}</div>
                <div>{report.program}</div>
                <div className="flex gap-2">
                  <span className={getSeverityColor(report.severity)}>
                    {report.severity}
                  </span>
                  <span className={getStatusColor(report.status)}>
                    {report.status}
                  </span>
                </div>
                <div className="flex items-center justify-end gap-3">
                  <span>{new Date(report.createdAt).toLocaleDateString()}</span>
                  <button className="bg-blue-500 text-white text-xs px-3 py-1 rounded hover:bg-blue-600">
                    View Details
                  </button>
                </div>
              </div>
            ))}
          {!loading && !error && data.length === 0 && (
            <div className="p-4 text-gray-500">No reports found.</div>
          )}
        </div>
      </div>

      {/* Pagination */}
      <div className="mt-4 flex justify-between items-center text-sm">
        <span>Showing {data.length} reports</span>
        <div className="flex gap-1">
          {["Previous", 1, 2, 3, 4, "Next"].map((p, i) => (
            <button
              key={i}
              className={`px-3 py-1 rounded ${
                p === 1 ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-800"
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Report Statistics (Static) */}
      <div className="mt-10">
        <h3 className="text-lg font-semibold mb-4">Report Statistics</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <div className="bg-gray-100 rounded p-4 text-center">
            <p className="text-2xl font-bold">24</p>
            <p className="text-sm">Total Reports</p>
          </div>
          <div className="bg-gray-100 rounded p-4 text-center">
            <p className="text-2xl font-bold">18</p>
            <p className="text-sm">Accepted Reports</p>
          </div>
          <div className="bg-gray-100 rounded p-4 text-center">
            <p className="text-2xl font-bold">$8,750</p>
            <p className="text-sm">Total Bounties</p>
          </div>
          <div className="bg-gray-100 rounded p-4 text-center">
            <p className="text-2xl font-bold">3</p>
            <p className="text-sm">Critical Findings</p>
          </div>
        </div>

        <div className="h-64 w-full">
          <Bar data={chartData} options={chartOptions} />
        </div>
      </div>
    </div>
  );
}
