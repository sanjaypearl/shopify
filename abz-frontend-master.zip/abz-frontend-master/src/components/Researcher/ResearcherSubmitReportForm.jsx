"use client";
import { useState } from "react";
import { UploadCloud } from "lucide-react";
import { useDispatch, useSelector } from "react-redux";
import { createReport, fetchReports } from "@/store/actions/reportAction";
import { toast } from "react-toastify";

export default function ResearcherSubmitReportForm() {
  const dispatch = useDispatch();
  const { createStatus, createError } = useSelector((state) => state.report);

  // match backend field names
  const [form, setForm] = useState({
    program: "",
    reportTitle: "",
    vulnerabilityType: "",
    severity: "",
    reproduction_steps: "",
    vulnerability_details: "",
    file: null,
    confirm: false,
  });

  const handleChange = (e) => {
    const { name, value, type, checked, files } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]:
        type === "checkbox" ? checked : type === "file" ? files[0] : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("program", form.program);
    formData.append("reportTitle", form.reportTitle);
    formData.append("vulnerabilityType", form.vulnerabilityType);
    formData.append("severity", form.severity);
    formData.append("reproduction_steps", form.reproduction_steps);
    formData.append("vulnerability_details", form.vulnerability_details || "");

    // optional fields (only if backend supports them)
    formData.append("affected_asset", form.affected_asset || "");
    formData.append("cvss_score", form.cvss_score || "");
    formData.append("similar_cve_reference", form.similar_cve_reference || "");
    formData.append(
      "mitigation_recommendation",
      form.mitigation_recommendation || ""
    );
    formData.append(
      "private_nate_to_cyberveo",
      form.private_nate_to_cyberveo || ""
    );
    formData.append("tags_lable", form.tags_lable || "");
    formData.append("reference_link", form.reference_link || "");

    if (form.file) {
      formData.append("file", form.file);
    }

    try {
      // unwrap() throws on reject so we can catch it
      await dispatch(createReport(formData)).unwrap();
      toast.success("Report submitted successfully");

      // refresh the reports list after creation
      dispatch(fetchReports());

      // clear form
      setForm({
        program: "",
        reportTitle: "",
        vulnerabilityType: "",
        severity: "",
        reproduction_steps: "",
        vulnerability_details: "",
        file: null,
        confirm: false,
      });
    } catch (err) {
      toast.error("Failed to submit report.  Please try again.");
      console.error("Error submitting report:", err);
    }
  };

  const isSubmitting = createStatus === "loading";

  return (
    <div className="bg-white p-6 rounded shadow-md max-w-6xl mx-auto my-8">
      <h2 className="text-xl font-semibold mb-4">
        Submit Vulnerability Report
      </h2>
      <p className="text-sm text-gray-500 mb-6">
        Complete the form below to submit a new vulnerability report
      </p>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Program */}
        <div>
          <label className="block text-sm font-medium mb-1">Program *</label>
          <select
            name="program"
            className="w-full border border-gray-300 rounded px-3 py-2"
            value={form.program}
            onChange={handleChange}
            required
          >
            <option value="">Select a program</option>
            <option>SecureTech Cloud</option>
            <option>RetailShield E-commerce</option>
            <option>FinGuard Banking</option>
          </select>
        </div>

        {/* Report Title */}
        <div>
          <label className="block text-sm font-medium mb-1">
            Report Title *
          </label>
          <input
            name="reportTitle"
            className="w-full border border-gray-300 rounded px-3 py-2"
            placeholder="Provide a clear, descriptive title for your vulnerability"
            value={form.reportTitle}
            onChange={handleChange}
            required
          />
        </div>

        {/* Vulnerability Type */}
        <div>
          <label className="block text-sm font-medium mb-1">
            Vulnerability Type *
          </label>
          <select
            name="vulnerabilityType"
            className="w-full border border-gray-300 rounded px-3 py-2"
            value={form.vulnerabilityType}
            onChange={handleChange}
            required
          >
            <option value="">Select vulnerability type</option>
            <option>SQL Injection</option>
            <option>XSS</option>
            <option>IDOR</option>
            <option>CSRF</option>
            <option>Other</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">
            Affected Asset *
          </label>
          <input
            name="affected_asset"
            className="w-full border border-gray-300 rounded px-3 py-2"
            placeholder="e.g., search page, login form"
            value={form.affected_asset || ""}
            onChange={handleChange}
            required
          />
        </div>

        {/* Severity */}
        <div>
          <label className="block text-sm font-medium mb-2">Severity *</label>
          <div className="flex gap-4">
            {["low", "medium", "high", "critical"].map((level) => (
              <label key={level} className="flex items-center gap-1 text-sm">
                <input
                  type="radio"
                  name="severity"
                  value={level}
                  checked={form.severity === level}
                  onChange={handleChange}
                  required
                />
                {level.charAt(0).toUpperCase() + level.slice(1)}
              </label>
            ))}
          </div>
        </div>

        {/* Steps to Reproduce */}
        <div>
          <label className="block text-sm font-medium mb-1">
            Steps to Reproduce *
          </label>
          <textarea
            name="reproduction_steps"
            className="w-full border border-gray-300 rounded px-3 py-2 h-28"
            placeholder="Provide detailed step-by-step instructions to reproduce the vulnerability"
            value={form.reproduction_steps}
            onChange={handleChange}
            required
          />
        </div>

        {/* Impact / Vulnerability details */}
        <div>
          <label className="block text-sm font-medium mb-1">
            Impact Description *
          </label>
          <textarea
            name="vulnerability_details"
            className="w-full border border-gray-300 rounded px-3 py-2 h-24"
            placeholder="Describe the potential impact of this vulnerability and how it could be exploited"
            value={form.vulnerability_details}
            onChange={handleChange}
            required
          />
        </div>

        {/* Attachments */}
        <div>
          <label className="block text-sm font-medium mb-2">Attachments</label>
          <div className="border-2 border-dashed rounded p-6 flex flex-col items-center gap-2 text-center bg-gray-50">
            <UploadCloud className="w-8 h-8 text-blue-500" />
            <input
              type="file"
              name="file"
              onChange={handleChange}
              className="hidden"
              id="fileUpload"
            />
            <label
              htmlFor="fileUpload"
              className="cursor-pointer bg-blue-500 text-white px-4 py-2 rounded text-sm"
            >
              Browse File
            </label>
            <p className="text-xs text-gray-400">
              Max file size: 20MB. Supported formats: PNG, JPG, PDF, ZIP
            </p>
            {form.file && (
              <p className="text-xs text-gray-600 mt-2">{form.file.name}</p>
            )}
          </div>
        </div>

        {/* Confirm Checkbox */}
        <div>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              name="confirm"
              checked={form.confirm}
              onChange={handleChange}
              required
            />
            I confirm this report complies with the program’s disclosure policy
          </label>
        </div>

        {/* Buttons */}
        <div className="flex gap-4">
          <button
            type="button"
            className="border border-gray-400 px-4 py-2 rounded"
          >
            Save Draft
          </button>
          <button
            type="button"
            className="border border-gray-400 px-4 py-2 rounded"
          >
            Preview
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className={`ml-auto px-6 py-2 rounded ${
              isSubmitting
                ? "bg-gray-400"
                : "bg-blue-600 hover:bg-blue-700 text-white"
            }`}
          >
            {isSubmitting ? "Submitting..." : "Submit Report"}
          </button>
        </div>

        {createError && (
          <div className="text-red-600 text-sm mt-2">{createError}</div>
        )}
      </form>

      {/* Submission Tips */}
      <div className="mt-8 p-4 bg-blue-50 border-l-4 border-blue-500 text-sm text-blue-700">
        <p className="font-semibold mb-2">Submission Tips</p>
        <ul className="list-disc list-inside space-y-1">
          <li>
            Include clear reproduction steps with specific URLs and parameters
          </li>
          <li>
            Attach screenshots or screen recordings to demonstrate the
            vulnerability
          </li>
          <li>
            Explain the potential business impact or threat from the issue
          </li>
          <li>Provide suggestions for remediation if possible</li>
        </ul>
      </div>
    </div>
  );
}
