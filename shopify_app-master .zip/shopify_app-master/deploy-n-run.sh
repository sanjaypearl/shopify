if npm run deploy; then
    npm run dev;
else 
    echo "Failed to deploy and run"
fi