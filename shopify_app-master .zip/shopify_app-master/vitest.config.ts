import { defineConfig } from "vitest/config";
import tsconfigPaths from "vite-tsconfig-paths";

export default defineConfig({
  plugins: [tsconfigPaths()],
  test: {
    globals: true, // No need to import describe, it, expect, etc.
    environment: "node", // We are testing a Node.js API
    setupFiles: ["./tests/setup.ts"], // A file to run before all tests

    coverage: {
      provider: "v8",
      reporter: ["text", "json", "html"],
      include: ['app/routes/**/*.js', 'app/services/**/*.js'],
    },
  },
});
