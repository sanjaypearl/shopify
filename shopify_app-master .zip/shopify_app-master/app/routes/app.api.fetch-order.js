import { logger } from "../logger";
import prisma from "../db.server";

export const action = async ({ request }) => {
  try {
    const {
      shop,
      orderGid,  
    } = await request.json();

    const requiredFields = {
      shop,
      orderGid,
    };
    const missingFields = Object.keys(requiredFields).filter(
      (key) => !requiredFields[key],
    );
    if (missingFields.length > 0) {
      return new Response(
        JSON.stringify({
          success: false,
          error: {
            code: "MISSING_FIELDS",
            message: `Missing required fields: ${missingFields.join(", ")}`,
            details: missingFields,
          },
        }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }

    const session = await prisma.session.findFirst({
      where: { shop: shop },
    });

    if (!session) {
      return new Response(
        JSON.stringify({
          success: false,
          error: {
            code: "SESSION_NOT_FOUND",
            message: "Shop session not found.",
          },
        }),
        { status: 404, headers: { "Content-Type": "application/json" } }
      );
    }

    console.log(session)

    const api_version = "2025-04";
    const shopify_api_url = `https://${shop}/admin/api/${api_version}/graphql.json`;

    const headers = {
      "X-Shopify-Access-Token": session.accessToken,
      "Content-Type": "application/json",
    };

    // ========================================================================
    // STEP 1: Get the first open Fulfillment Order for the main Order
    // (For simplicity, we'll move the first one we find. A real app might need more logic)
    // ========================================================================

    const GET_FULFILLMENT_ORDERS_QUERY = `
        query getFulfillmentOrders($orderId: ID!) {
            order(id: $orderId) {
                fulfillmentOrders(first: 10) {
                    edges {
                        node {
                            id
                            status
                            lineItems(first: 50) {
                                edges {
                                    node {
                                        id
                                        quantity: totalQuantity
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }`;

    const getFfOrdersResponse = await fetch(shopify_api_url, {
      method: "POST",
      headers,
      body: JSON.stringify({
        query: GET_FULFILLMENT_ORDERS_QUERY,
        variables: { orderId: orderGid },
      }),
    });

    const ffOrdersData = await getFfOrdersResponse.json();

    logger.info(`GET_FULFILLMENT_ORDERS_QUERY   ------- > ${JSON.stringify(ffOrdersData)}`)

    if (
      ffOrdersData.errors ||
      !ffOrdersData?.data?.order ||
      !ffOrdersData.data.order.fulfillmentOrders?.edges?.length
    ) {
      logger.error(
        `Could not find open fulfillment orders for ${orderGid}: ${JSON.stringify(ffOrdersData.errors || "No open fulfillment orders found")}`,
      );
      return new Response(
        JSON.stringify({
          success: false,
          error: {
            code: "FULFILLMENT_ORDER_NOT_FOUND",
            message: `Could not find open fulfillment orders for ${orderGid}`,
            details: ffOrdersData.errors || null,
          },
        }),
        { status: 404, headers: { "Content-Type": "application/json" } }
      );
    }

    const originalFulfillmentOrder =
      ffOrdersData.data.order.fulfillmentOrders.edges[0].node;;

    return new Response(
      JSON.stringify({
        success: true,
        message: "Order fetched successfully.",
        originalFulfillmentOrder,
      }),
      { status: 200, headers: { "Content-Type": "application/json" } }
    );
    


  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        error: {
          code: "INTERNAL_ERROR",
          message: error?.message || "An unknown error occurred.", // 140 
          details: error?.stack || null, // 141
        },
      }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
};
