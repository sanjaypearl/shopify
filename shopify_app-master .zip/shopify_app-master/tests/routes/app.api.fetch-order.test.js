import { describe, it, expect, vi, beforeEach } from 'vitest';
import { action } from '../../app/routes/app.api.fetch-order';
import prisma from '../../app/db.server'; // We need to import it to mock it
import { logger } from '../../app/logger'; // Import to check if it's called

// --- MOCKS ---
// Mock the entire prisma module.
// We are replacing its 'default' export with a fake object.
vi.mock('../../app/db.server', () => ({
  default: {
    session: {
      // Replace findFirst with a Vitest mock function we can control
      findFirst: vi.fn(),
    },
  },
}));

// Mock the logger to prevent logs during tests and to check if it's called.
// This is handled globally by our tests/setup.ts file, but
// explicitly showing it here can also be helpful for understanding.
// If you have the setup file, this mock here is not strictly necessary,
// but it doesn't hurt.
vi.mock('../../app/logger', () => ({
  logger: {
    info: vi.fn(),
    error: vi.fn(),
  }
}));

// Mock the global `fetch` function so we don't make real network calls.
vi.stubGlobal('fetch', vi.fn());


// 'describe' groups all tests for this API action.
describe('API Action: Fetch Order', () => {
  const shop = 'test-shop.myshopify.com';
  const orderGid = 'gid://shopify/Order/123456789';

  // 'beforeEach' runs before every 'it' block. This is crucial for ensuring
  // that mocks are reset and tests don't interfere with each other.
  beforeEach(() => {
    vi.clearAllMocks(); // Resets call counts, mock implementations, etc.
  });

  // --- Test Scenario: Failure due to Missing Fields ---
  describe('Input Validation', () => {
    it('should return 400 if shop is missing', async () => {
      // ARRANGE: Create a request missing the 'shop' field.
      const request = new Request('http://test.com', {
        method: 'POST',
        body: JSON.stringify({ orderGid }),
      });

      // ACT
      const response = await action({ request });
      const responseData = await response.json();

      // ASSERT
      expect(response.status).toBe(400);
      expect(responseData.success).toBe(false);
      expect(responseData.error.code).toBe('MISSING_FIELDS');
      expect(responseData.error.message).toContain('Missing required fields: shop');
    });

    it('should return 400 if orderGid is missing', async () => {
      // ARRANGE: Create a request missing the 'orderGid' field.
      const request = new Request('http://test.com', {
        method: 'POST',
        body: JSON.stringify({ shop }),
      });

      // ACT
      const response = await action({ request });
      const responseData = await response.json();

      // ASSERT
      expect(response.status).toBe(400);
      expect(responseData.error.code).toBe('MISSING_FIELDS');
      expect(responseData.error.message).toContain('Missing required fields: orderGid');
    });
  });

  // --- Test Scenario: Database or Shopify API Failures ---
  describe('External Service Failures', () => {
    it('should return 404 if shop session is not found in the database', async () => {
      // ARRANGE: A valid request, but prisma will find nothing.
      const request = new Request('http://test.com', {
        method: 'POST',
        body: JSON.stringify({ shop, orderGid }),
      });
      prisma.session.findFirst.mockResolvedValue(null);

      // ACT
      const response = await action({ request });
      const responseData = await response.json();

      // ASSERT
      expect(response.status).toBe(404);
      expect(responseData.error.code).toBe('SESSION_NOT_FOUND');
      expect(prisma.session.findFirst).toHaveBeenCalledWith({ where: { shop } });
    });

    it('should return 404 if Shopify API returns GraphQL errors', async () => {
        // ARRANGE
        const request = new Request('http://test.com', {
            method: 'POST',
            body: JSON.stringify({ shop, orderGid }),
        });
        const fakeSession = { accessToken: 'fake-token' };
        prisma.session.findFirst.mockResolvedValue(fakeSession);

        // Mock a Shopify response that contains an 'errors' object
        const shopifyErrorResponse = { errors: [{ message: 'Order not found.' }] };
        fetch.mockResolvedValue(new Response(JSON.stringify(shopifyErrorResponse)));

        // ACT
        const response = await action({ request });
        const responseData = await response.json();

        // ASSERT
        expect(response.status).toBe(404);
        expect(responseData.error.code).toBe('FULFILLMENT_ORDER_NOT_FOUND');
        expect(logger.error).toHaveBeenCalled(); // Check that we logged the error
    });

    it('should return 404 if no fulfillment orders are found for the order', async () => {
        // ARRANGE
        const request = new Request('http://test.com', {
            method: 'POST',
            body: JSON.stringify({ shop, orderGid }),
        });
        const fakeSession = { accessToken: 'fake-token' };
        prisma.session.findFirst.mockResolvedValue(fakeSession);

        // Mock a Shopify response that is valid but contains no fulfillment orders
        const shopifyEmptyResponse = { data: { order: { fulfillmentOrders: { edges: [] } } } };
        fetch.mockResolvedValue(new Response(JSON.stringify(shopifyEmptyResponse)));

        // ACT
        const response = await action({ request });
        const responseData = await response.json();

        // ASSERT
        expect(response.status).toBe(404);
        expect(responseData.error.code).toBe('FULFILLMENT_ORDER_NOT_FOUND');
        expect(logger.error).toHaveBeenCalled();
    });

    it('should return 404 if fulfillmentOrders object is null', async () => {
    // ARRANGE
    const request = new Request('http://test.com', {
        method: 'POST',
        body: JSON.stringify({ shop, orderGid }),
    });
    prisma.session.findFirst.mockResolvedValue({ accessToken: 'fake-token' });

    // Mock a response where the fulfillmentOrders key is null
    const shopifyNullResponse = {
        data: {
            order: {
                // This is the key part we are testing
                fulfillmentOrders: null
            }
        }
    };
    fetch.mockResolvedValue(new Response(JSON.stringify(shopifyNullResponse)));

    // ACT
    const response = await action({ request });
    const responseData = await response.json();

    // ASSERT
    expect(response.status).toBe(404);
    expect(responseData.error.code).toBe('FULFILLMENT_ORDER_NOT_FOUND');
});
  });

  // --- Test Scenario: The "Happy Path" ---
  describe('Successful Execution', () => {
    it('should return 200 and the fulfillment order data on success', async () => {
      // ARRANGE
      const request = new Request('http://test.com', {
        method: 'POST',
        body: JSON.stringify({ shop, orderGid }),
      });

      const fakeSession = { id: '1', shop, accessToken: 'fake-token-123' };
      prisma.session.findFirst.mockResolvedValue(fakeSession);

      const fakeShopifyResponse = {
        data: {
          order: {
            fulfillmentOrders: {
              edges: [
                {
                  node: {
                    id: 'gid://shopify/FulfillmentOrder/67890',
                    status: 'OPEN',
                    lineItems: { edges: [{ node: { id: 'li-1', quantity: 1 } }] },
                  },
                },
              ],
            },
          },
        },
      };
      fetch.mockResolvedValue(new Response(JSON.stringify(fakeShopifyResponse)));

      // ACT
      const response = await action({ request });
      const responseData = await response.json();

      // ASSERT
      expect(response.status).toBe(200);
      expect(responseData.success).toBe(true);
      expect(responseData.message).toBe('Order fetched successfully.');
      expect(responseData.originalFulfillmentOrder.id).toBe('gid://shopify/FulfillmentOrder/67890');
      
      // Verify mocks were called as expected
      expect(prisma.session.findFirst).toHaveBeenCalledOnce();
      expect(fetch).toHaveBeenCalledOnce();
      expect(logger.info).toHaveBeenCalled(); // Check that info was logged on success

      // Check not just THAT fetch was called, but WHAT it was called with.
    expect(fetch).toHaveBeenCalledWith(
        `https://${shop}/admin/api/2025-04/graphql.json`, // Check the URL
        expect.objectContaining({ // Check the options object
            method: 'POST',
            headers: {
                "X-Shopify-Access-Token": 'fake-token-123',
                "Content-Type": "application/json",
            },
            // Check that the body contains the correct variables
            body: expect.stringContaining(`"orderId":"${orderGid}"`)
        })
      );
    });
  });

  // --- Test Scenario: Catch-all for unexpected errors ---
describe('Internal Error Handling Fallbacks', () => {
  it('should fall back to default error message and null stack', async () => {
    // Simulate a Request object whose .json() throws a plain object (no message/stack)
    const request = {
      json: vi.fn().mockImplementation(() => {
        throw {}; // ❌ no message, no stack
      }),
      method: 'POST',
    };

    const response = await action({ request: request });
    const responseData = await response.json();

    expect(response.status).toBe(500);
    expect(responseData.success).toBe(false);

    // ✅ These ensure fallback values were used
    expect(responseData.error.message).toBe("An unknown error occurred.");
    expect(responseData.error.details).toBe(null);
  });
});

});