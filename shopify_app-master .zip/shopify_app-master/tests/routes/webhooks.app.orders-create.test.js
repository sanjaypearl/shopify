import { describe, it, expect, vi, beforeEach } from "vitest";
import { action } from "../../app/routes/webhooks.app.orders-create"; // Adjust path if needed
import { authenticate } from "../../app/shopify.server";
import prisma from "../../app/db.server";
import { createOrder, signin } from "../../app/services/API";
import { logger } from "../../app/logger";

// --- MOCKS ---
vi.mock("../../app/shopify.server", () => ({
  authenticate: { webhook: vi.fn() },
}));
vi.mock("../../app/db.server", () => ({
  default: { orders: { create: vi.fn() } },
}));
vi.mock("../../app/services/API", () => ({
  createOrder: vi.fn(),
  signin: vi.fn(),
}));
vi.mock("../../app/logger", () => ({
  logger: { info: vi.fn(), error: vi.fn(), warn: vi.fn() },
}));

// --- TEST SUITE ---
describe("Webhook: Orders Create", () => {
  const shop = "test-shop.myshopify.com";
  const fakeOrderPayload = { id: 12345, admin_graphql_api_id: "gid_12345" };
  const rawBody = JSON.stringify(fakeOrderPayload);

  // Reset mocks before each test for isolation
  beforeEach(() => {
    vi.clearAllMocks();
  });

  // Helper to create a request object
  const createWebhookRequest = (body) =>
    new Request("http://test.com", { method: "POST", body });

  // Helper to parse the JSON response body
  const getResponseData = async (response) => await response.json();

  describe("Authentication & Payload Validation", () => {
    it("should return 400 if the payload is not valid JSON", async () => {
      authenticate.webhook.mockResolvedValue({ shop });
      const request = createWebhookRequest('{ "invalid": json }');
      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(400);
      expect(data.success).toBe(false);
      expect(data.error.code).toBe("INVALID_JSON");
      expect(logger.error).toHaveBeenCalledWith(
        "Webhook - Invalid JSON payload",
        expect.anything(),
      );
    });
  });

  describe("Service Failures", () => {
    beforeEach(() => {
      // All tests in this block pass authentication
      authenticate.webhook.mockResolvedValue({ shop });
    });

    it("should return 500 if saving to the database fails", async () => {
      prisma.orders.create.mockRejectedValue(new Error("DB constraint failed"));
      const request = createWebhookRequest(rawBody);
      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(500);
      expect(data.success).toBe(false);
      expect(data.error.code).toBe("DATABASE_ERROR");
      expect(logger.error).toHaveBeenCalledWith(
        "Webhook - DB insert failed",
        expect.anything(),
      );
    });

    it("should return 502 if the initial createOrder API call fails", async () => {
      prisma.orders.create.mockResolvedValue({});
      createOrder.mockRejectedValue(new Error("API is down"));
      const request = createWebhookRequest(rawBody);
      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(502);
      expect(data.success).toBe(false);
      expect(data.error.code).toBe("API_ERROR");
      expect(logger.error).toHaveBeenCalledWith(
        "Webhook - Create Order API call failed",
        expect.anything(),
      );
    });
  });

  describe("Retry Logic on 403 Forbidden", () => {
    beforeEach(() => {
      authenticate.webhook.mockResolvedValue({ shop });
      prisma.orders.create.mockResolvedValue({});
    });

    it("should attempt signin, retry createOrder, and succeed", async () => {
      // ARRANGE
      createOrder.mockResolvedValueOnce({ results: { status_code: 403 } });
      signin.mockResolvedValue({ success: true });
      createOrder.mockResolvedValueOnce({ results: { status_code: 200 } });

      const request = createWebhookRequest(rawBody);
      const response = await action({ request });
      const data = await getResponseData(response);

      // ASSERT
      expect(response.status).toBe(200);
      expect(data.success).toBe(true);
      expect(data.message).toBe("Webhook processed");
      expect(signin).toHaveBeenCalledOnce();
      expect(createOrder).toHaveBeenCalledTimes(2);
      expect(logger.warn).toHaveBeenCalledWith(
        "Webhook - Create Order - Unauthorized, retrying after signin.",
        expect.anything(),
      );
    });

    it("should return 401 if the signin attempt fails", async () => {
      createOrder.mockResolvedValueOnce({ results: { status_code: 403 } });
      signin.mockRejectedValue(new Error("Invalid signin credentials"));

      const request = createWebhookRequest(rawBody);
      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(401);
      expect(data.success).toBe(false);
      expect(data.error.code).toBe("AUTHORIZATION_FAILED");
      expect(logger.error).toHaveBeenCalledWith(
        "Webhook - Signin or Retry failed",
        expect.anything(),
      );
    });

    it("should return 200 but log an error if the retry also fails with 403", async () => {
      // Using the array response format for coverage
      createOrder.mockResolvedValue({ results: [{ status_code: 403 }] });
      signin.mockResolvedValue({ success: true });

      const request = createWebhookRequest(rawBody);
      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(200);
      expect(data.success).toBe(true);
      expect(signin).toHaveBeenCalledOnce();
      expect(createOrder).toHaveBeenCalledTimes(2);
      expect(logger.error).toHaveBeenCalledWith(
        "Webhook - Create Order - Retry failed due to invalid credentials.",
        expect.anything(),
      );
    });
  });

  describe("Happy Path", () => {
    it("should succeed on the first attempt", async () => {
      authenticate.webhook.mockResolvedValue({ shop });
      prisma.orders.create.mockResolvedValue({});
      createOrder.mockResolvedValue({ results: { status_code: 200 } });

      const request = createWebhookRequest(rawBody);
      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(200);
      expect(data.success).toBe(true);
      expect(data.message).toBe("Webhook processed");
      expect(prisma.orders.create).toHaveBeenCalledOnce();
      expect(createOrder).toHaveBeenCalledOnce();
      expect(signin).not.toHaveBeenCalled();
    });
  });

  describe("Uncaught Exception Handling", () => {
    it("should handle uncaught exception when error lacks stack and message", async () => {
      authenticate.webhook.mockImplementation(() => {
        throw { unexpected: true }; // no .stack or .message
      });

      const request = createWebhookRequest(rawBody);
      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(500);
      expect(data.success).toBe(false);
      expect(data.error.code).toBe("INTERNAL_ERROR");
      expect(data.error.details).toBe("No error message available.");

      expect(logger.error).toHaveBeenCalledWith(
        "Webhook - Uncaught Exception",
        {
          error: { unexpected: true },
          rawBody,
        },
      );
    });
  });
});
