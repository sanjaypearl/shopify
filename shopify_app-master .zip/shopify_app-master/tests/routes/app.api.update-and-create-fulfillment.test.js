import { describe, it, expect, vi, beforeEach } from "vitest";
import { action } from "../../app/routes/app.api.update-and-create-fulfillment"; // Adjust path if needed
import prisma from "../../app/db.server";
import { logger } from "../../app/logger";

// --- MOCKS ---
vi.mock("../../app/db.server", () => ({
  default: {
    session: { findFirst: vi.fn() },
  },
}));

vi.mock("../../app/logger", () => ({
  logger: { info: vi.fn(), error: vi.fn(), warn: vi.fn() },
}));

// Mock the global fetch API
vi.stubGlobal("fetch", vi.fn());

// Helper to easily parse the Response body
const getResponseData = async (response) => JSON.parse(await response.text());

describe("API Action: Update and Create Fulfillment", () => {
  // --- TEST CONSTANTS ---
  const shop = "test-shop.myshopify.com";
  const validRequestBody = {
    shop,
    orderGid: "gid://shopify/Order/123",
    newLocationGid: "gid://shopify/Location/DEF",
    carrier: "Test Carrier",
    tracking_number: "TC123456789",
    tracking_url: "https://test-carrier.com/track/TC123456789",
  };

  beforeEach(() => {
    vi.clearAllMocks(); // Reset mocks before each test
    // Default successful session mock for most tests
    prisma.session.findFirst.mockResolvedValue({ accessToken: "fake-token" });
  });

  // --- TEST SUITES ---

  describe("Input Validation & Pre-flight Checks", () => {
    it("should return 400 if required fields are missing", async () => {
      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify({ shop, orderGid: "gid://shopify/Order/123" }),
      });

      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(400);
      expect(data.success).toBe(false);
      expect(data.error.code).toBe("MISSING_FIELDS");
      expect(data.error.message).toContain(
        "newLocationGid, carrier, tracking_number",
      );
    });

    it("should return 404 if shop session is not found", async () => {
      prisma.session.findFirst.mockResolvedValue(null);
      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify(validRequestBody),
      });

      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(404);
      expect(data.success).toBe(false);
      expect(data.error.code).toBe("SESSION_NOT_FOUND");
    });
  });

  describe("Step 1: Get Fulfillment Order Failures", () => {
    it("should return 404 if the order has no open fulfillment orders", async () => {
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: { order: { fulfillmentOrders: { edges: [] } } },
          }),
        ),
      );

      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify(validRequestBody),
      });
      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(404);
      expect(data.error.code).toBe("FULFILLMENT_ORDER_NOT_FOUND");
      expect(fetch).toHaveBeenCalledTimes(1); // Should fail on the first API call
    });

    it("should return 400 if the found fulfillment order is already closed", async () => {
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              order: {
                fulfillmentOrders: {
                  edges: [
                    {
                      node: {
                        id: "gid://shopify/FulfillmentOrder/1",
                        status: "CLOSED",
                      },
                    },
                  ],
                },
              },
            },
          }),
        ),
      );

      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify(validRequestBody),
      });
      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(400);
      expect(data.error.code).toBe("ORDER_ALREADY_FULFILLED");
      expect(fetch).toHaveBeenCalledTimes(1);
    });
  });

  describe("Step 2: Move Fulfillment Order Failures", () => {
    it("should return 400 if moving the fulfillment order fails with userErrors", async () => {
      // Step 1 Success: Find an open fulfillment order
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              order: {
                fulfillmentOrders: {
                  edges: [
                    {
                      node: {
                        id: "gid://shopify/FulfillmentOrder/1",
                        status: "OPEN",
                      },
                    },
                  ],
                },
              },
            },
          }),
        ),
      );

      // Step 2 Failure: Move fails
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              fulfillmentOrderMove: {
                movedFulfillmentOrder: null,
                userErrors: [
                  {
                    field: "newLocationId",
                    message: "is not a valid location for this order.",
                  },
                ],
              },
            },
          }),
        ),
      );

      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify(validRequestBody),
      });
      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(400);
      expect(data.error.code).toBe("FULFILLMENT_ORDER_MOVE_FAILED");
      expect(data.error.details[0].message).toContain(
        "is not a valid location",
      );
      expect(fetch).toHaveBeenCalledTimes(2);
    });

    it("should return 400 if moving the fulfillment order fails with top-level GraphQL errors", async () => {
      // Step 1 Success: Find an open fulfillment order
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              order: {
                fulfillmentOrders: {
                  edges: [
                    {
                      node: {
                        id: "gid://shopify/FulfillmentOrder/1",
                        status: "OPEN",
                      },
                    },
                  ],
                },
              },
            },
          }),
        ),
      );

      // Step 2 Failure: moveData has top-level `errors`, no userErrors
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            errors: [{ message: "Something went wrong on Shopify side." }],
          }),
        ),
      );

      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify(validRequestBody),
      });

      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(400);
      expect(data.success).toBe(false);
      expect(data.error.code).toBe("FULFILLMENT_ORDER_MOVE_FAILED");
      expect(data.error.details[0].message).toContain("Something went wrong");
      expect(fetch).toHaveBeenCalledTimes(2);
    });
  });

  describe("Step 3: Create Fulfillment Failures", () => {
    it("should return 400 if creating the final fulfillment fails", async () => {
      // Step 1 Success
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              order: {
                fulfillmentOrders: {
                  edges: [
                    {
                      node: {
                        id: "gid://shopify/FulfillmentOrder/1",
                        status: "OPEN",
                        lineItems: {
                          edges: [{ node: { id: "li_1", quantity: 1 } }],
                        },
                      },
                    },
                  ],
                },
              },
            },
          }),
        ),
      );

      // Step 2 Success
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              fulfillmentOrderMove: {
                movedFulfillmentOrder: {
                  id: "gid://shopify/FulfillmentOrder/2_MOVED",
                  status: "OPEN",
                },
                userErrors: [],
              },
            },
          }),
        ),
      );

      // Step 3 Failure
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              fulfillmentCreateV2: {
                fulfillment: null,
                userErrors: [
                  { field: "trackingInfo.number", message: "is invalid." },
                ],
              },
            },
          }),
        ),
      );

      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify(validRequestBody),
      });
      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(400);
      expect(data.error.code).toBe("FULFILLMENT_CREATE_FAILED");
      expect(data.error.details[0].message).toContain("is invalid");
      expect(fetch).toHaveBeenCalledTimes(3);
    });

    it("should return 400 if fulfillment creation fails due to top-level GraphQL errors", async () => {
      // Step 1 Success
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              order: {
                fulfillmentOrders: {
                  edges: [
                    {
                      node: {
                        id: "gid://shopify/FulfillmentOrder/1",
                        status: "OPEN",
                        lineItems: {
                          edges: [{ node: { id: "li_1", quantity: 1 } }],
                        },
                      },
                    },
                  ],
                },
              },
            },
          }),
        ),
      );

      // Step 2 Success
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              fulfillmentOrderMove: {
                movedFulfillmentOrder: {
                  id: "gid://shopify/FulfillmentOrder/2_MOVED",
                  status: "OPEN",
                },
                userErrors: [],
              },
            },
          }),
        ),
      );

      // Step 3 Failure: GraphQL top-level error
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            errors: [{ message: "Invalid tracking number format." }],
          }),
        ),
      );

      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify(validRequestBody),
      });

      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(400);
      expect(data.success).toBe(false);
      expect(data.error.code).toBe("FULFILLMENT_CREATE_FAILED");
      expect(data.error.details[0].message).toContain(
        "Invalid tracking number format",
      );
      expect(fetch).toHaveBeenCalledTimes(3);
    });
  });

  describe("Happy Path", () => {
    it("should successfully get, move, and fulfill an order", async () => {
      // Mock for Step 1: Get Fulfillment Order
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              order: {
                fulfillmentOrders: {
                  edges: [
                    {
                      node: {
                        id: "gid://shopify/FulfillmentOrder/1_ORIGINAL",
                        status: "OPEN",
                        lineItems: {
                          edges: [
                            {
                              node: {
                                id: "gid://shopify/FulfillmentOrderLineItem/1",
                                quantity: 1,
                              },
                            },
                          ],
                        },
                      },
                    },
                  ],
                },
              },
            },
          }),
        ),
      );

      // Mock for Step 2: Move Fulfillment Order
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              fulfillmentOrderMove: {
                movedFulfillmentOrder: {
                  id: "gid://shopify/FulfillmentOrder/2_MOVED",
                  status: "OPEN",
                },
                userErrors: [],
              },
            },
          }),
        ),
      );

      // Mock for Step 3: Create Fulfillment
      fetch.mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: {
              fulfillmentCreateV2: {
                fulfillment: {
                  id: "gid://shopify/Fulfillment/FINAL",
                  status: "SUCCESS",
                },
                userErrors: [],
              },
            },
          }),
        ),
      );

      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify(validRequestBody),
      });
      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(200);
      expect(data.success).toBe(true);
      expect(data.fulfillment.id).toBe("gid://shopify/Fulfillment/FINAL");
      expect(data.message).toBe("Fulfillment created successfully.");
      expect(fetch).toHaveBeenCalledTimes(3);
    });
  });

  describe("Internal Error Handling", () => {
    it("should return 500 for an unexpected error (e.g., prisma failure)", async () => {
      prisma.session.findFirst.mockRejectedValue(
        new Error("DB connection failed"),
      );

      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify(validRequestBody),
      });
      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(500);
      expect(data.error.code).toBe("INTERNAL_ERROR");
      expect(data.error.message).toBe("DB connection failed");
    });

    it("should return 500 and use error.toString() when error.stack is missing", async () => {
      // Force error with no stack
      const customError = {
        message: "Custom error without stack",
        toString: () => "CustomErrorToString()",
      };

      // Cause prisma.session.findFirst to throw that error
      prisma.session.findFirst.mockImplementation(() => {
        throw customError;
      });

      const request = new Request("http://test.com", {
        method: "POST",
        body: JSON.stringify(validRequestBody),
      });

      const response = await action({ request });
      const data = await getResponseData(response);

      expect(response.status).toBe(500);
      expect(data.success).toBe(false);
      expect(data.error.code).toBe("INTERNAL_ERROR");
      expect(data.error.message).toBe("Custom error without stack");
      expect(data.error.details).toBe(null); // since stack is undefined
      expect(logger.error).toHaveBeenCalledWith(
        expect.stringContaining("CustomErrorToString"),
      );
    });

    it("should return 500 and use fallback message when error.message is missing", async () => {
  const errorWithoutMessage = {
    toString: () => "Error without message",
    stack: "stack-trace-here",
  };

  prisma.session.findFirst.mockImplementation(() => {
    throw errorWithoutMessage;
  });

  const request = new Request("http://test.com", {
    method: "POST",
    body: JSON.stringify(validRequestBody),
  });

  const response = await action({ request });
  const data = await getResponseData(response);

  expect(response.status).toBe(500);
  expect(data.success).toBe(false);
  expect(data.error.code).toBe("INTERNAL_ERROR");
  expect(data.error.message).toBe("An unknown error occurred.");
  expect(data.error.details).toBe("stack-trace-here");
  expect(logger.error).toHaveBeenCalledWith(
    expect.stringContaining("stack-trace-here")
  );
});

  });
});
