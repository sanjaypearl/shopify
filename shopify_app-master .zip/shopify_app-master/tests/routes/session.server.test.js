import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

// --- Hoisted Mocks ---
// This code runs BEFORE the imports at the top of the file,
// which is exactly what we need.

// 1. Mock the redirect function from Remix.
const redirectFn = vi.fn();
vi.mock("@remix-run/node", async (importOriginal) => {
  const original = await importOriginal();
  return {
    ...original,
    // We mock redirect to inspect its calls without stopping the test.
    redirect: (...args) => {
      redirectFn(...args);
      // We still need to throw something to satisfy the function's contract.
      throw new Response("Redirected", {
        status: 302,
        headers: { Location: args[0] },
      });
    },
  };
});





describe("Session Management", () => {
  // --- Dynamic Import ---
  // We will import the session functions inside our tests after setting the env var.
  let getSession,
      commitSession,
      getAuthToken,
      setAuthToken,
      destroyAuthSession;

  // Store original env to avoid polluting other tests
  const originalEnv = process.env;

  beforeEach(async () => {
    // Reset mocks before each test
    vi.clearAllMocks();
    
    // Restore process.env to a clean state for each test
    process.env = { ...originalEnv };
    
    // **KEY CHANGE**: Set the environment variable *before* importing the module
    process.env.SESSION_SECRET = "default-secret-for-testing";

    // **KEY CHANGE**: Dynamically import the module AFTER setting the env var
    const sessionModule = await import("../../app/services/session.server"); // Adjust path if needed
    getSession = sessionModule.getSession;
    commitSession = sessionModule.commitSession;
    getAuthToken = sessionModule.getAuthToken;
    setAuthToken = sessionModule.setAuthToken;
    destroyAuthSession = sessionModule.destroyAuthSession;
  });

  afterEach(() => {
    // Clean up and restore original environment
    process.env = originalEnv;
  });
  
  

  describe("getAuthToken", () => {
    it("should return null if there is no session cookie", async () => {
      const request = new Request("http://localhost/");
      const token = await getAuthToken(request);
      expect(token).toBeNull();
    });

    it("should return null if the session cookie is present but contains no token", async () => {
      const session = await getSession(new Request("http://localhost/"));
      const cookie = await commitSession(session);
      const request = new Request("http://localhost/", { headers: { Cookie: cookie } });
      const token = await getAuthToken(request);
      expect(token).toBeNull();
    });

    it("should return the access token from the session cookie", async () => {
      const testToken = "test-access-token-123";
      const session = await getSession(new Request("http://localhost/"));
      session.set("accessToken", testToken);
      const cookie = await commitSession(session);
      const request = new Request("http://localhost/", { headers: { Cookie: cookie } });
      const token = await getAuthToken(request);
      expect(token).toBe(testToken);
    });
  });

  describe("setAuthToken", () => {
    it("should return headers with a Set-Cookie value and not redirect", async () => {
      const request = new Request("http://localhost/login");
      const testToken = "new-token-to-set";
      const headers = await setAuthToken(request, testToken);

      expect(redirectFn).not.toHaveBeenCalled();
      expect(headers).toBeInstanceOf(Headers);
      const cookie = headers.get("Set-Cookie");
      expect(cookie).toContain("__session=");
    });

    it("should throw a redirect response when redirectTo is provided", async () => {
      const request = new Request("http://localhost/login");
      const testToken = "another-new-token";
      const redirectTo = "/dashboard";

      await expect(setAuthToken(request, testToken, redirectTo)).rejects.toThrow();

      expect(redirectFn).toHaveBeenCalledTimes(1);
      expect(redirectFn).toHaveBeenCalledWith(
        redirectTo,
        expect.objectContaining({ headers: expect.any(Headers) })
      );
  const headers = redirectFn.mock.calls[0][1].headers;
    const cookie = headers.get("Set-Cookie");
    
    expect(cookie).toContain("__session=");
    });
  });

  describe("destroyAuthSession", () => {
    it("should throw a redirect response that destroys the cookie", async () => {
      const session = await getSession(new Request("http://localhost/"));
      session.set("accessToken", "some-token-to-destroy");
      const cookie = await commitSession(session);
      const request = new Request("http://localhost/", { headers: { Cookie: cookie } });

      await expect(destroyAuthSession(request)).rejects.toThrow();

      expect(redirectFn).toHaveBeenCalledTimes(1);
      expect(redirectFn).toHaveBeenCalledWith("/", expect.any(Object));
       const headers = redirectFn.mock.calls[0][1].headers;
    const setCookieHeader = headers["Set-Cookie"];
    expect(setCookieHeader).toBeDefined();

    // **KEY CHANGE**: Check for the 'Expires' attribute, which is how
    // this library invalidates the cookie.
    expect(setCookieHeader).toContain("Expires=Thu, 01 Jan 1970");
    });

    it("should redirect to a specified path after destroying the session", async () => {
      const request = new Request("http://localhost/");
      const redirectTo = "/login";
      await expect(destroyAuthSession(request, redirectTo)).rejects.toThrow();
      expect(redirectFn).toHaveBeenCalledWith(redirectTo, expect.any(Object));
    });
  });
});