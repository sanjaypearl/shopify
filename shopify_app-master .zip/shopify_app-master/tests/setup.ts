// tests/setup.ts

import { vi } from 'vitest';

// This replaces the real logger with a "spy" for all tests.
// The spy does nothing, so we won't see log output during tests.
// This is a great way to handle global utilities.
vi.mock('../app/logger', () => ({
  logger: {
    info: vi.fn(),
    error: vi.fn(),
  },
}));