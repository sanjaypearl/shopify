import React from "react";
import PizzaCustomizationForm from "./FoodCustomizationForms/PizzaCustomizationForm/PizzaCustomizationForm";

const FoodCustomization = () => {
  return (
    <div className="">
      <PizzaCustomizationForm />
    </div>
  );
};

export default FoodCustomization;
