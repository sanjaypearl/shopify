import { useState, useEffect } from "react";
import { toast } from "sonner";
import { instance } from "../../services/axiosInterceptor";
import { useNavigate } from "react-router-dom";

const BurgerWraps = () => {
  const [items, setItems] = useState(null);
  const navigate = useNavigate();

  async function deleteItem(id){
      const res = await instance.delete(`/burger-wraps/${id}`);
  
    if(!res?.data?.status)
    {
        toast.error("Failed To Delete !!")
        return;

    }
    await  fetchData();

    

  }

  async function fetchData()
  {
    const res = await instance.get(`/burger-wraps`);

    setItems(res?.data);
   
  }
  

  function handleEdit(id){
    navigate(`/editBurgerWraps/${id}`);
  }

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <div className="flex justify-between items-center py-4">
      <h1 className="text-2xl font-bold mb-4">Burger/Wraps</h1>
      <a href="create-burger-wraps" className="text-white bg-green-500 p-2 hover:scale-105  rounded-md" >Add Burger/Wraps</a>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full bg-white shadow-md rounded-lg">
          <thead>
            <tr className="bg-gray-200">
              <th className="py-2 px-4 text-left">Title</th>
              <th className="py-2 px-4 text-left">Type</th>
              <th className="py-2 px-4 text-left">Banner</th>
              <th className="py-2 px-4 text-left">Price</th>
              <th className="py-2 px-4 text-left">Veg/Non-Veg</th>
              <th className="py-2 px-4 text-left">Actions</th>
            </tr>
          </thead>
          <tbody>
            {items && items.length > 0 ? (
              items.map((item, index) => (
                <tr key={index} className="border-b">
                  <td className="py-2 px-4">{item.title}</td>
                  <td className="py-2 px-4">{item.metaData}</td>
                  <td className="py-2 px-4">
                    {Array.isArray(item.banner) ? (
                      <div className="flex space-x-2">
                        {item.banner.map((img, idx) => (
                          <img
                            key={idx}
                            src={img}
                            alt={`Banner ${idx}`}
                            className="h-16 w-16 object-cover rounded"
                          />
                        ))}
                      </div>
                    ) : (
                      <img
                        src={item.banner}
                        alt="Banner"
                        className="h-16 w-16 object-cover rounded"
                      />
                    )}
                  </td>
                  <td className="py-2 px-4">£{item?.price}</td>
                  <td className="py-2 px-4">{item?.isVeg ? "Veg":"Non Veg"}</td>
                  <td className="py-2 px-4">
                     <div className="flex gap-2">
                        <button className="p-2 hover:bg-green-400 bg-green-600 rounded-md text-white" onClick={()=>handleEdit(item?._id)}>Edit</button>
                        <button className="p-2 hover:bg-red-400 bg-red-600 rounded-md text-white" onClick={ ()=>  deleteItem(item?._id)}>Delete</button>
                     </div>
                  </td>

                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4" className="py-4 text-center">No data available</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default BurgerWraps;