import React, { useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { instance } from "../../services/axiosInterceptor";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

const CreateBurgerWraps = () => {
  const bannerRef = useRef(null);
  const [isLoading,setLoading] = useState(false);
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = async (data) => {
    const formData = new FormData();
    
    if (bannerRef?.current?.files[0]) {
      formData.append("banner", bannerRef.current.files[0]);
    }else{
        toast.error("Failed To Load Image !!");
        return;
    }

    formData.append('isVeg',data.category == 'VEG');
    formData.append('title',data.title);
    formData.append('metaData',data.metaData);
    formData.append('price',data.price);


    try {
        setLoading(true);
      const response = await instance.post("/burger-wraps", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      
      alert("Burger Wrap Created Successfully!");
       setLoading(false);
      navigate('/burger-wraps');
      console.log(response.data);
    } catch (error) {
        setLoading(false);
      console.error("Error creating burger wrap", error);
      alert("Failed to create burger wrap");
    }
  };

  return (
    <div className="max-w-lg mx-auto p-6 bg-white shadow-md rounded-md">
      <h2 className="text-xl font-bold mb-4">Create Burger Wrap</h2>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="mb-4">
          <label className="block text-gray-700">Title</label>
          <input
            {...register("title", { required: "Title is required" })}
            className="w-full p-2 border border-gray-300 rounded"
            placeholder="Enter title"
          />
          {errors.title && <p className="text-red-500">{errors.title.message}</p>}
        </div>

        <div className="mb-4">
          <label className="block text-gray-700">Metadata</label>
          <select
            {...register("metaData", { required: "Metadata is required" })}
            className="w-full p-2 border border-gray-300 rounded"
          >
            <option value="">Select Metadata</option>
            <option value="BURGER">BURGER</option>
            <option value="WRAP">WRAP</option>
          </select>
          {errors.metaData && <p className="text-red-500">{errors.metaData.message}</p>}
        </div>

        <div className="mb-4">
          <label className="block text-gray-700">Banner</label>
          <input type="file" name="banner" ref={bannerRef} className="w-full p-2 border border-gray-300 rounded" />
        </div>

        <div className="mb-4">
          <label className="block text-gray-700">Category</label>
          <div className="flex items-center mb-2">
            <input
              {...register("category", { required: "Please select a category" })}
              id="veg"
              type="radio"
              value="VEG"
              className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500"
            />
            <label htmlFor="veg" className="ml-2 text-sm font-medium text-gray-900">
              Veg
            </label>
          </div>
          <div className="flex items-center">
            <input
              {...register("category", { required: "Please select a category" })}
              id="nonveg"
              type="radio"
              value="NON_VEG"
              className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 focus:ring-blue-500"
            />
            <label htmlFor="nonveg" className="ml-2 text-sm font-medium text-gray-900">
              Non-Veg
            </label>
          </div>
          {errors.category && <p className="text-red-500">{errors.category.message}</p>}
        </div>

        <div className="mb-4">
          <label className="block text-gray-700">Price</label>
          <input
            type="number"
            {...register("price", { required: "Price is required", min: 1 })}
            className="w-full p-2 border border-gray-300 rounded"
            placeholder="Enter price"
          />
          {errors.price && <p className="text-red-500">{errors.price.message}</p>}
        </div>

        {isLoading ? <p>Loading ...</p> :<button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">
          Create
        </button>}
      </form>
    </div>
  );
};

export default CreateBurgerWraps;
