import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import axios from "axios";
import { instance } from "../../services/axiosInterceptor";

const EditBurgerWraps = () => {
    const { id } = useParams();
    const { register, handleSubmit, setValue, formState: { errors } } = useForm();
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchBurgerWrap = async () => {
            try {
                const response = await instance.get(`burger-wraps/${id}`);
                const { title, metaData, banner, price } = response.data;
                setValue("title", title);
                setValue("metaData", metaData);
                setValue("banner", banner);
                setValue("price", price);
                setLoading(false);
            } catch (error) {
                console.error("Error fetching burger wrap", error);
            }
        };
        fetchBurgerWrap();
    }, [id, setValue]);

    const onSubmit = async (data) => {
        try {
            await instance.put(`/burger-wraps/${id}`, data);
            alert("Burger Wrap Updated Successfully!");
        } catch (error) {
            console.error("Error updating burger wrap", error);
            alert("Failed to update burger wrap");
        }
    };

    if (loading) return <div>Loading...</div>;

    return (
        <div className="max-w-lg mx-auto p-6 bg-white shadow-md rounded-md">
            <h2 className="text-xl font-bold mb-4">Edit Burger Wrap</h2>
            <form onSubmit={handleSubmit(onSubmit)}>
                <div className="mb-4">
                    <label className="block text-gray-700">Title</label>
                    <input 
                        {...register("title", { required: "Title is required" })} 
                        className="w-full p-2 border border-gray-300 rounded"
                    />
                    {errors.title && <p className="text-red-500">{errors.title.message}</p>}
                </div>

                <div className="mb-4">
                    <label className="block text-gray-700">Metadata</label>
                    <select {...register("metaData", { required: "Metadata is required" })} 
                        className="w-full p-2 border border-gray-300 rounded">
                        <option value="BURGER">BURGER</option>
                        <option value="WRAP">WRAP</option>
                    </select>
                    {errors.metaData && <p className="text-red-500">{errors.metaData.message}</p>}
                </div>
                
                <div className="mb-4">
                    <label className="block text-gray-700">Banner URL</label>
                    <input 
                        {...register("banner", { required: "Banner URL is required" })} 
                        className="w-full p-2 border border-gray-300 rounded"
                    />
                    {errors.banner && <p className="text-red-500">{errors.banner.message}</p>}
                </div>
                
                <div className="mb-4">
                    <label className="block text-gray-700">Price</label>
                    <input 
                        type="number" 
                        {...register("price", { required: "Price is required", min: 1 })} 
                        className="w-full p-2 border border-gray-300 rounded"
                    />
                    {errors.price && <p className="text-red-500">{errors.price.message}</p>}
                </div>
                
                <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">Update</button>
            </form>
        </div>
    );
};

export default EditBurgerWraps;
