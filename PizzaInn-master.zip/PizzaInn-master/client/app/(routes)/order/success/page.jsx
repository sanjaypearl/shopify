// // app/order/success/page.jsx
// "use client";

// import { useEffect, useState, useCallback, useRef } from "react";
// import { useRouter, useSearchParams } from "next/navigation";
// import { toast } from "sonner";
// import { useDispatch } from "react-redux";
// import { emptyCart } from "@/app/lib/features/cartSlice/cartSlice";

// export default function OrderSuccessPage() {
//   const router = useRouter();
//   const searchParams = useSearchParams();
//   const dispatch = useDispatch();

//   const orderNumber = searchParams.get("orderNumber");

//   const [state, setState] = useState({
//     status: "loading",   // loading | success | failed | error
//     wpReference: "",     // optional downstream ref if you choose to expose it
//   });
//   const [countdown, setCountdown] = useState(6);
//   const timeoutRef = useRef(null);

//   // ---------------------------------------------------------------------------
//   // Payment verification – no session / token required
//   // ---------------------------------------------------------------------------
//   const verifyPayment = useCallback(async () => {
//     if (!orderNumber) {
//       setState({ status: "error", wpReference: "" });
//       toast.error("Missing order number.");
//       return;
//     }

//     try {
//       const res = await fetch(
//         `${process.env.NEXT_PUBLIC_BASE_URL}/api/v1/order/orderStatus/${orderNumber}`,
//         { method: "GET" }
//       );

//       if (!res.ok) {
//         throw new Error(`API responded ${res.status}`);
//       }

//       const data = await res.json(); // { orderStatus, paymentStatus, ... }

//       if (data.orderStatus === "Completed" && data.paymentStatus) {
//         toast.success("Payment confirmed!");
//         dispatch(emptyCart());
//         setState({
//           status: "success",
//           wpReference: data.downstreamReference || "", // if you include it
//         });

//         // start redirect countdown
//         // timeoutRef.current = setInterval(() => {
//         //   setCountdown((prev) => {
//         //     if (prev <= 1) {
//         //       clearInterval(timeoutRef.current);
//         //       router.push("/order/tracker");
//         //       return 0;
//         //     }
//         //     return prev - 1;
//         //   });
//         // }, 1000);
//       } else {
//         toast.error("Payment not confirmed or was cancelled.");
//         setState({ status: "failed", wpReference: "" });
//       }
//     } catch (err) {
//       console.error("Payment verification error:", err);
//       toast.error("Error verifying payment.");
//       setState({ status: "error", wpReference: "" });
//     }
//   }, [orderNumber, router, dispatch]);

//   useEffect(() => {
//     verifyPayment();
//     return () => {
//       if (timeoutRef.current) clearInterval(timeoutRef.current);
//     };
//   }, [verifyPayment]);

//   const handleRetry = () => {
//     setState({ status: "loading", wpReference: "" });
//     setCountdown(6);
//     verifyPayment();
//   };

//   const { status, wpReference } = state;

//   // ---------------------------------------------------------------------------
//   // UI
//   // ---------------------------------------------------------------------------
//   return (
//     <div className="max-w-xl mx-auto p-4 text-center">
//       {status === "loading" && <p>Verifying your payment…</p>}

//       {status === "success" && (
//         <>
//           <h2 className="text-2xl font-bold text-green-600">
//             Payment Successful!
//           </h2>
//           <p className="mt-2">
//             Your order <strong>#{orderNumber}</strong>
//             {wpReference && (
//               <>
//                 {" "}
//                 (ref&nbsp;<code>{wpReference}</code>)
//               </>
//             )}{" "}
//             has been confirmed.
//           </p>
//           <p className="mt-2 text-gray-600">
//             Redirecting to order tracker in {countdown} s…
//           </p>
//           <button
//             onClick={() => router.push("/order/tracker")}
//             className="mt-4 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
//           >
//             Track Order Now
//           </button>
//         </>
//       )}

//       {status === "failed" && (
//         <>
//           <p className="text-red-600">
//             Payment was not successful or was cancelled.
//           </p>
//           <button
//             onClick={handleRetry}
//             className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
//           >
//             Retry Verification
//           </button>
//         </>
//       )}

//       {status === "error" && (
//         <>
//           <p className="text-red-600">Something went wrong during verification.</p>
//           <button
//             onClick={handleRetry}
//             className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
//           >
//             Retry Verification
//           </button>
//         </>
//       )}
//     </div>
//   );
// }


"use client";

import { Suspense, useEffect, useState, useCallback, useRef } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { toast } from "sonner";
import { useDispatch } from "react-redux";
import { emptyCart } from "@/app/lib/features/cartSlice/cartSlice";

function OrderSuccessContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const dispatch = useDispatch();

  const orderNumber = searchParams.get("orderNumber");

  const [state, setState] = useState({
    status: "loading", // loading | success | failed | error
    wpReference: "",
  });
  const [countdown, setCountdown] = useState(6);
  const timeoutRef = useRef(null);

  const verifyPayment = useCallback(async () => {
    if (!orderNumber) {
      setState({ status: "error", wpReference: "" });
      toast.error("Missing order number.");
      return;
    }

    try {
      const res = await fetch(
        `${process.env.NEXT_PUBLIC_BASE_URL}/api/v1/order/orderStatus/${orderNumber}`,
        { method: "GET" }
      );

      if (!res.ok) throw new Error(`API responded ${res.status}`);

      const data = await res.json();

      if (data.orderStatus === "Completed" && data.paymentStatus) {
        toast.success("Payment confirmed!");
        dispatch(emptyCart());
        setState({
          status: "success",
          wpReference: data.downstreamReference || "",
        });
      } else {
        toast.error("Payment not confirmed or was cancelled.");
        setState({ status: "failed", wpReference: "" });
      }
    } catch (err) {
      console.error("Payment verification error:", err);
      toast.error("Error verifying payment.");
      setState({ status: "error", wpReference: "" });
    }
  }, [orderNumber, dispatch]);

  useEffect(() => {
    verifyPayment();
    return () => {
      if (timeoutRef.current) clearInterval(timeoutRef.current);
    };
  }, [verifyPayment]);

  const handleRetry = () => {
    setState({ status: "loading", wpReference: "" });
    setCountdown(6);
    verifyPayment();
  };

  const { status, wpReference } = state;

  return (
    <div className="max-w-xl mx-auto p-4 text-center">
      {status === "loading" && <p>Verifying your payment…</p>}

      {status === "success" && (
        <>
          <h2 className="text-2xl font-bold text-green-600">
            Payment Successful!
          </h2>
          <p className="mt-2">
            Your order <strong>#{orderNumber}</strong>
            {wpReference && (
              <>
                {" "}
                (ref&nbsp;<code>{wpReference}</code>)
              </>
            )}{" "}
            has been confirmed.
          </p>
          <p className="mt-2 text-gray-600">
            Redirecting to order tracker in {countdown} s…
          </p>
          <button
            onClick={() => router.push("/order/tracker")}
            className="mt-4 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
          >
            Track Order Now
          </button>
        </>
      )}

      {status === "failed" && (
        <>
          <p className="text-red-600">
            Payment was not successful or was cancelled.
          </p>
          <button
            onClick={handleRetry}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Retry Verification
          </button>
        </>
      )}

      {status === "error" && (
        <>
          <p className="text-red-600">
            Something went wrong during verification.
          </p>
          <button
            onClick={handleRetry}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Retry Verification
          </button>
        </>
      )}
    </div>
  );
}

export default function OrderSuccessPage() {
  return (
    <Suspense fallback={<p>Loading payment verification…</p>}>
      <OrderSuccessContent />
    </Suspense>
  );
}

