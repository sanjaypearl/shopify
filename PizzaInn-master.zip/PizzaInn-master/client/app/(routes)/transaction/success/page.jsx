"use client"
import { CheckCircle } from "lucide-react";
import { useRouter } from "next/navigation";

export default function page() {
  const router = useRouter();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white p-8 rounded-2xl shadow-lg flex flex-col items-center">
        <CheckCircle className="text-green-500" size={64} />
        <h1 className="text-2xl font-semibold mt-4">Transaction Successful</h1>
        <p className="text-gray-600 mt-2">Your payment has been completed successfully.</p>
        <button className="mt-6 hover:bg-green-500 text-white bg-green-600 p-2 rounded-md" onClick={() => router.push("/")}>Return to Home</button>
      </div>
    </div>
  );
}