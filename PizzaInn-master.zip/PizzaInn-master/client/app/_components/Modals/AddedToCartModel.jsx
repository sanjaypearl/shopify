import React from "react";

const AddedToCartModel = ({ isAddClicked, setIsAddClicked }) => {
  return (
    <div>
      <div
        id="popup-modal"
        tabindex="-1"
        class={`${
          isAddClicked ? "flex" : "hidden"
        }  overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full shadow-lg `}
      >
        <div class="relative p-4 w-full max-w-md max-h-full ">
          <div class="relative bg-white rounded-lg shadow-[0_10px_20px_rgba(240,_46,_170,_0.7)]  shadow-lg">
            <button
              onClick={() => setIsAddClicked(false)}
              type="button"
              class="absolute top-3 end-2.5 text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
              data-modal-hide="popup-modal"
            >
              <svg
                class="w-3 h-3 text-[#c80f2e]"
                aria-hidden="true"
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 14 14"
              >
                <path
                  stroke="currentColor"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"
                />
              </svg>
              <span class="sr-only">Close modal</span>
            </button>
            <div class="p-4 md:p-5 flex justify-center flex-col items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="100"
                height="100"
                viewBox="0 0 24 24"
              >
                <path d="M10 19.5c0 .829-.672 1.5-1.5 1.5s-1.5-.671-1.5-1.5c0-.828.672-1.5 1.5-1.5s1.5.672 1.5 1.5zm3.5-1.5c-.828 0-1.5.671-1.5 1.5s.672 1.5 1.5 1.5 1.5-.671 1.5-1.5c0-.828-.672-1.5-1.5-1.5zm1.336-5l1.977-7h-16.813l2.938 7h11.898zm4.969-10l-3.432 12h-12.597l.839 2h13.239l3.474-12h1.929l.743-2h-4.195z" />
              </svg>
              <h3 class="mb-5 text-lg font-normal text-black dark:text-gray-400">
                Added to Cart!
              </h3>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddedToCartModel;
