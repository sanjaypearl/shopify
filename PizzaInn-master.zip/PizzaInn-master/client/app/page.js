import React from "react";
import HomePage from "./_components/HomePage/HomePage";


const page = () => {
  
  return (
    <div>
      <HomePage />
    </div>
  );
};

export default page;
