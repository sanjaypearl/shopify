import express from "express";
import { upload } from "../configs/cloudinary.js";
import { deleteDessert, getAllDesserts, newDessert, updateDessert } from "../controllers/dessert/dessert.js";
import { deleteCategory, getAllCategory, newCategory, updateCategory } from "../controllers/dessert/dessertCategory.js";
import {deleteFilter, getAllDessertFilter,newFilter, updateFilter} from "../controllers/dessert/dessertFilter.js"
import { verifyAdminToken } from "../utils/VerifyAdmin.js";

const router = express.Router();

//dessert
router.route("/").get(getAllDesserts).post(upload.single("banner"), newDessert);
router.route("/:id").patch(verifyAdminToken(["admin"]) , upload.single("banner"), updateDessert).delete(verifyAdminToken(["admin"])  , deleteDessert);

//category
router.route("/category").get(getAllCategory).post(newCategory);
router.route("/category/:id").delete(verifyAdminToken(["admin"])  , deleteCategory).patch(verifyAdminToken(["admin"])  , updateCategory);


//filter
router.route("/filter").get(getAllDessertFilter).post(verifyAdminToken(["admin"]) ,newFilter)
router.route("/filter/:id").delete(verifyAdminToken(["admin"])  ,deleteFilter).patch(verifyAdminToken(["admin"]) ,updateFilter);

export default router;
