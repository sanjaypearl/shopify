import express from "express";
const router = express.Router();
import { newDips,getAllDips, updateDips, deleteDips } from "../controllers/dips.js";
import { upload } from "../configs/cloudinary.js";
import { verifyAdminToken } from "../utils/VerifyAdmin.js";

router.route("/").get(getAllDips).post(verifyAdminToken(["admin"]) , upload.single("banner"),newDips)
router.route("/:id").delete(verifyAdminToken(["admin"])  , deleteDips).patch(verifyAdminToken(["admin"])  ,upload.single("banner"),updateDips)

export default router;
