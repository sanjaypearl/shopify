import express from "express"
import { deleteBanner, getAllBanners, newbanner, updateBanner } from "../controllers/banner.js";
import { upload } from "../configs/cloudinary.js";
import { verifyAdminToken } from "../utils/VerifyAdmin.js";


const router = express.Router();

router.route("/").get(getAllBanners).post(verifyAdminToken(["admin"])  , upload.single("banner"),newbanner)
router.route("/:id").patch(verifyAdminToken(["admin"])  , upload.single("banner"),updateBanner).delete(verifyAdminToken(["admin"])  , deleteBanner)

export default router