// import express from "express";
// import { transactionCreatedWebHook, verifyTransaction, webhookResponse } from "../controllers/order.js";


// const router = express.Router();

// router.route("/transactionCreatedWebhook").get(transactionCreatedWebHook).post(webhookResponse)
// router.route('/verifyTransaction').get(verifyTransaction).post(verifyTransaction)


// export default router;


import express from "express";
import { transactionCreatedWebHook, verifyOrderByWorldpay, verifyTransaction, webhookResponse } from "../controllers/order.js";
import { verifySignature } from "../utils/worldpay.js";


const router = express.Router();

router.route("/transactionCreatedWebhook").get(transactionCreatedWebHook).post(webhookResponse)
router.route('/verifyTransaction').get(verifyTransaction).post(verifyTransaction)
router.route('/verifyOrder').post(verifyOrderByWorldpay)


export default router;

