import express from "express";
const router = express.Router();
import { upload } from "../../configs/cloudinary.js";
import { createNewPizza, deletePizza, getAllPizza, updatePizza } from "../../controllers/pizza/pizza.js";
import { deleteCategory, getAllCategory, newCategory, updateCategory } from "../../controllers/pizza/pizzaCategory.js";
import { deleteFilter, getAllFilter, newFilter, updateFilter } from "../../controllers/pizza/pizzaFilter.js";
import { verifyAdminToken } from "../../utils/VerifyAdmin.js";

//pizza
router.route("/").get(getAllPizza).post(verifyAdminToken(["admin"])  , upload.single("banner"),  createNewPizza);
router.route("/:id").patch(verifyAdminToken(["admin"])  ,  upload.single("banner"), updatePizza).delete( verifyAdminToken(["admin"])   , deletePizza);

//category
router.route("/category").get(getAllCategory).post(newCategory);
router.route("/category/:id").delete(verifyAdminToken(["admin"]) , deleteCategory).patch(verifyAdminToken(["admin"]) ,updateCategory);


//filter
router.route("/filter").get(getAllFilter).post(newFilter)
router.route("/filter/:id").delete(verifyAdminToken(["admin"]) , deleteFilter).patch(verifyAdminToken(["admin"]) , updateFilter);

export default router;