// import express from "express";
// import { upload } from "../configs/cloudinary.js";
// import { deleteSides, getAllSides, newSides, updateSides } from "../controllers/sides/sides.js";
// import {
//   deleteCategory,
//   getAllCategory,
//   newCategory,
//   updateCategory,
// } from "../controllers/sides/sidesCategory.js";
// import { deleteFilter, getAllSidesFilter, newFilter, updateFilter } from "../controllers/sides/sidesFilter.js";

// const router = express.Router();

// //sides
// router.route("/").get(getAllSides).post(upload.single("banner"), newSides);
// router.route("/:id").patch(upload.single("banner"), updateSides).delete(deleteSides);

// //category
// router.route("/category").get(getAllCategory).post(newCategory);
// router.route("/category/:id").delete(deleteCategory).patch(updateCategory);

// //filter
// router.route("/filter").get(getAllSidesFilter).post(newFilter)
// router.route("/filter/:id").delete(deleteFilter).patch(updateFilter);

// export default router;



import express from "express";
import { upload } from "../configs/cloudinary.js";

import {
  deleteSides,
  getAllSides,
  newSides,
  updateSides,
} from "../controllers/sides/sides.js";

import {
  deleteCategory,
  getAllCategory,
  newCategory,
  updateCategory,
} from "../controllers/sides/sidesCategory.js";

import {
  deleteFilter,
  getAllSidesFilter,
  newFilter,
  updateFilter,
} from "../controllers/sides/sidesFilter.js";
import { verifyAdminToken } from "../utils/VerifyAdmin.js";


const router = express.Router();

//
// 🔓 Public Route (Optional, can add auth if needed)
router.route("/").get(getAllSides);

// 🔒 Admin-only: Create/Update/Delete Sides
router
  .route("/")
  .post(verifyAdminToken(["admin"]), upload.single("banner"), newSides);

router
  .route("/:id")
  .patch(verifyAdminToken(["admin"]), upload.single("banner"), updateSides)
  .delete(verifyAdminToken(["admin"]), deleteSides);

//
// Category Routes
router
  .route("/category")
  .get(getAllCategory)
  .post(verifyAdminToken(["admin"]), newCategory);

router
  .route("/category/:id")
  .patch(verifyAdminToken(["admin"]), updateCategory)
  .delete(verifyAdminToken(["admin"]), deleteCategory);

//
// Filter Routes
router
  .route("/filter")
  .get(getAllSidesFilter)
  .post(verifyAdminToken(["admin"]), newFilter);

router
  .route("/filter/:id")
  .patch(verifyAdminToken(["admin"]), updateFilter)
  .delete(verifyAdminToken(["admin"]), deleteFilter);

export default router;

