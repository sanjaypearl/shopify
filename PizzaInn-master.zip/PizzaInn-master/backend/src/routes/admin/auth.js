import express from "express";
import { adminLogin, adminSignup } from "../../controllers/admin/auth.js";

const router = express.Router();

router.route("/signup").post(adminSignup);
router.route("/").post(adminLogin);


export default router;
