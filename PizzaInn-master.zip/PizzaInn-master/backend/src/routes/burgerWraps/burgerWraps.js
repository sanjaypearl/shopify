import express from "express";
import {
  createBurgerWrap,
  deleteBurgerWrap,
  getBurgerWrapById,
  getBurgerWraps,
  updateBurgerWrap,
} from "../../controllers/burgerWraps/burgerWraps.js";
import { upload } from "../../configs/cloudinary.js";
import { verifyAdminToken } from "../../utils/VerifyAdmin.js";
const router = express.Router();

// Routes
router
  .route("/")
  .get(getBurgerWraps)
  .post(verifyAdminToken(["admin"]), upload.single("banner"), createBurgerWrap);
router
  .route("/:id")
  .get(getBurgerWrapById)
  .put( upload.single("banner"),verifyAdminToken(["admin"]) , updateBurgerWrap)
  .delete(deleteBurgerWrap);

export const burgerWrapsRouter = router;
