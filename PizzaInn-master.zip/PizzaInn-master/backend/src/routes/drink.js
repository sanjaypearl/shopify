import express from "express";
import { deleteDrink, getAllDrink, newDrink, updateDrink } from "../controllers/drink.js";
import { upload } from "../configs/cloudinary.js";
import { verifyAdminToken } from "../utils/VerifyAdmin.js";
const router = express.Router();

router.route("/").get(getAllDrink).post(verifyAdminToken(["admin"])  , upload.single("banner"), newDrink);
router.route("/:id").delete(verifyAdminToken(["admin"]) ,deleteDrink).patch(verifyAdminToken(["admin"])  , upload.single("banner"), updateDrink);

export default router;
