import express from 'express';
import { createDeal, deleteDeal, getAllDeals, getDeal, updateDeal } from '../../controllers/deals/deals.js';
import { upload } from '../../configs/cloudinary.js';
import { verifyAdminToken } from '../../utils/VerifyAdmin.js';

const dealsRoutes = express.Router();

dealsRoutes.route('/')
    .get(getAllDeals)
    .post(verifyAdminToken(["admin"]) , upload.single('banner'),createDeal);

dealsRoutes.route('/:id')
    .get(getDeal)
    .patch( verifyAdminToken(["admin"]),upload.single('banner'),updateDeal)
    .delete(verifyAdminToken(["admin"]) ,deleteDeal);

export default dealsRoutes;
