// import express from "express";
// import {
//   checkTransaction,
//   createOrder,
//   getAllOrders,
//   getOrderFromOrderCode,
//   getParticularUserOrders,
//   newOrder,
//   onlineOrder,
//   updateCompleteOrder,
// } from "../controllers/order.js";

// const router = express.Router();
// router.route("/createOrder").post(createOrder);
// router.route("/:userId").get(getParticularUserOrders);
// router.route("/").post(newOrder).get(getAllOrders);
// router.route("/:id").patch(updateCompleteOrder);
// router.route("/create-viva-order").post(onlineOrder);
// router.route("/checkTransaction/:transactionId").get(checkTransaction);
// router.route("/getFromOrderCode/:orderCode").get(getOrderFromOrderCode);


// export default router;


import express from "express";
import {
  checkTransaction,
  createOrder,
  getAllOrders,
  getOrderFromOrderCode,
  getParticularUserOrders,
  newOrder,
  onlineOrder,
  updateCompleteOrder,
  getOrderStatus,
} from "../controllers/order.js";
import { verifyAdminToken } from "../utils/VerifyAdmin.js";

const router = express.Router();

router.route("/createOrder").post(createOrder);
router.route("/orderStatus/:orderNumber").get(getOrderStatus);
router.route("/:userId").get(getParticularUserOrders);
router.route("/").post(newOrder).get(getAllOrders);
router.route("/:id").patch(updateCompleteOrder);
router.route("/create-viva-order").post(onlineOrder);

// ✅ Admin-only routes
router
  .route("/")
  .post(newOrder)
  .get(verifyAdminToken(["admin"]), getAllOrders);
router.route("/:id").patch(verifyAdminToken(["admin"]), updateCompleteOrder);
router
  .route("/checkTransaction/:transactionId")
  .get(verifyAdminToken(["admin"]), checkTransaction);
router
  .route("/getFromOrderCode/:orderCode")
  .get(verifyAdminToken(["admin"]), getOrderFromOrderCode);

// ✅ Accessible to user
router.route("/:userId").get(getParticularUserOrders);

export default router;
