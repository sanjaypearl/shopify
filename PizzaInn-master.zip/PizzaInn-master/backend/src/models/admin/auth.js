import mongoose from "mongoose";

const adminSchema = new mongoose.Schema(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: true,
    },
    role: {
      type: String,
      default: "user", // Default role set to 'user'
      enum: ["user", "admin"], // Optional: limit values for role
    },
  },
  { timestamps: true }
);

// Export model
export const admin = mongoose.model("adminSchma", adminSchema);
