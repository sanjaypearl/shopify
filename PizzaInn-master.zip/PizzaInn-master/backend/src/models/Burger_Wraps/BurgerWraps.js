import mongoose from "mongoose";


const BurgerWrapsSchema = new mongoose.Schema({
    title:{
        type:String,
        required:true,
        unique:true
    },
    metaData:{
        type:String,
        required:[true,"Type Is Required Field !!"],
        enum:['BURGER','WRAP']
    },
    isVeg:{
      type:Boolean,
      default:true,
      required:[true,"Is Veg Is Required Field "]
    },
    banner: { type: String, required: true },
    price:  { type: Number, required: true },
},{
    timestamps:true
});


export const BurgerWrapsModel = new mongoose.model('BurgerWraps',BurgerWrapsSchema);