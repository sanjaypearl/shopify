// ------------------------------------------------Imports-----------------------------------------------

// -----------------------------------------------------------------------------------------------------------

// -----------------------------------------------------------------------------------------------------------

// envAccess -- function to access the environment variables
export const envAccess = (field) => {
  return process.env[field];
};

// -----------------------------------------------------------------------------------------------------------
// ----------------------------------------------CORS CONFIG---------------------------------------------

export const developmentWhiteListedIpAddresses = [
  "http://localhost:5173",
  "http://localhost:5174 ",
  "https://hot-house-9gco.vercel.app/",
  "https://hot-house.vercel.app/",
  "http://localhost:3000",
  "https://6d3b-103-99-15-226.ngrok-free.app",
  "34.246.73.11",
  "52.215.22.123",
  "52.31.61.0",
  "18.130.125.132",
  "35.176.91.145",
  "52.56.235.128",
  "18.185.7.67",
  "18.185.134.117",
  "18.185.158.215",
  "52.48.6.187",
  "34.243.65.63",
  "3.255.13.18",
  "3.251.36.74",
  "63.32.208.6",
  "52.19.45.138",
  "3.11.50.124",
  "3.11.213.43",
  "3.14.190.43",
  "3.121.172.32",
  "3.125.11.252",
  "3.126.98.120",
  "3.139.153.185",
  "3.139.255.63",
  "13.200.51.10",
  "13.200.56.25",
  "13.232.151.127",
  "34.236.63.10",
  "34.253.172.98",
  "35.170.209.108",
  "35.177.246.6",
  "52.4.68.25",
  "52.51.12.88",
  "108.129.30.203"

];

export const productionWhiteListedIpAddresses = ["https://hot-house.vercel.app/"];

export const corsConfig = () => {
  return envAccess("NODE_WORKING_ENVIRONMENT")
    ? {
        origin: developmentWhiteListedIpAddresses,
        credentials: true,
        allowedHeaders: ["Content-Type", "Authorization", "x-csrf-token"],
        methods: ["GET", "PUT", "POST", "PATCH", "DELETE"],
        exposedHeaders: ["*", "Authorization"],
      }
    : {
        origin: productionWhiteListedIpAddresses,
        credentials: true,
        allowedHeaders: ["Content-Type", "Authorization", "x-csrf-token"],
        methods: ["GET", "PUT", "POST", "PATCH", "DELETE"],
        exposedHeaders: ["*", "Authorization"],
      };
};
// -----------------------------------------------------------------------------------------------------------
// --------------------------------------------PIZZA CUSTOMIZATION---------------------------------------------

export const pizzaCustomization = {
  pizzaSizes: ["SUPER_SIZE", "LARGE", "MEDIUM", "SMALL"],
  pizzaBases: [
    "CHEEZY_CRUST",
    "DEEP_PAN",
    "HOT_DOG_CRUST",
    "PEPPERONI_CRUST",
    "THIN_CRUST",
  ],
  pizzaSauces: [
    "BBQ_SAUCE",
    "GARLIC_SAUCE",
    "HOT_BBQ_SAUCE",
    "SMOKY_SAUSAGE",
    "TOMATO_SAUCE",
    "NO_SAUCE",
  ],
  pizzaCheeses: ["3_BLEND_CHEESE", "MOZZARELLA", "NO_CHEESE"],
  pizzaVegToppings: [
    "BLACK_OLIVES",
    "CHILLI_FLAKES",
    "FETA_CHEESE",
    "FRESH_TOMATO",
    "GREEN_CHILLI",
    "GREEN_PEPPER",
    "JALAPENO",
    "MUSHROOMS",
    "MUSTARD_MAYO",
    "PINEAPPLE",
    "RED_ONION",
    "ROQUITO",
    "SLICED_GHERKIN",
    "SPECIAL_BURGER_SAUCE",
    "SPINACH",
    "SUN_DRIED_TOMATO",
    "SWEETCORN",
    "TOMATO_KETCHUP",
  ],
  pizzaMeatToppings: [
    "BACON",
    "BEEF",
    "CHICKEN",
    "CHICKEN_TIKKA",
    "CHORIZO_SAUSAGE",
    "GERMAN_HOT_DOG",
    "HAM",
    "MEATBALLS",
    "MEXICAN_CHICKEN",
    "PEPPERONI",
    "PERI_PERI_CHICKEN",
    "SALAMI",
    "SPICY_PORK",
    "TANDOORI_CHICKEN",
    "TURKEY_HAM",
  ],
  pizzaSeafoodToppings: ["ANCHOVY", "PRAWNS", "TUNA"],
};

// -----------------------------------------------------------------------------------------------------------
