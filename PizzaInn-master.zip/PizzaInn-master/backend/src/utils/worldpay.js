import axios from "axios";
import { v4 as uuidv4 } from "uuid";

const baseURL =
  process.env.NODE_WORKING_ENVIRONMENT === "development"
    ? process.env.WORLDPAY_DEVELOPMENT_URL
    : process.env.WORLDPAY_PRODUCTION_URL;

const worldpay = axios.create({
  baseURL,
  auth: {
    username: process.env.WORLDPAY_API_KEY,
    password: process.env.WORLDPAY_SECRET_KEY,
  },
  headers: {
    "Content-Type": "application/vnd.worldpay.payment_pages-v1.hal+json",
    Accept: "application/vnd.worldpay.payment_pages-v1.hal+json",
  },
});

export async function createWorldpayPaymentPage({
  amount,
  currency,
  description,
  transactionReference,
  narrative = "PizzaInno",
  successURL,
  failureURL,
  cancelURL,
}) {
  const payload = {
    transactionReference,
    merchant: { entity: process.env.WORLDPAY_ENTITY },
    narrative: { line1: narrative },
    value: { currency, amount },
    description,
    resultURLs: {
      successURL,
      failureURL,
      cancelURL,
    },
  };

  const { data } = await worldpay.post("/payment_pages", payload, {
    headers: {
      "WP-CorrelationId": uuidv4(),
    },
  });

  if (!data?.url) {
    throw new Error("Worldpay response missing 'url' property.");
  }

  return data.url;
}

export function verifySignature(req, res, next) {
  const signature = req.headers["x-wp-signature"];
  const payload = JSON.stringify(req.body);

  const expectedSignature = crypto
    .createHmac("sha256", WORLD_PAY_SECRET)
    .update(payload)
    .digest("hex");

  if (signature !== expectedSignature) {
    return res.status(403).send("Invalid signature");
  }

  next();
}
