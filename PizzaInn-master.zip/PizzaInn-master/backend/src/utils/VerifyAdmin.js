import jwt from "jsonwebtoken";
import { admin } from "../models/admin/auth.js"; // Make sure the path and `.js` are correct

export const verifyAdminToken = (requiredRoles = []) => {
  return async (req, res, next) => {
    try {
      // ✅ Read token from cookie
      const token = req.cookies?.adminToken;

      if (!token) {
        return res.status(401).json({ message: "Unauthorized: No token provided" });
      }

      // ✅ Verify token
      const decoded = jwt.verify(token, process.env.ADMIN_SECRET);

      // ✅ Fetch admin
      const foundAdmin = await admin.findById(decoded.id);
      if (!foundAdmin) {
        return res.status(401).json({ message: "Unauthorized: Admin not found" });
      }

      // ✅ Role check
      if (requiredRoles.length > 0 && !requiredRoles.includes(foundAdmin.role)) {
        return res.status(403).json({ message: "Forbidden: Insufficient permissions" });
      }

      // ✅ Attach to request
      req.admin = {
        id: foundAdmin._id,
        email: foundAdmin.email,
        role: foundAdmin.role,
      };

      next();
    } catch (error) {
      console.error("Token verification error:", error);
      return res.status(401).json({ message: "Invalid or expired token" });
    }
  };
};
