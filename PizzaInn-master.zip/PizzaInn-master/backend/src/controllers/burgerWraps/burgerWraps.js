// @desc    Get all burger wraps
// @route   GET /api/burger-wraps

import { BurgerWrapsModel } from "../../models/Burger_Wraps/BurgerWraps.js";
import { asyncErrorHandler } from "../../utils/errors/asyncErrorHandler.js";

// @access  Public
export const getBurgerWraps = asyncErrorHandler(async (req, res) => {
  const burgerWraps = await BurgerWrapsModel.find();
  res.status(200).json(burgerWraps);
});

// @desc    Get a single burger wrap by ID
// @route   GET /api/burger-wraps/:id
// @access  Public
export const getBurgerWrapById = asyncErrorHandler(async (req, res) => {
  const burgerWrap = await BurgerWrapsModel.findById(req.params.id);
  if (!burgerWrap) {
    res.status(404);
    throw new Error("Burger wrap not found");
  }
  res.status(200).json(burgerWrap);
});

// @desc    Create a new burger wrap
// @route   POST /api/burger-wraps
// @access  Private/Admin
export const createBurgerWrap = asyncErrorHandler(async (req, res) => {
  const { title, metaData, price, isVeg } = req.body;

  if (!title || !metaData || !req?.file?.path || !price) {
    res.status(400);
    throw new Error("All fields are required");
  }

  await BurgerWrapsModel.create({
    title,
    metaData,
    banner: req?.file?.path,
    price,
    isVeg,
  });
  res.status(201).json({ status: true, message: "Data Created Successfully" });
});

// @desc    Update a burger wrap
// @route   PUT /api/burger-wraps/:id
// @access  Private/Admin
export const updateBurgerWrap = asyncErrorHandler(async (req, res) => {
  const { title, metaData, price } = req.body;
  console.log("reached");

  const query = {};
  if (req?.file?.path) {
    query.banner = req?.file?.path;
  }
  const updatedBurgerWrap = await BurgerWrapsModel.findByIdAndUpdate(
    req.params.id,
    { title, metaData, price, ...query },
    { new: true, runValidators: true }
  );

  if (!updatedBurgerWrap) {
    res.status(404);
    throw new Error("Burger wrap not found");
  }

  res.status(200).json({
    status: true,
    message: "Data Updated Successfully",
    updatedBurgerWrap,
  });
});

// @desc    Delete a burger wrap
// @route   DELETE /api/burger-wraps/:id
// @access  Private/Admin
export const deleteBurgerWrap = asyncErrorHandler(async (req, res) => {
  const burgerWrap = await BurgerWrapsModel.findById(req.params.id);
  if (!burgerWrap) {
    res.status(404);
    throw new Error("Burger wrap not found");
  }

  await burgerWrap.deleteOne();
  res.status(200).json({ status: true, message: "Burger wrap removed" });
});
