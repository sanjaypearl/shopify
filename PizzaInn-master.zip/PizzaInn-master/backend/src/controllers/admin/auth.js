// import { admin } from "../../models/admin/auth.js";
// import { asyncErrorHandler } from "../../utils/errors/asyncErrorHandler.js";
// import bcrypt from "bcrypt";

// // -------------------admin signup-------------------------
// export const adminSignup = asyncErrorHandler(async (req, res) => {
//   const { email, password } = req?.body;
//   const hashedPassword = await bcrypt.hash(password, 10);
//   const newAdmin = new admin({
//     email,
//     password: hashedPassword,
//   });
//   newAdmin.save();
//   res.status(201).send("success");
// });
import { admin } from "../../models/admin/auth.js";
import { asyncErrorHandler } from "../../utils/errors/asyncErrorHandler.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

// ------------------- Admin Signup -------------------------
export const adminSignup = asyncErrorHandler(async (req, res) => {
  const { email, password } = req.body;

  const existingAdmin = await admin.findOne({ email });
  if (existingAdmin) {
    return res.status(400).json({ message: "Admin already exists" });
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  const newAdmin = new admin({
    email,
    password: hashedPassword,
    role: "user", // default role
  });

  await newAdmin.save();

  res.status(201).json({ message: "Admin registered successfully" });
});


// ------------------- Admin Login -------------------------


export const adminLogin = asyncErrorHandler(async (req, res) => {
  const { userName, password } = req.body;

  const existingAdmin = await admin.findOne({ email:userName });
  console.log("existing " , existingAdmin)
  if (!existingAdmin) {
    return res.status(401).json({ message: "Invalid email nhi h  or password" });
  }

  const isMatch = await bcrypt.compare(password, existingAdmin.password);
  if (!isMatch) {
    return res.status(401).json({ message: "Invalid email or password" });
  }

  // Generate JWT token
  const token = jwt.sign(
    {
      id: existingAdmin._id,
      email: existingAdmin.email,
      role: existingAdmin.role,
    },
    process.env.ADMIN_SECRET,
    { expiresIn: "1d" }
  );

  // Set JWT as cookie
  res.cookie("adminToken", token, {
    httpOnly: true,                     // Not accessible by JavaScript
    secure: process.env.NODE_ENV === "production", // Only over HTTPS in prod
    sameSite: "Strict",                 // Prevent CSRF
    maxAge: 24 * 60 * 60 * 1000,        // 1 day
  });

  res.status(200).json({
    message: "Login successful",
    sucess:true,
    admin: {
      id: existingAdmin._id,
      email: existingAdmin.email,
      role: existingAdmin.role,
    },
  });
});
