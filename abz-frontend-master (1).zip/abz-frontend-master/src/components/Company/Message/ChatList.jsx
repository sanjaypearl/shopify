"use client";

import { useState } from "react";
import { MdSend } from "react-icons/md";

const dummyChats = [
  {
    id: "1",
    name: "Sarah Chen",
    image: "https://randomuser.me/api/portraits/women/44.jpg",
    lastMessage: "I've found a critical vulnerability in the...",
    time: "10:23 AM",
    messages: [
      {
        from: "Sarah Chen",
        time: "Yesterday, 4:32 PM",
        content:
          "Hello Alex, I’ve found a critical vulnerability in the authentication system...",
      },
      {
        from: "Sarah Chen",
        time: "Yesterday, 4:35 PM",
        content:
          "I've attached the proof of concept and detailed steps to reproduce...",
      },
      {
        from: "You",
        time: "Yesterday, 8:15 PM",
        content:
          "Thank you for reporting this, Sarah. I’ve forwarded the details to our security team...",
      },
      {
        from: "Sarah Chen",
        time: "Today, 9:45 AM",
        content:
          "This vulnerability seems to be in the OAuth implementation specifically...",
      },
      {
        from: "Sarah Chen",
        time: "Today, 10:23 AM",
        content: "Should I submit it as a separate report or include it here?",
      },
    ],
  },
  {
    id: "2",
    name: "Marcus Johnson",
    image: "https://randomuser.me/api/portraits/men/45.jpg",
    lastMessage: "Regarding the SQL injection issue in the...",
    time: "Yesterday",
    messages: [],
  },
  {
    id: "3",
    name: "Elena Rodriguez",
    image: "https://randomuser.me/api/portraits/women/46.jpg",
    lastMessage: "Can you provide more details about the...",
    time: "Oct 12",
    messages: [],
  },
  {
    id: "4",
    name: "David Kim",
    image: "https://randomuser.me/api/portraits/men/47.jpg",
    lastMessage: "I've submitted my report for the API...",
    time: "Oct 10",
    messages: [],
  },
  {
    id: "5",
    name: "Aisha Patel",
    image: "https://randomuser.me/api/portraits/women/48.jpg",
    lastMessage: "Thank you for approving my bounty...",
    time: "Oct 8",
    messages: [],
  },
];

export default function ChatPage() {
  const [selectedChat, setSelectedChat] = useState(null);
  const [message, setMessage] = useState("");

  return (
    <div className="flex h-screen text-sm font-sans">
      {/* Sidebar */}
      <div className="w-1/3 border-r  border-gray-300 p-3  bg-gray-100">
        <input
          type="text"
          placeholder="Search conversations..."
          className="w-full px-3 py-2 border bg-white rounded-md border-gray-400 mb-3 text-sm"
        />
        <div className="flex gap-2 mb-3 p-3 bg-white">
          <button className="px-4 py-1.5 bg-gray-600 text-white text-sm font-medium rounded-md shadow-sm">
            All
          </button>
          <button className="px-4 py-1.5 border border-gray-500 text-gray-800 text-sm font-medium rounded-md">
            Unread
          </button>
          <button className="px-4 py-1.5 border border-gray-500 text-gray-800 text-sm font-medium rounded-md">
            Programs
          </button>
        </div>

        <div>
          {dummyChats.map((chat) => (
            <div
              key={chat.id}
              onClick={() => setSelectedChat(chat)}
              className={`flex w-80 items-start gap-3 p-2 pr-2 mb-2 bg-white rounded-md cursor-pointer hover:bg-gray-200 ${
                selectedChat?.id === chat.id ? "bg-gray-100" : ""
              }`}
            >
              <img
                src={chat.image}
                alt={chat.name}
                className="w-10 h-10 rounded-full object-cover"
              />
              <div className="flex-1">
                <div className="flex justify-between font-semibold">
                  <span>{chat.name}</span>
                  <span className="text-gray-500 text-xs">{chat.time}</span>
                </div>
                <div className="text-gray-600 text-sm truncate">
                  {chat.lastMessage}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat Container */}
      <div className="flex-1 flex flex-col bg-gray-200 relative">
        {selectedChat ? (
          <>
            <div className="border-b border-gray-200 p-4 bg-white flex items-center gap-3">
              <img
                src={selectedChat.image}
                alt={selectedChat.name}
                className="w-10 h-10 rounded-full object-cover"
              />
              <div>
                <div className="font-medium text-base">{selectedChat.name}</div>
                <div className="text-xs text-gray-500">
                  Security Researcher • Web Application Program
                </div>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
              {selectedChat.messages.map((msg, index) => (
                <div
                  key={index}
                  className={`flex items-start gap-2 max-w-[75%] ${
                    msg.from === "You" ? "ml-auto flex-row-reverse" : ""
                  }`}
                >
                  <img
                    src={
                      msg.from === "You"
                        ? "https://randomuser.me/api/portraits/men/32.jpg"
                        : selectedChat.image
                    }
                    alt={msg.from}
                    className="w-8 h-8 rounded-full  object-cover mt-1"
                  />
                  <div>
                    <div
                      className={`p-3 rounded-md border-gray-100 whitespace-pre-wrap shadow-sm text-sm ${
                        msg.from === "You"
                          ? "bg-blue-100 text-right"
                          : "bg-white border"
                      }`}
                    >
                      <p>{msg.content}</p>
                      {msg.attachment && (
                        <div className="mt-2 flex items-center text-sm text-red-600">
                          📎{" "}
                          <span className="ml-1 underline">
                            {msg.attachment}
                          </span>
                        </div>
                      )}
                    </div>
                    <div
                      className={`text-xs text-gray-500 mt-1 ${
                        msg.from === "You" ? "text-right" : ""
                      }`}
                    >
                      {msg.time}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className=" p-3 bg-white flex items-center gap-2 sticky bottom-0">
              <input
                type="text"
                placeholder="Type your message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="flex-1 p-2 ml-10 border rounded-md text-sm"
              />
              <button className="p-2 text-blue-600">
                <MdSend className="w-5 h-5" />
              </button>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-400">
            Select a conversation to start chatting
          </div>
        )}
      </div>
    </div>
  );
}
