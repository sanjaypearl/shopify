import React, { useEffect, useState } from 'react';
import DataService from '@/services/Axios/axiosInterceptor';

const ReportList = ({ onClose }) => {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchReports = async () => {
    try {
      setLoading(true);
      const response = await DataService.getAllReports();
      setReports(response.data?.data || []);
    } catch (error) {
      console.error('Error fetching reports:', error);
      setError('Failed to fetch reports.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  return (
    <div className="fixed inset-0 flex justify-center items-center z-50">
      <div className="bg-white w-full max-w-3xl p-6 rounded-lg shadow-lg border border-gray-300 relative">
        {/* Modal Header */}
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Submitted Reports</h2>
          <button
            className="text-gray-500 hover:text-gray-700 text-xl"
            onClick={onClose}
            aria-label="Close"
          >
            ✖
          </button>
        </div>

        {/* Content */}
        {loading && <p className="text-gray-500">Loading reports...</p>}
        {error && <p className="text-red-500">{error}</p>}

        {!loading && !error && (
          <>
            {reports.length === 0 ? (
              <p className="text-gray-600">No reports found.</p>
            ) : (
              <div className="max-h-[400px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-blue-400 scrollbar-track-gray-200">
                <ul className="space-y-3">
                  {reports.map((report) => (
                    <li
                      key={report._id}
                      className="p-4 border border-gray-200 rounded-md bg-gray-50"
                    >
                      <div className="font-medium text-blue-600">
                        {report.reportTitle || 'Untitled'}
                      </div>
                      <div className="text-sm text-gray-700 capitalize">
                        Status: {report.status || 'Pending'}
                      </div>
                      <div className="text-xs text-gray-500">
                        Submitted on:{' '}
                        {report.createdAt
                          ? new Date(report.createdAt).toLocaleDateString()
                          : 'N/A'}
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </>
        )}

        {/* Footer */}
        <div className="mt-6 flex justify-end">
          <button
            className="bg-gray-200 hover:bg-gray-300 text-gray-800 px-4 py-2 rounded-md text-sm"
            onClick={onClose}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default ReportList;
