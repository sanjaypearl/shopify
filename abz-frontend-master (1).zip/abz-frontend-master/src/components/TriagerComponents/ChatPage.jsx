

"use client";

import { useState } from "react";
import { MdSend } from "react-icons/md";
import { FaFilePdf, FaFileAlt } from "react-icons/fa";

const dummyChats = [
  {
    id: "1",
    name: "Alex Morgan",
    role: "Researcher · Acme Security",
    image: "https://randomuser.me/api/portraits/men/32.jpg",
    time: "10:23 AM",
    priority: "High",
    status: "open",
    lastMessage: "I've attached the additional logs you requested...",
       messages: [
      {
        from: "Alex Morgan",
        time: "Monday, 9:47 AM",
        content:
          "Hi Sarah, I’m reaching out regarding a critical vulnerability I discovered in your API authentication mechanism.",
      },
      {
        from: "Sarah Chen",
        time: "Monday, 10:12 AM",
        content:
          "Thanks for bringing this to our attention, Alex. Could you provide more details?",
      },
      {
        from: "Alex Morgan",
        time: "Monday, 10:30 AM",
        content: "The vulnerability affects the /api/v2/auth endpoint.",
        attachment: {
          name: "Vulnerability_Report_CVE-2023-45678.pdf",
          size: "2.4 MB",
          type: "pdf",
        },
      },
      {
        from: "Sarah Chen",
        time: "Monday, 11:05 AM",
        content:
          "We confirmed the vulnerability. Could you share the server logs?",
      },
      {
        from: "Alex Morgan",
        time: "Monday, 11:48 AM",
        content: "Attached logs for CVE-2023-45678.",
        attachment: {
          name: "exploit_logs.txt",
          size: "1.2 MB",
          type: "txt",
        },
      },
    ],
  },
  {
    id: "2",
    name: "Maria Rodriguez",
    role: "Security Engineer · TechDefend",
    image: "https://randomuser.me/api/portraits/women/47.jpg",
    time: "Yesterday",
    priority: "Medium",
    status: "closed",
    lastMessage: "Thanks for the quick response...",
    messages: [
      {
        from: "Maria Rodriguez",
        time: "Yesterday, 3:10 PM",
        content: "Thanks for the quick response...",
      },
    ],
  },
  {
    id: "3",
    name: "James Wilson",
    role: "Researcher · Independent",
    image: "https://randomuser.me/api/portraits/men/52.jpg",
    time: "Yesterday",
    priority: "High",
    status: "open",
    lastMessage: "I've discovered a potential SQL injection vulnerability...",
    messages: [
      {
        from: "James Wilson",
        time: "Yesterday, 2:25 PM",
        content: "SQL injection vulnerability in the login form...",
      },
    ],
  },
  {
    id: "4",
    name: "SecureTech Inc.",
    role: "Vendor",
    image: "https://randomuser.me/api/portraits/lego/1.jpg",
    time: "Monday",
    priority: "Low",
    status: "closed",
    lastMessage: "We’ve reviewed the report and would like to schedule a call...",
    messages: [
      {
        from: "SecureTech Inc.",
        time: "Monday, 4:45 PM",
        content: "We’d like to schedule a call...",
      },
    ],
  },
];

export default function ChatPage() {
  const [selectedChat, setSelectedChat] = useState(null);
  const [message, setMessage] = useState("");
  const [threadType, setThreadType] = useState("open"); // 'open' or 'closed'

  const filteredChats = dummyChats.filter((chat) => chat.status === threadType);

  return (
    <div className="flex h-screen text-sm font-sans">
      {/* Sidebar */}
      <div className="w-72 border-r border-gray-300 bg-gray-100 flex flex-col">
        <h3 className="px-3 pt-3 font-bold">Messages</h3>
        <div className="p-3">
          <input
            type="text"
            placeholder="Search conversations..."
            className="w-full px-3 py-2 border border-gray-300 bg-white rounded-md text-sm"
          />
        </div>

        {/* Toggle Buttons */}
        <div className="flex justify-around text-xs font-medium mb-2">
          <button
            onClick={() => setThreadType("open")}
            className={`px-3 py-2 border-b-2 ${
              threadType === "open" ? "border-gray-600 text-black" : "border-transparent text-gray-500"
            }`}
          >
            Open Threads
          </button>
          <button
            onClick={() => setThreadType("closed")}
            className={`px-3 py-2 border-b-2 ${
              threadType === "closed" ? "border-gray-600 text-black" : "border-transparent text-gray-500"
            }`}
          >
            Closed Threads
          </button>
        </div>

        {/* Chat List */}
        <div className="flex-1 overflow-y-auto p-2">
          {filteredChats.map((chat) => (
            <div
              key={chat.id}
              onClick={() => setSelectedChat(chat)}
              className={`flex items-start gap-3 px-3 py-3 bg-white cursor-pointer hover:bg-gray-200 rounded ${
                selectedChat?.id === chat.id ? "bg-gray-100" : ""
              }`}
            >
              <img src={chat.image} alt={chat.name} className="w-10 h-10 rounded-full object-cover" />
              <div className="flex-1 pb-3">
                <div className="flex justify-between font-semibold text-sm">
                  <span>{chat.name}</span>
                  <span className="text-xs text-gray-400">{chat.time}</span>
                </div>
                <div className="text-xs text-gray-500">{chat.role}</div>
                <div className="text-xs text-gray-600 mt-1 line-clamp-2">
                  {chat.lastMessage}
                </div>
                <div className="mt-1">
                  <span className="inline-block text-[10px] px-2 py-0.5 rounded-full font-semibold bg-white border border-gray-500">
                    {chat.priority} Priority
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat Container */}
      <div className="flex-1 flex flex-col bg-gray-100 relative">
        {selectedChat ? (
          <>
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-gray-300 bg-gray-100">
              <div className="flex gap-3 items-center">
                <img
                  src={selectedChat.image}
                  alt={selectedChat.name}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <div className="font-medium text-sm">{selectedChat.name}</div>
                  <div className="text-xs text-gray-500">{selectedChat.role}</div>
                </div>
              </div>
              <div className="space-x-2 text-xs text-gray-800">
                <button className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-white border border-gray-500">
                  Call
                </button>
                <button className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-white border border-gray-500">
                  Video
                </button>
                <button className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-white border border-gray-500">
                  Settings
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4 bg-gray-50">
              {selectedChat.messages.map((msg, index) => (
                <div
                  key={index}
                  className={`flex items-start bg-white gap-3 max-w-[75%] ${
                    msg.from === "Sarah Chen" ? "ml-auto flex-row-reverse" : ""
                  }`}
                >
                  <img
                    src={
                      msg.from === "Sarah Chen"
                        ? "https://randomuser.me/api/portraits/women/44.jpg"
                        : selectedChat.image
                    }
                    alt={msg.from}
                    className="w-8 h-8 rounded-full object-cover mt-1"
                  />
                  <div>
                    <div
                      className={`p-3 rounded-md text-sm shadow-sm whitespace-pre-wrap ${
                        msg.from === "Sarah Chen" ? "bg-blue-100 text-right" : "bg-white"
                      }`}
                    >
                      <p className="text-gray-800">{msg.content}</p>
                      {msg.attachment && (
                        <div className="mt-2 flex items-center justify-between bg-gray-100 rounded px-3 py-2 text-xs">
                          <div className="flex items-center gap-2 text-gray-700">
                            {msg.attachment.type === "pdf" ? (
                              <FaFilePdf className="text-red-500" />
                            ) : (
                              <FaFileAlt className="text-blue-500" />
                            )}
                            <div>
                              <div className="font-medium">{msg.attachment.name}</div>
                              <div className="text-gray-500 text-xs">{msg.attachment.size}</div>
                            </div>
                          </div>
                          <button className="text-blue-600 text-xs font-semibold">Download</button>
                        </div>
                      )}
                    </div>
                    <div
                      className={`text-xs text-gray-500 mt-1 ${
                        msg.from === "Sarah Chen" ? "text-right" : ""
                      }`}
                    >
                      {msg.time}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Input */}
            <div className="bg-white p-3 flex items-center gap-2 sticky bottom-0 border-t border-gray-300">
              <input
                type="text"
                placeholder="Type your message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="flex-1 px-4 py-2 border rounded-md border-gray-300 text-sm focus:outline-none"
              />
              <button className="px-3 py-2 border rounded-md border-blue-600 bg-blue-500 text-white">
               Send
              </button>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-400">
            Select a conversation to start chatting
          </div>
        )}
      </div>
    </div>
  );
}

