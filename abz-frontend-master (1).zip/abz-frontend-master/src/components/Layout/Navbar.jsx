"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Menu, X } from "lucide-react";

export default function Header() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <header className="bg-gray-900 text-white font-medium shadow-sm w-full relative">
      <div className="max-w-8xl mx-auto px-4 py-4 flex items-center justify-between">
        {/* Left: Logo */}
        <Link href="/" className="flex items-center gap-2 flex-shrink-0">
          {/* Desktop/Laptop Logo */}
          <Image
            src="/CyberNeoGen-02.png"
            alt="CyberNeoGen Logo"
            width={200}
            height={240}
            priority
            className="hidden md:block"
          />
          {/* Mobile/Tablet Logo */}
          <Image
            src="/CyberNeoGen-03.png"
            alt="CyberNeoGen Mobile Logo"
            width={40}
            height={40}
            priority
            className="block md:hidden"
          />
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-6 mx-auto">
          <Link
            href="/"
            className="text-base font-semibold hover:text-blue-400 transition"
          >
            Home
          </Link>
          <Link
            href="/explore"
            className="text-base font-semibold hover:text-blue-400 transition"
          >
            Explore
          </Link>
          <Link
            href="/blog"
            className="text-base font-semibold hover:text-blue-400 transition"
          >
            Blog
          </Link>
          <Link
            href="/about"
            className="text-base font-semibold hover:text-blue-400 transition"
          >
            About Us
          </Link>
          <Link
            href="/contact"
            className="text-base font-semibold hover:text-blue-400 transition"
          >
            Contact
          </Link>
        </nav>

        {/* Desktop Auth Buttons */}
        <div className="hidden md:flex items-center border-0 gap-3 flex-shrink-0">
          <Link
            href="/login"
            className="px-4 py-1.5 text-base border border-white/30 rounded-full hover:bg-white/10 transition"
          >
            Sign In
          </Link>
          <Link
            href="/signup"
            className="px-4 py-1.5 text-base bg-blue-600 hover:bg-blue-700 rounded-full transition"
          >
            Sign Up
          </Link>
        </div>

        {/* Mobile Menu Icon */}
        <button
          onClick={() => setSidebarOpen(true)}
          className="block md:hidden text-white focus:outline-none"
        >
          <Menu size={28} />
        </button>
      </div>

      {/* Mobile Sidebar */}
      <div
        className={`fixed inset-0 bg-black/50 z-40 transform transition-opacity duration-300 ease-in-out ${
          sidebarOpen ? "opacity-100 visible" : "opacity-0 invisible"
        }`}
        onClick={() => setSidebarOpen(false)}
      />

      <div
        className={`fixed top-0 left-0 h-full w-64 bg-gray-900 z-50 transform transition-transform duration-300 ease-in-out ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Sidebar Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <Image
            src="/CyberNeoGen-03.png"
            alt="Sidebar Logo"
            width={40}
            height={40}
            priority
          />
          <button
            onClick={() => setSidebarOpen(false)}
            className="text-white focus:outline-none"
          >
            <X size={24} />
          </button>
        </div>

        {/* Sidebar Nav */}
        <nav className="flex flex-col p-4 space-y-4">
          <Link
            href="/"
            onClick={() => setSidebarOpen(false)}
            className="text-lg hover:text-blue-400 transition"
          >
            Home
          </Link>
          <Link
            href="/explore"
            onClick={() => setSidebarOpen(false)}
            className="text-lg hover:text-blue-400 transition"
          >
            Explore
          </Link>
          <Link
            href="/blog"
            onClick={() => setSidebarOpen(false)}
            className="text-lg hover:text-blue-400 transition"
          >
            Blog
          </Link>
          <Link
            href="/about"
            onClick={() => setSidebarOpen(false)}
            className="text-lg hover:text-blue-400 transition"
          >
            About Us
          </Link>
          <Link
            href="/contact"
            onClick={() => setSidebarOpen(false)}
            className="text-lg hover:text-blue-400 transition"
          >
            Contact
          </Link>
        </nav>

        {/* Sidebar Auth Buttons */}
        <div className="p-4 flex flex-col gap-3">
          <Link
            href="/login"
            onClick={() => setSidebarOpen(false)}
            className="px-4 py-2 border border-white/30 rounded-full hover:bg-white/10 transition text-center"
          >
            Sign In
          </Link>
          <Link
            href="/signup"
            onClick={() => setSidebarOpen(false)}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-full transition text-center"
          >
            Sign Up
          </Link>
        </div>
      </div>
    </header>
  );
}
