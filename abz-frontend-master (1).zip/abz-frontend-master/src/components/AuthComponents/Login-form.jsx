"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useDispatch } from "react-redux";
import { login } from "@/store/actions/Auth/authActions";
import Image from "next/image";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function LoginPage() {
  const router = useRouter();
  const dispatch = useDispatch();

  const [formData, setFormData] = useState({
    email: "",
    password: "",
    rememberMe: false,
  });

  const [isLoading, setIsLoading] = useState(false);

  // Handle input change
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  // Handle form submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const user = await dispatch(login(formData)).unwrap();

      if (user) {
        localStorage.setItem("user", JSON.stringify(user));
        localStorage.setItem("token", user.token);

        toast.success("Login successful!", { position: "top-right" });

        // Redirect based on role
        setTimeout(() => {
          switch (user.data.role) {
            case "admin":
              router.push("/admin");
              break;
            case "company":
              router.push("/company");
              break;
            case "researcher":
              router.push("/researcher");
              break;
            case "treasurer":
              router.push("/triager");
              break;
            default:
              router.push("/unauthorized");
          }
        }, 1500);
      }
    } catch (err) {
      const errorMsg =
        err?.response?.data?.message || err?.message || "Invalid email or password";
      toast.error(errorMsg, { position: "top-right" });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Background Image */}
      <div
        className="hidden lg:flex lg:w-2/3 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('/cyber-bg.png')",
        }}
      ></div>

      {/* Login Panel */}
      <div className="w-full lg:w-1/3 flex items-center justify-center p-8 bg-gray-50">
        <div className="w-full max-w-sm">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <div className="w-8 h-8 bg-indigo-900 rounded-full flex items-center justify-center mr-1">
                <Image
                  src="/CyberNeoGen-03.png"
                  alt="Logo"
                  width={24}
                  height={24}
                />
              </div>
              <h1 className="text-xl font-bold text-gray-800">CyberNeoGen</h1>
            </div>
            <p className="text-sm text-gray-600">
              Sign in to access your dashboard
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Username
              </label>
              <input
                type="email"
                name="email"
                placeholder="Enter your username"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <input
                type="password"
                name="password"
                placeholder="Enter your password"
                value={formData.password}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            {/* Remember Me & Forgot Password */}
            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center text-gray-700">
                <input
                  type="checkbox"
                  name="rememberMe"
                  checked={formData.rememberMe}
                  onChange={handleChange}
                  className="w-4 h-4 text-blue-500 border-gray-300 rounded focus:ring-blue-500"
                />
                <span className="ml-2">Remember me</span>
              </label>
              <a href="#" className="text-blue-500 hover:underline">
                Forgot Password?
              </a>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className={`w-full py-2 px-4 rounded font-semibold text-white transition-colors ${
                isLoading
                  ? "bg-blue-300 cursor-not-allowed"
                  : "bg-blue-500 hover:bg-blue-600"
              }`}
            >
              {isLoading ? "Signing In..." : "Sign In"}
            </button>

            {/* Signup Link */}
            <div className="text-center pt-4">
              <p className="text-sm text-gray-600">
                New Here?{" "}
                <a
                  href="/signup"
                  className="text-blue-500 hover:text-blue-600 font-medium"
                >
                  Signup
                </a>
              </p>
              <p className="text-xs text-gray-500 mt-2">
                Want to setup a program on our platform?{" "}
                <a href="#" className="text-blue-500 hover:text-blue-600">
                  Join Us
                </a>
              </p>
            </div>
          </form>
        </div>
      </div>

      {/* Toast container for popups */}
      <ToastContainer position="top-right" autoClose={3000} />
    </div>
  );
}
