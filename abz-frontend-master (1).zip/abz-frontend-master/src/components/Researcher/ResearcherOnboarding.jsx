"use client";

import Image from "next/image";
import Link from "next/link";

export default function OnboardingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            {/* Header */}
            <div className="space-y-4">
              <h1 className="text-5xl font-bold text-gray-900">
                Welcome to <span className="text-blue-600">CyberNeoGen</span>
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Your gateway to cutting-edge cybersecurity research and rewards
              </p>
              <p className="text-lg text-gray-500">
                Join our community of elite researchers and help secure the
                digital world while earning competitive rewards for your
                discoveries.
              </p>
            </div>

            {/* Features */}
            <div className="space-y-6">
              {/* Intuitive Dashboard */}
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                  <svg
                    className="w-6 h-6 text-white"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                    />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Intuitive Dashboard
                  </h3>
                  <p className="text-gray-600">
                    Track your progress, manage active programs, and view your
                    performance metrics all in one place.
                  </p>
                </div>
              </div>

              {/* Diverse Programs */}
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                  <svg
                    className="w-6 h-6 text-white"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                    />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Diverse Programs
                  </h3>
                  <p className="text-gray-600">
                    Access a wide range of security programs from leading
                    companies across various industries.
                  </p>
                </div>
              </div>

              {/* Streamlined Reporting */}
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                  <svg
                    className="w-6 h-6 text-white"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                    />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Streamlined Reporting
                  </h3>
                  <p className="text-gray-600">
                    Submit vulnerability reports easily with our structured
                    templates and real-time feedback system.
                  </p>
                </div>
              </div>

              {/* Earnings Tracking */}
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                  <svg
                    className="w-6 h-6 text-white"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    Earnings Tracking
                  </h3>
                  <p className="text-gray-600">
                    Monitor your bounties, rewards, and payment history with
                    comprehensive financial analytics.
                  </p>
                </div>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex space-x-4">
              <Link
                href="/researcher"
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors"
              >
                Get Started
              </Link>
              <button className="border border-gray-300 hover:border-gray-400 text-gray-700 px-8 py-3 rounded-lg font-semibold transition-colors">
                Learn More
              </button>
            </div>
          </div>

          {/* Right Content - Dashboard Preview */}
          <div className="relative">
            <Image
              src="/onboarding.png"
              alt="CyberNeoGen Dashboard Preview"
              className="w-full h-auto rounded-lg shadow-2xl"
              width={1000}
              height={1000}
            />

            {/* Stats Callout */}
            <div className="absolute -bottom-6 -left-6 bg-blue-50 border border-blue-200 rounded-lg p-4 shadow-lg">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                  <svg
                    className="w-4 h-4 text-white"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path
                      fillRule="evenodd"
                      d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <div>
                  <p className="text-sm text-blue-800 font-medium">
                    Join over{" "}
                    <span className="font-bold">5,000 researchers</span> who
                    have the collectively identified{" "}
                    <span className="font-bold">12,000+ vulnerabilities</span>{" "}
                    and earned more than{" "}
                    <span className="font-bold">$8.5M in bounties</span>.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Testimonials Section */}
      <div className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            What Our Researchers Say
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <div className="flex items-center space-x-4 mb-4">
                <Image
                  src="/male1.png"
                  alt="Marcus Chen"
                  className="w-12 h-12 rounded-full"
                  width={240}
                  height={240}
                />
                <div>
                  <h4 className="font-semibold text-gray-900">Marcus Chen</h4>
                  <p className="text-sm text-gray-600">
                    Senior Security Researcher
                  </p>
                </div>
              </div>
              <p className="text-gray-700 mb-4">
                "CyberNeoGen's platform streamlined my workflow and increased my
                productivity by 40%. The clear program guidelines and responsive
                team made vulnerability reporting a breeze."
              </p>
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <svg
                    key={i}
                    className="w-4 h-4 fill-current"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
            </div>

            {/* Testimonial 2 */}
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <div className="flex items-center space-x-4 mb-4">
                <Image
                  src="/female.png"
                  alt="Sophia Rodriguez"
                  className="w-12 h-12 rounded-full"
                  width={240}
                  height={240}
                />
                <div>
                  <h4 className="font-semibold text-gray-900">
                    Sophia Rodriguez
                  </h4>
                  <p className="text-sm text-gray-600">Bug Bounty Hunter</p>
                </div>
              </div>
              <p className="text-gray-700 mb-4">
                "As a newcomer to bug bounties, CyberNeoGen provided the perfect
                starting point with their mentorship program and educational
                resources. I earned my first bounty within two weeks!"
              </p>
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <svg
                    key={i}
                    className="w-4 h-4 fill-current"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
            </div>

            {/* Testimonial 3 */}
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <div className="flex items-center space-x-4 mb-4">
                <Image
                  src="/male2.png"
                  alt="Jamal Washington"
                  className="w-12 h-12 rounded-full"
                  width={240}
                  height={240}
                />
                <div>
                  <h4 className="font-semibold text-gray-900">
                    Jamal Washington
                  </h4>
                  <p className="text-sm text-gray-600">Security Engineer</p>
                </div>
              </div>
              <p className="text-gray-700 mb-4">
                "The analytics dashboard gives me incredible insights into my
                performance. I can track my progress, identify my strengths, and
                focus on areas where I can improve my skills."
              </p>
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <svg
                    key={i}
                    className="w-4 h-4 fill-current"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
