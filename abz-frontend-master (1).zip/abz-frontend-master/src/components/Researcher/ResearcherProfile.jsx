import {
  User,
  Settings,
  BarChart3,
  DollarSign,
  Award,
  Star,
  Shield,
  CheckCircle,
  Clock,
  Target,
  Linkedin,
  Twitter,
  Github,
  Youtube,
  Users,
} from "lucide-react";

export default function ResearcherProfile() {
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-gray-900">My Profile</h1>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-md bg-white hover:bg-gray-50 text-gray-700">
            <Settings className="h-4 w-4" />
            Edit Settings
          </button>
          <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md">
            Dashboard
          </button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        {/* Left Column - Profile Info */}
        <div className="col-span-4 space-y-6">
          {/* Profile Card */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-6">
              <div className="text-center">
                <div className="relative inline-block">
                  <div className="relative">
                    <img
                      src="../images/profileimg1.png"
                      alt="Alex Rivera"
                      className="h-40 w-40 rounded-full mx-auto mb-4 object-cover"
                    />
                    <div className="absolute -bottom-2 -right-1 bottom-5 bg-blue-600 rounded-full p-1">
                      <CheckCircle className="h-3 w-3 text-white" />
                    </div>
                  </div>
                </div>

                <h2 className="text-lg font-bold text-gray-900 mb-1">
                  Alex Rivera
                </h2>
                <p className="text-blue-600 font-medium mb-4 text-sm">
                  Researcher
                </p>

                {/* Social Links */}
                <div className="flex justify-center gap-2 mb-6">
                  <div className="bg-blue-600 rounded-full p-1.5">
                    <Linkedin className="h-5 w-5 text-white" />
                  </div>
                  <div className="bg-gray-600 rounded-full p-1.5">
                    <Github className="h-5 w-5 text-white" />
                  </div>
                  <div className="bg-blue-400 rounded-full p-1.5">
                    <Twitter className="h-5 w-5 text-white" />
                  </div>
                  <div className="bg-red-600 rounded-full p-1.5">
                    <Youtube className="h-5 w-5 text-white" />
                  </div>
                </div>

                {/* Member Info */}
                <div className="text-left space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Member </span>
                    <span className="text-gray-900">March 2021</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Last Seen</span>
                    <span className="text-gray-900">Today</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Reputation</span>
                    <div className="flex items-center gap-1">
                      <Star className="h-3 w-3 text-yellow-500 fill-current" />
                      <span className="text-gray-900">4.9/5</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Main Content */}
        <div className="col-span-8 space-y-6">
          {/* About Me */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold flex items-center gap-2 text-black">
                <User className="h-5 w-5 text-blue-500" />
                About Me
              </h3>
            </div>
            <div className="p-6">
              <p className="text-gray-700 mb-6 text-sm">
                Cybersecurity professional with over 5 years of experience in
                vulnerability research and penetration testing. Specialized in
                web application security, API security, and cloud
                infrastructure. Passionate about finding security flaws and
                helping organizations improve their security posture.
              </p>

              <div className="grid grid-cols-2 gap-8">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">Skills</h4>
                  <div className="flex flex-wrap gap-2">
                    <span className="inline-block px-2 py-1 text-xs border border-blue-200 text-blue-600 rounded-full">
                      Web Security
                    </span>
                    <span className="inline-block px-2 py-1 text-xs border border-blue-200 text-blue-600 rounded-full">
                      API Testing
                    </span>
                    <span className="inline-block px-2 py-1 text-xs border border-blue-200 text-blue-600 rounded-full">
                      Cloud Security
                    </span>
                    <span className="inline-block px-2 py-1 text-xs border border-blue-200 text-blue-600 rounded-full">
                      Mobile Security
                    </span>
                    <span className="inline-block px-2 py-1 text-xs border border-blue-200 text-blue-600 rounded-full">
                      Network Penetration
                    </span>
                    <span className="inline-block px-2 py-1 text-xs border border-blue-200 text-blue-600 rounded-full">
                      DevOps Top 10
                    </span>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-3">
                    Certifications
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    <span className="inline-block px-2 py-1 text-xs border border-blue-200 text-blue-600 rounded-full">
                      CISCP
                    </span>
                    <span className="inline-block px-2 py-1 text-xs border border-blue-200 text-blue-600 rounded-full">
                      CEH
                    </span>
                    <span className="inline-block px-2 py-1 text-xs border border-blue-200 text-blue-600 rounded-full">
                      CISSP
                    </span>
                    <span className="inline-block px-2 py-1 text-xs border border-blue-200 text-blue-600 rounded-full">
                      AWS Security Specialist
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Performance Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Performance Stats */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-semibold flex items-center gap-2 text-gray-700">
                  <BarChart3 className="h-5 w-5 text-blue-500" />
                  Performance Stats
                </h3>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-blue-50 p-4 rounded-lg text-center">
                    <div className="text-2xl font-bold text-blue-600">87</div>
                    <div className="text-xs text-gray-600">
                      Reports Submitted
                    </div>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg text-center">
                    <div className="text-2xl font-bold text-blue-600">64</div>
                    <div className="text-xs text-gray-600">
                      Reports Accepted
                    </div>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg text-center">
                    <div className="text-2xl font-bold text-blue-600">73%</div>
                    <div className="text-xs text-gray-600">Acceptance Rate</div>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg text-center">
                    <div className="text-2xl font-bold text-blue-600">12</div>
                    <div className="text-xs text-gray-600">
                      Critical Findings
                    </div>
                  </div>
                </div>

                {/* Chart placeholder */}
                <div className="h-32 bg-gray-50 rounded-lg overflow-hidden relative flex items-center justify-center">
                  <svg className="w-full h-full" viewBox="0 0 300 100">
                    <polyline
                      fill="none"
                      stroke="#3B82F6"
                      strokeWidth="2"
                      points="20,80 60,60 100,70 140,50 180,40 220,30 260,20"
                    />
                    <polyline
                      fill="none"
                      stroke="#F59E0B"
                      strokeWidth="2"
                      points="20,85 60,75 100,65 140,55 180,45 220,35 260,25"
                    />
                  </svg>
                </div>
              </div>
            </div>

            {/* Earnings Summary */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-semibold flex items-center gap-2 text-gray-700">
                  <DollarSign className="h-5 w-5 text-blue-500" />
                  Earnings Summary
                </h3>
              </div>
              <div className="p-6">
                <div className="text-3xl font-bold text-gray-900">$42,750</div>
                <div className="text-sm text-gray-600 mb-4">
                  Total Bounties Earned
                </div>
                <div className="text-lg font-semibold text-blue-600">
                  $8,500
                </div>
                <div className="text-sm text-gray-600 mb-6">Last 30 Days</div>

                {/* Bounty Distribution */}
                <h4 className="text-md font-semibold text-gray-900 mb-4">
                  Bounty Distribution
                </h4>
                <div className="flex items-center justify-center">
                  <div className="w-32 h-32 rounded-full bg-gray-200 relative overflow-hidden">
                    {/* Fake pie chart - replace with real chart if needed */}
                    <div
                      className="absolute inset-0 bg-blue-500"
                      style={{
                        clipPath:
                          "polygon(50% 50%, 50% 0%, 100% 0%, 100% 100%, 50% 100%)",
                      }}
                    />
                    <div
                      className="absolute inset-0 bg-orange-400"
                      style={{
                        clipPath: "polygon(50% 50%, 100% 100%, 50% 100%)",
                      }}
                    />
                    <div
                      className="absolute inset-0 bg-green-400"
                      style={{
                        clipPath: "polygon(50% 50%, 50% 100%, 0% 100%, 0% 50%)",
                      }}
                    />
                    <div
                      className="absolute inset-0 bg-gray-400"
                      style={{
                        clipPath: "polygon(50% 50%, 0% 50%, 0% 0%, 50% 0%)",
                      }}
                    />
                  </div>
                </div>

                {/* Legend */}
                <div className="flex flex-wrap justify-center gap-4 text-xs mt-4">
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                    <span>Critical (45%)</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-orange-400 rounded-full"></div>
                    <span>High (30%)</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                    <span>Medium (20%)</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-gray-400 rounded-full"></div>
                    <span>Low (5%)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Achievements & Badges */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold flex items-center gap-2 text-blue-600">
                <Award className="h-5 w-5" />
                Achievements & Badges
              </h3>
            </div>
            <div className="p-6">
              <div className="flex px-4 justify-between">
                <div className="text-center">
                  <div className="w-12 h-12 bg-yellow-500 rounded-full flex items-center justify-center mb-2">
                    <Star className="h-6 w-6 text-white" />
                  </div>
                  <div className="text-xs text-gray-600">Top Researcher</div>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-gray-400 rounded-full flex items-center justify-center mb-2">
                    <Shield className="h-6 w-6 text-white" />
                  </div>
                  <div className="text-xs text-gray-600">Bug Hunter</div>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center mb-2">
                    <Target className="h-6 w-6 text-white" />
                  </div>
                  <div className="text-xs text-gray-600">Security Expert</div>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mb-2">
                    <CheckCircle className="h-6 w-6 text-white" />
                  </div>
                  <div className="text-xs text-gray-600">Fast Reporter</div>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mb-2">
                    <Clock className="h-6 w-6 text-white" />
                  </div>
                  <div className="text-xs text-gray-600">1 Year Club</div>
                </div>
              </div>
            </div>
          </div>

          {/* Social Links */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            {/* Header */}
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-semibold flex items-center gap-2 text-gray-700">
                <Users className="h-5 w-5 text-blue-500" />
                Social Links
              </h3>
            </div>

            {/* Links */}
            <div className="p-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* LinkedIn */}
                <div className="flex items-center gap-3 border border-gray-200 rounded-lg px-3 py-2">
                  <Linkedin className="h-5 w-5 text-blue-600" />
                  <div>
                    <div className="text-xs text-gray-500">LinkedIn</div>
                    <div className="text-sm text-gray-800 break-all">
                      linkedin.com/in/alexrivera
                    </div>
                  </div>
                </div>

                {/* GitHub */}
                <div className="flex items-center gap-3 border border-gray-200 rounded-lg px-3 py-2">
                  <Github className="h-5 w-5 text-gray-800" />
                  <div>
                    <div className="text-xs text-gray-500">GitHub</div>
                    <div className="text-sm text-gray-800 break-all">
                      github.com/alexrivera-security
                    </div>
                  </div>
                </div>

                {/* Twitter */}
                <div className="flex items-center gap-3 border border-gray-200 rounded-lg px-3 py-2">
                  <Twitter className="h-5 w-5 text-sky-500" />
                  <div>
                    <div className="text-xs text-gray-500">Twitter</div>
                    <div className="text-sm text-gray-800 break-all">
                      twitter.com/alexrivera_sec
                    </div>
                  </div>
                </div>

                {/* YouTube */}
                <div className="flex items-center gap-3 border border-gray-200 rounded-lg px-3 py-2">
                  <Youtube className="h-5 w-5 text-red-600" />
                  <div>
                    <div className="text-xs text-gray-500">YouTube</div>
                    <div className="text-sm text-gray-800 break-all">
                      youtube.com/c/AlexRiveraSecurity
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
