"use client";
import { useState } from "react";
import { UploadCloud } from "lucide-react";
import { useDispatch, useSelector } from "react-redux";
import { createReport, fetchReports } from "@/store/actions/reportAction";
import { toast } from "react-toastify";
import {
  FaExclamationTriangle,
  FaFire,
  FaShieldAlt,
  FaInfoCircle,
  FaPlus,
  FaTimes,
  FaEdit,
  FaCheck,
  FaFileAlt,
  FaClipboardList,
  FaBug,
  FaUpload,
  FaLightbulb,
  FaGlobe,
  FaToggleOn,
  FaToggleOff,
} from "react-icons/fa";

export default function ResearcherSubmitReportForm() {
  const dispatch = useDispatch();
  const { createStatus, createError } = useSelector((state) => state.report);

  const [showSeverityCalculator, setShowSeverityCalculator] = useState(false);

  // match backend field names
  const [form, setForm] = useState({
    program: "",
    reportTitle: "",
    vulnerabilityType: "",
    severity: "",
    impact_description: "", // renamed for better flow
    reproduction_steps: "",
    vulnerability_details: "",
    affected_asset: "",
    file: null,
    confirm: false,
  });

  const vulnerabilityTypes = [
    // Injection Flaws
    "SQL Injection",
    "NoSQL Injection",
    "LDAP Injection",
    "Command Injection",
    "Code Injection",
    "XPath Injection",
    "XML Injection",
    "Header Injection",

    // Cross-Site Scripting
    "Reflected XSS",
    "Stored XSS",
    "DOM-based XSS",
    "Blind XSS",

    // Authentication & Session Management
    "Broken Authentication",
    "Session Fixation",
    "Session Hijacking",
    "Weak Password Policy",
    "Account Takeover",
    "Multi-Factor Authentication Bypass",

    // Access Control
    "Broken Access Control",
    "IDOR (Insecure Direct Object Reference)",
    "Privilege Escalation",
    "Missing Authorization",
    "Path Traversal",

    // Security Misconfiguration
    "Security Misconfiguration",
    "Default Credentials",
    "Information Disclosure",
    "Debug Information Exposure",
    "HTTP Security Headers Missing",

    // Cryptographic Issues
    "Weak Cryptography",
    "Insecure Cryptographic Storage",
    "Insufficient Transport Layer Security",
    "Weak Random Number Generation",

    // Business Logic
    "Business Logic Flaw",
    "Race Condition",
    "Time-of-Check Time-of-Use (TOCTOU)",
    "Insufficient Process Validation",

    // Input Validation
    "Input Validation Bypass",
    "File Upload Vulnerability",
    "XXE (XML External Entity)",
    "CSV Injection",
    "Template Injection",

    // Web Application Specific
    "CSRF (Cross-Site Request Forgery)",
    "SSRF (Server-Side Request Forgery)",
    "Open Redirect",
    "Clickjacking",
    "CORS Misconfiguration",

    // API Security
    "API Security Misconfiguration",
    "GraphQL Vulnerabilities",
    "REST API Vulnerabilities",
    "Rate Limiting Bypass",

    // Mobile & Client-Side
    "Mobile Application Vulnerability",
    "Client-Side Enforcement",
    "Insecure Data Storage",
    "Insufficient Binary Protection",

    // Infrastructure
    "Network Security Vulnerability",
    "DNS Security Issue",
    "SSL/TLS Vulnerability",
    "Server Misconfiguration",

    // Other
    "Social Engineering",
    "Physical Security",
    "Denial of Service (DoS)",
    "Other",
  ];

  const predefinedDomains = {
    "SecureTech Cloud": [
      "api.securetech.com",
      "dashboard.securetech.com",
      "admin.securetech.com",
      "cdn.securetech.com",
      "auth.securetech.com",
    ],
    "RetailShield E-commerce": [
      "shop.retailshield.com",
      "api.retailshield.com",
      "checkout.retailshield.com",
      "admin.retailshield.com",
      "cdn.retailshield.com",
    ],
    "FinGuard Banking": [
      "secure.finguard.com",
      "api.finguard.com",
      "mobile.finguard.com",
      "admin.finguard.com",
      "portal.finguard.com",
    ],
  };

  const handleChange = (e) => {
    const { name, value, type, checked, files } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]:
        type === "checkbox" ? checked : type === "file" ? files[0] : value,
    }));

    if (name === "program" && value && predefinedDomains[value]) {
      const domains = predefinedDomains[value];
      setInScopeAssets(
        domains.map((domain) => ({ type: "Domain/Subdomain", value: domain }))
      );
      toast.success(`Auto-loaded ${domains.length} domains for ${value}`);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("program", form.program);
    formData.append("reportTitle", form.reportTitle);
    formData.append("vulnerabilityType", form.vulnerabilityType);
    formData.append("severity", form.severity);
    formData.append("impact_description", form.impact_description);
    formData.append("reproduction_steps", form.reproduction_steps);
    formData.append("vulnerability_details", form.vulnerability_details || "");

    // optional fields (only if backend supports them)
    formData.append("affected_asset", form.affected_asset || "");
    formData.append("cvss_score", form.cvss_score || "");
    formData.append("similar_cve_reference", form.similar_cve_reference || "");
    formData.append(
      "mitigation_recommendation",
      form.mitigation_recommendation || ""
    );
    formData.append(
      "private_nate_to_cyberveo",
      form.private_nate_to_cyberveo || ""
    );
    formData.append("tags_lable", form.tags_lable || "");
    formData.append("reference_link", form.reference_link || "");

    if (form.file) {
      formData.append("file", form.file);
    }

    try {
      // unwrap() throws on reject so we can catch it
      await dispatch(createReport(formData)).unwrap();
      toast.success("Report submitted successfully");

      // refresh the reports list after creation
      dispatch(fetchReports());

      // clear form
      setForm({
        program: "",
        reportTitle: "",
        vulnerabilityType: "",
        severity: "",
        impact_description: "",
        reproduction_steps: "",
        vulnerability_details: "",
        affected_asset: "",
        file: null,
        confirm: false,
      });
    } catch (err) {
      toast.error("Failed to submit report.  Please try again.");
      console.error("Error submitting report:", err);
    }
  };

  const isSubmitting = createStatus === "loading";

  const [currency, setCurrency] = useState("USD");
  const [editingIndex, setEditingIndex] = useState(null);
  const [severityData, setSeverityData] = useState([
    {
      severity: "Critical",
      icon: <FaFire className="w-4 h-4" />,
      color: "text-red-600",
      bgColor: "bg-red-50",
      borderColor: "border-red-200",
      selectedBgColor: "bg-red-100",
      selectedBorderColor: "border-red-400",
      minimum: 5000,
      maximum: 10000,
      average: 7500,
    },
    {
      severity: "High",
      icon: <FaExclamationTriangle className="w-4 h-4" />,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
      borderColor: "border-orange-200",
      selectedBgColor: "bg-orange-100",
      selectedBorderColor: "border-orange-400",
      minimum: 2000,
      maximum: 5000,
      average: 3500,
    },
    {
      severity: "Medium",
      icon: <FaShieldAlt className="w-4 h-4" />,
      color: "text-yellow-600",
      bgColor: "bg-yellow-50",
      borderColor: "border-yellow-200",
      selectedBgColor: "bg-yellow-100",
      selectedBorderColor: "border-yellow-400",
      minimum: 500,
      maximum: 2000,
      average: 1250,
    },
    {
      severity: "Low",
      icon: <FaInfoCircle className="w-4 h-4" />,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200",
      selectedBgColor: "bg-blue-100",
      selectedBorderColor: "border-blue-400",
      minimum: 100,
      maximum: 500,
      average: 300,
    },
  ]);

  const handleSeveritySelect = (severity) => {
    setForm((prev) => ({ ...prev, severity }));
  };

  const handleEditRewards = (index, field, value) => {
    const numValue = Number.parseInt(value) || 0;
    setSeverityData((prev) =>
      prev.map((item, i) =>
        i === index ? { ...item, [field]: numValue } : item
      )
    );
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const [inScopeAssets, setInScopeAssets] = useState([
    { type: "Domain/Subdomain", value: "api.cyberneoGen.com" },
    { type: "Domain/Subdomain", value: "dashboard.cyberneoGen.com" },
  ]);

  const [outOfScopeAssets, setOutOfScopeAssets] = useState([
    { type: "Domain/Subdomain", value: "staging.cyberneoGen.com" },
  ]);

  const [newInScope, setNewInScope] = useState({
    type: "Domain/Subdomain",
    value: "",
  });
  const [newOutOfScope, setNewOutOfScope] = useState({
    type: "Domain/Subdomain",
    value: "",
  });

  const assetTypes = [
    "Domain/Subdomain",
    "IP Address",
    "Mobile App",
    "API Endpoint",
    "Web Application",
  ];

  const addInScopeAsset = () => {
    if (!newInScope.value.trim()) {
      toast.error("Please enter a valid asset");
      return;
    }
    setInScopeAssets([...inScopeAssets, { ...newInScope }]);
    setNewInScope({ type: "Domain/Subdomain", value: "" });
    toast.success("In-scope asset added successfully");
  };

  const addOutOfScopeAsset = () => {
    if (!newOutOfScope.value.trim()) {
      toast.error("Please enter a valid asset");
      return;
    }
    setOutOfScopeAssets([...outOfScopeAssets, { ...newOutOfScope }]);
    setNewOutOfScope({ type: "Domain/Subdomain", value: "" });
    toast.success("Out-of-scope asset added successfully");
  };

  const removeInScopeAsset = (index) => {
    setInScopeAssets(inScopeAssets.filter((_, i) => i !== index));
    toast.success("Asset removed from in-scope");
  };

  const removeOutOfScopeAsset = (index) => {
    setOutOfScopeAssets(outOfScopeAssets.filter((_, i) => i !== index));
    toast.success("Asset removed from out-of-scope");
  };

  return (
    <div className="bg-white p-6 rounded shadow-md max-w-6xl mx-auto my-8">
      <h2 className="text-xl font-semibold mb-4">
        Submit Vulnerability Report
      </h2>
      <p className="text-sm text-gray-500 mb-6">
        Complete the form below to submit a new vulnerability report
      </p>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-gray-50 border border-gray-200 p-6 rounded-lg space-y-6">
          <div className="flex items-center gap-2">
            <FaFileAlt className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-semibold text-gray-900">
              Basic Information
            </h3>
          </div>

          {/* Program with auto-fetch indicator */}
          <div>
            <label className="block text-sm font-medium mb-2 text-gray-700">
              Program *
              <span className="text-xs text-blue-600 ml-2">
                <FaGlobe className="w-3 h-3 inline mr-1" />
                Auto-loads domains
              </span>
            </label>
            <select
              name="program"
              className="w-full bg-white border border-gray-300 rounded px-3 py-2 text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              value={form.program}
              onChange={handleChange}
              required
            >
              <option value="">Select a program</option>
              <option>SecureTech Cloud</option>
              <option>RetailShield E-commerce</option>
              <option>FinGuard Banking</option>
            </select>
          </div>

          {/* Report Title */}
          <div>
            <label className="block text-sm font-medium mb-2 text-gray-700">
              Report Title *
            </label>
            <input
              name="reportTitle"
              className="w-full bg-white border border-gray-300 rounded px-3 py-2 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Provide a clear, descriptive title for your vulnerability"
              value={form.reportTitle}
              onChange={handleChange}
              required
            />
          </div>

          {/* Vulnerability Type with comprehensive options */}
          <div>
            <label className="block text-sm font-medium mb-2 text-gray-700">
              Vulnerability Type *
              <span className="text-xs text-gray-500 ml-2">
                ({vulnerabilityTypes.length} types available)
              </span>
            </label>
            <select
              name="vulnerabilityType"
              className="w-full bg-white border border-gray-300 rounded px-3 py-2 text-gray-900 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              value={form.vulnerabilityType}
              onChange={handleChange}
              required
            >
              <option value="">Select vulnerability type</option>
              {vulnerabilityTypes.map((type) => (
                <option className="" key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2 text-gray-700">
              Affected Asset *
            </label>
            <input
              name="affected_asset"
              className="w-full bg-white border border-gray-300 rounded px-3 py-2 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="e.g., search page, login form, API endpoint"
              value={form.affected_asset || ""}
              onChange={handleChange}
              required
            />
          </div>
        </div>

        <div className="bg-gray-50 border border-gray-200 p-6 rounded-lg space-y-6">
          <div className="flex items-center gap-2">
            <FaExclamationTriangle className="w-5 h-5 text-orange-600" />
            <h3 className="text-lg font-semibold text-gray-900">
              Impact Assessment
            </h3>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2 text-gray-700">
              Impact Description *
            </label>
            <textarea
              name="impact_description"
              className="w-full bg-white border border-gray-300 rounded px-3 py-2 h-24 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Describe the potential impact of this vulnerability and how it could affect the business or users"
              value={form.impact_description}
              onChange={handleChange}
              required
            />
          </div>
        </div>

        <div className="bg-gray-50 border border-gray-200 p-6 rounded-lg space-y-6">
          <div className="flex items-center gap-2">
            <FaBug className="w-5 h-5 text-red-600" />
            <h3 className="text-lg font-semibold text-gray-900">
              Technical Details
            </h3>
          </div>

          {/* Steps to Reproduce */}
          <div>
            <label className="block text-sm font-medium mb-2 text-gray-700">
              Steps to Reproduce *
            </label>
            <textarea
              name="reproduction_steps"
              className="w-full bg-white border border-gray-300 rounded px-3 py-2 h-28 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Provide detailed step-by-step instructions to reproduce the vulnerability"
              value={form.reproduction_steps}
              onChange={handleChange}
              required
            />
          </div>

          {/* Additional Technical Details */}
          <div>
            <label className="block text-sm font-medium mb-2 text-gray-700">
              Additional Technical Details
            </label>
            <textarea
              name="vulnerability_details"
              className="w-full bg-white border border-gray-300 rounded px-3 py-2 h-20 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Any additional technical information, code snippets, or analysis"
              value={form.vulnerability_details}
              onChange={handleChange}
            />
          </div>
        </div>

        {/* Scope Definition */}
        <div className="bg-gray-50 border border-gray-200 p-6 rounded-lg space-y-8">
          <div className="flex items-center gap-2">
            <FaShieldAlt className="w-5 h-5 text-green-600" />
            <h3 className="text-lg font-semibold text-gray-900">
              Scope Definition
            </h3>
          </div>

          {/* In-scope Assets */}
          <div>
            <h4 className="text-sm font-medium text-green-700 mb-4">
              In-scope Assets*
            </h4>

            {/* Add new in-scope asset */}
            <div className="flex gap-2 mb-4">
              <select
                value={newInScope.type}
                onChange={(e) =>
                  setNewInScope({ ...newInScope, type: e.target.value })
                }
                className="bg-white border border-gray-300 rounded px-3 py-2 text-sm min-w-[160px] text-gray-900"
              >
                {assetTypes.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
              <input
                type="text"
                value={newInScope.value}
                onChange={(e) =>
                  setNewInScope({ ...newInScope, value: e.target.value })
                }
                placeholder="e.g., *.example.com"
                className="flex-1 bg-white border border-gray-300 rounded px-3 py-2 text-sm placeholder-gray-400 text-gray-900"
              />
              <button
                type="button"
                onClick={addInScopeAsset}
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded text-sm flex items-center gap-2"
              >
                <FaPlus className="w-3 h-3" />
                Add
              </button>
            </div>

            {/* In-scope assets list */}
            <div className="space-y-2">
              {inScopeAssets.map((asset, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 bg-white border border-gray-200 rounded px-3 py-2"
                >
                  <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs min-w-[120px]">
                    {asset.type}
                  </span>
                  <span className="flex-1 text-sm text-gray-900">
                    {asset.value}
                  </span>
                  <button
                    type="button"
                    onClick={() => removeInScopeAsset(index)}
                    className="text-red-500 hover:text-red-600 p-1"
                  >
                    <FaTimes className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Out-of-scope Assets */}
          <div>
            <h4 className="text-sm font-medium text-red-700 mb-4">
              Out-of-scope Assets
            </h4>

            {/* Add new out-of-scope asset */}
            <div className="flex gap-2 mb-4">
              <select
                value={newOutOfScope.type}
                onChange={(e) =>
                  setNewOutOfScope({ ...newOutOfScope, type: e.target.value })
                }
                className="bg-white border border-gray-300 rounded px-3 py-2 text-sm min-w-[160px] text-gray-900"
              >
                {assetTypes.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
              <input
                type="text"
                value={newOutOfScope.value}
                onChange={(e) =>
                  setNewOutOfScope({ ...newOutOfScope, value: e.target.value })
                }
                placeholder="e.g., test.example.com"
                className="flex-1 bg-white border border-gray-300 rounded px-3 py-2 text-sm placeholder-gray-400 text-gray-900"
              />
              <button
                type="button"
                onClick={addOutOfScopeAsset}
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded text-sm flex items-center gap-2"
              >
                <FaPlus className="w-3 h-3" />
                Add
              </button>
            </div>

            {/* Out-of-scope assets list */}
            <div className="space-y-2">
              {outOfScopeAssets.map((asset, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 bg-white border border-gray-200 rounded px-3 py-2"
                >
                  <span className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs min-w-[120px]">
                    {asset.type}
                  </span>
                  <span className="flex-1 text-sm text-gray-900">
                    {asset.value}
                  </span>
                  <button
                    type="button"
                    onClick={() => removeOutOfScopeAsset(index)}
                    className="text-red-500 hover:text-red-600 p-1"
                  >
                    <FaTimes className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-gray-50 border border-gray-200 p-6 rounded-lg">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <FaShieldAlt className="w-5 h-5 text-green-600" />
              <h3 className="text-lg font-semibold text-gray-900">
                Severity Calculator & Rewards
              </h3>
              <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                Optional
              </span>
            </div>
            <button
              type="button"
              onClick={() => setShowSeverityCalculator(!showSeverityCalculator)}
              className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-700"
            >
              {showSeverityCalculator ? (
                <>
                  <FaToggleOn className="w-5 h-5" />
                  Hide Calculator
                </>
              ) : (
                <>
                  <FaToggleOff className="w-5 h-5" />
                  Show Calculator
                </>
              )}
            </button>
          </div>

          {showSeverityCalculator && (
            <>
              <div className="flex items-center justify-between mb-4">
                <div className="text-sm text-gray-600">
                  Select a severity level and customize reward amounts. Click on
                  severity badges to select them.
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-gray-600">Currency:</span>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="bg-white border border-gray-300 rounded px-2 py-1 text-sm text-gray-900"
                  >
                    <option value="USD">USD ($)</option>
                    <option value="EUR">EUR (€)</option>
                    <option value="GBP">GBP (£)</option>
                  </select>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full bg-white border border-gray-200 rounded-lg">
                  <thead>
                    <tr className="border-b border-gray-200 bg-gray-50">
                      <th className="text-left py-3 px-4 font-medium text-gray-700">
                        Severity
                      </th>
                      <th className="text-left py-3 px-4 font-medium text-gray-700">
                        Minimum
                      </th>
                      <th className="text-left py-3 px-4 font-medium text-gray-700">
                        Maximum
                      </th>
                      <th className="text-left py-3 px-4 font-medium text-gray-700">
                        Average
                      </th>
                      <th className="text-left py-3 px-4 font-medium text-gray-700">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {severityData.map((item, index) => {
                      const isSelected = form.severity === item.severity;
                      const isEditing = editingIndex === index;

                      return (
                        <tr
                          key={index}
                          className={`border-b border-gray-100 hover:bg-gray-50 ${
                            isSelected ? "bg-blue-50" : ""
                          }`}
                        >
                          <td className="py-4 px-4">
                            <div
                              onClick={() =>
                                handleSeveritySelect(item.severity)
                              }
                              className={`flex items-center gap-3 ${
                                isSelected
                                  ? item.selectedBgColor +
                                    " " +
                                    item.selectedBorderColor
                                  : item.bgColor + " " + item.borderColor
                              } border rounded-lg px-3 py-2 w-fit cursor-pointer hover:shadow-sm transition-all ${
                                isSelected ? "ring-2 ring-blue-300" : ""
                              }`}
                            >
                              <span className={item.color}>{item.icon}</span>
                              <span className="font-medium text-gray-900">
                                {item.severity}
                              </span>
                              {isSelected && (
                                <FaCheck className="w-3 h-3 text-green-600" />
                              )}
                            </div>
                          </td>
                          <td className="py-4 px-4">
                            {isEditing ? (
                              <input
                                type="number"
                                value={item.minimum}
                                onChange={(e) =>
                                  handleEditRewards(
                                    index,
                                    "minimum",
                                    e.target.value
                                  )
                                }
                                className="w-20 border border-gray-300 rounded px-2 py-1 text-sm"
                              />
                            ) : (
                              <span className="text-gray-700">
                                {formatCurrency(item.minimum)}
                              </span>
                            )}
                          </td>
                          <td className="py-4 px-4">
                            {isEditing ? (
                              <input
                                type="number"
                                value={item.maximum}
                                onChange={(e) =>
                                  handleEditRewards(
                                    index,
                                    "maximum",
                                    e.target.value
                                  )
                                }
                                className="w-20 border border-gray-300 rounded px-2 py-1 text-sm"
                              />
                            ) : (
                              <span className="text-gray-700">
                                {formatCurrency(item.maximum)}
                              </span>
                            )}
                          </td>
                          <td className="py-4 px-4">
                            {isEditing ? (
                              <input
                                type="number"
                                value={item.average}
                                onChange={(e) =>
                                  handleEditRewards(
                                    index,
                                    "average",
                                    e.target.value
                                  )
                                }
                                className="w-20 border border-gray-300 rounded px-2 py-1 text-sm"
                              />
                            ) : (
                              <span className="text-gray-600 text-sm">
                                {formatCurrency(item.average)}
                              </span>
                            )}
                          </td>
                          <td className="py-4 px-4">
                            <button
                              type="button"
                              onClick={() =>
                                setEditingIndex(isEditing ? null : index)
                              }
                              className={`flex items-center gap-1 px-2 py-1 rounded text-xs ${
                                isEditing
                                  ? "bg-green-100 text-green-700 hover:bg-green-200"
                                  : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                              }`}
                            >
                              {isEditing ? (
                                <>
                                  <FaCheck className="w-3 h-3" />
                                  Save
                                </>
                              ) : (
                                <>
                                  <FaEdit className="w-3 h-3" />
                                  Edit
                                </>
                              )}
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {form.severity && (
                <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>Selected Severity:</strong> {form.severity} - This
                    will be used for your vulnerability report.
                  </p>
                </div>
              )}
            </>
          )}

          {!showSeverityCalculator && (
            <div className="text-center py-8 text-gray-500">
              <FaShieldAlt className="w-8 h-8 mx-auto mb-2 text-gray-400" />
              <p className="text-sm">
                Severity calculator is hidden. Click "Show Calculator" to use
                it.
              </p>
            </div>
          )}
        </div>

        <div className="bg-gray-50 border border-gray-200 p-6 rounded-lg">
          <div className="flex items-center gap-2 mb-4">
            <FaUpload className="w-5 h-5 text-purple-600" />
            <h3 className="text-lg font-semibold text-gray-900">Attachments</h3>
          </div>

          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 flex flex-col items-center gap-2 text-center bg-white">
            <UploadCloud className="w-8 h-8 text-blue-500" />
            <input
              type="file"
              name="file"
              onChange={handleChange}
              className="hidden"
              id="fileUpload"
            />
            <label
              htmlFor="fileUpload"
              className="cursor-pointer bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded text-sm transition-colors"
            >
              Browse File
            </label>
            <p className="text-xs text-gray-500">
              Max file size: 20MB. Supported formats: PNG, JPG, PDF, ZIP
            </p>
            {form.file && (
              <p className="text-xs text-gray-700 mt-2 font-medium">
                {form.file.name}
              </p>
            )}
          </div>
        </div>

        <div className="bg-gray-50 border border-gray-200 p-6 rounded-lg">
          <div className="flex items-center gap-2 mb-4">
            <FaClipboardList className="w-5 h-5 text-green-600" />
            <h3 className="text-lg font-semibold text-gray-900">
              Confirmation
            </h3>
          </div>

          <label className="flex items-center gap-3 text-sm bg-white border border-gray-200 rounded-lg p-4">
            <input
              type="checkbox"
              name="confirm"
              checked={form.confirm}
              onChange={handleChange}
              required
              className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
            />
            <span className="text-gray-700">
              I confirm this report complies with the program's disclosure
              policy
            </span>
          </label>
        </div>

        <div className="bg-gray-50 border border-gray-200 p-6 rounded-lg">
          <div className="flex flex-wrap gap-4">
            <button
              type="button"
              className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-6 py-2 rounded-lg transition-colors"
            >
              Save Draft
            </button>
            <button
              type="button"
              className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-6 py-2 rounded-lg transition-colors"
            >
              Preview
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className={`ml-auto px-6 py-2 rounded-lg transition-colors ${
                isSubmitting
                  ? "bg-gray-400 text-gray-200 cursor-not-allowed"
                  : "bg-blue-600 hover:bg-blue-700 text-white"
              }`}
            >
              {isSubmitting ? "Submitting..." : "Submit Report"}
            </button>
          </div>

          {createError && (
            <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-700 text-sm">{createError}</p>
            </div>
          )}
        </div>
      </form>

      <div className="mt-6 bg-blue-50 border border-blue-200 p-6 rounded-lg">
        <div className="flex items-center gap-2 mb-4">
          <FaLightbulb className="w-5 h-5 text-blue-600" />
          <h3 className="text-lg font-semibold text-blue-900">
            Submission Tips
          </h3>
        </div>
        <ul className="list-disc list-inside space-y-2 text-sm text-blue-800">
          <li>
            Include clear reproduction steps with specific URLs and parameters
          </li>
          <li>
            Attach screenshots or screen recordings to demonstrate the
            vulnerability
          </li>
          <li>
            Explain the potential business impact or threat from the issue
          </li>
          <li>Provide suggestions for remediation if possible</li>
        </ul>
      </div>
    </div>
  );
}
