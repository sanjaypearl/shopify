import LoginForm from "@/components/AuthComponents/Login-form";
import React from "react";

const page = () => {
  return (
    <div>
      <LoginForm />
    </div>
  );
};

export default page;
