import SignupForm from "@/components/AuthComponents/Signup-form";

const page = () => {
  return (
    <div>
      <SignupForm />
    </div>
  );
};

export default page;
