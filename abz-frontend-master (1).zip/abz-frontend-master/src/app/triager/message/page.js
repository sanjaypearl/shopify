import React from "react";
import ChatPage from "@/components/TriagerComponents/ChatPage";

function page() {
  return (
    <>
      <ChatPage />
    </>
  );
}

export default page;
