import ResearcherFeedback from "@/components/TriagerComponents/ResearcherFeedback";
import React from "react";

const page = () => {
  return (
    <div>
      <ResearcherFeedback />
    </div>
  );
};

export default page;
