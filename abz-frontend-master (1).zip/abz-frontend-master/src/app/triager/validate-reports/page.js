import ValidatedReports from "@/components/TriagerComponents/ValidatedReports";
import React from "react";

const page = () => {
  return (
    <div>
      <ValidatedReports />
    </div>
  );
};

export default page;
