import Reports from "@/components/Company/Report/Reports";
import React from "react";

const page = () => {
  return (
    <div>
      <Reports />
    </div>
  );
};

export default page;
