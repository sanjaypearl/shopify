import React from "react";
import ChatList from "@/components/Company/Message/ChatList";

const page = () => {
  return (
    <>
      <ChatList />
    </>
  );
};

export default page;
