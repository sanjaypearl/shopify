import ListAssets from "@/components/Company/Assets/ListAssets";

// app/page.js
export default function HomePage() {
  return (
    <div>
      {" "}
      <ListAssets />
    </div>
  );
}
