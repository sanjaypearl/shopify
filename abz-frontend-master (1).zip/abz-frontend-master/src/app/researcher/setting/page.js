import ResearcherAccountSettings from "@/components/Researcher/ResearcherAccountSettings";
import React from "react";

const page = () => {
  return (
    <div>
      <ResearcherAccountSettings />
    </div>
  );
};

export default page;
