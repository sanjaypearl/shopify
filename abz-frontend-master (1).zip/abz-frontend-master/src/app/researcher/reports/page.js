import ResearcherReports from "@/components/Researcher/ResearcherReports";
import React from "react";

const page = () => {
  return (
    <div>
      <ResearcherReports />
    </div>
  );
};

export default page;
