"use client";
import { usePathname } from "next/navigation";
import Header from "@/components/AdminComponents/Header";
import Sidebar from "@/components/AdminComponents/Sidebar";
import useRouteProtect from "@/hooks/useRouteProtect";
import { useState } from "react";

import {
  FaChartBar,
  FaFileAlt,
  FaUsersCog,
  FaTasks,
  FaDollarSign,
  FaUsers,
  FaEnvelope,
  FaTrophy,
  FaPaperPlane
} from "react-icons/fa";

const adminMenuItems = [
  { name: "Dashboard", icon: <FaChartBar />, path: "/researcher" },
  { name: "Programs", icon: <FaTasks />, path: "/researcher/programs" },
  { name: "My Reports", icon: <FaFileAlt />, path: "/researcher/reports" },
  { name: "Submissions", icon: <FaPaperPlane />, path: "/researcher/submissions" },
  { name: "Earnings", icon: <FaDollarSign />, path: "/researcher/earnings" },
  { name: "Leaderboard", icon: <FaTrophy />, path: "/researcher/leaderboard" },
  { name: "Messages ", icon: <FaEnvelope />, path: "/researcher/messages" },
  {
    name: "Researcher Setting",
    icon: <FaUsersCog />,
    path: "/researcher/setting",
  },
  { name: "Profile", icon: <FaUsers />, path: "/researcher/profile" },
];

export default function AdminLayout({ children }) {
  const pathname = usePathname();
  const [menuItems] = useState(adminMenuItems);
  const { isAuthorized, isLoading } = useRouteProtect(["researcher"]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-900" />
      </div>
    );
  }

  if (!isAuthorized) return null;

  // Skip sidebar & header for onboarding
  if (pathname === "/researcher/onboarding") {
    return <main className="p-6 w-full">{children}</main>;
  }

  return (
    <div className="flex">
      <Sidebar menuItems={menuItems} />
      <div className="flex-1 flex flex-col h-screen overflow-y-auto">
        <Header />
        <main className="p-6">{children}</main>
      </div>
    </div>
  );
}
