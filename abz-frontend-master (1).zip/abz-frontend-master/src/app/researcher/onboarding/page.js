import OnboardingPage from "@/components/Researcher/ResearcherOnboarding";
import React from "react";

const page = () => {
  return (
    <div>
      <OnboardingPage />
    </div>
  );
};

export default page;
