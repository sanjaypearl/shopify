import ResearcherProfile from "@/components/Researcher/ResearcherProfile";
import React from "react";

const page = () => {
  return (
    <div>
      <ResearcherProfile />
    </div>
  );
};

export default page;
