import ResearcherSubmitReportForm from "@/components/Researcher/ResearcherSubmitReportForm";
import React from "react";

const page = () => {
  return (
    <div>
      <ResearcherSubmitReportForm />
    </div>
  );
};

export default page;
