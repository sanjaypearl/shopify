import ResearcherMessages from "@/components/Researcher/ResearcherMessages";
import React from "react";

const page = () => {
  return (
    <ResearcherMessages/>
  )
};

export default page;
