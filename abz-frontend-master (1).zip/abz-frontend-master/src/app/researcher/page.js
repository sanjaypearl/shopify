import ResearcherDashboard from "@/components/Researcher/ResearcherDashboard"

const page = () => {
  return (
    <div>
        <ResearcherDashboard />
    </div>
  )
}

export default page