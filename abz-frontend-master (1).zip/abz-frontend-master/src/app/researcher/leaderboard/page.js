import ResearcherLeaderboard from "@/components/Researcher/ResearcherLeaderboard";
import React from "react";

const page = () => {
  return (
    <div>
      <ResearcherLeaderboard />
    </div>
  );
};

export default page;
