import ManageProgram from "@/components/AdminComponents/Programs/ManageProgram";
import React from "react";

const page = () => {
  return (
    <div>
      <ManageProgram />
    </div>
  );
};

export default page;
