import ManageSettings from "@/components/AdminComponents/Settings/ManageSettings";

const page = () => {
  return (
    <div>
      <ManageSettings />
    </div>
  );
};

export default page;
