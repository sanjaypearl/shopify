import Analytics from "@/components/AdminComponents/Analytics/Analytics";

const page = () => {
  return (
    <div>
      <Analytics />
    </div>
  );
};

export default page;
