import Messages from "@/components/AdminComponents/Message/Messages";
import React from "react";

const page = () => {
  return (
    <div>
      <Messages />
    </div>
  );
};

export default page;
