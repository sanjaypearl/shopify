import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

export const fetchResearchers = createAsyncThunk(
  "researcher/fetchResearchers",
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(
        `${process.env.NEXT_PUBLIC_API_URL}/researchers`
      );
      return response.data;
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to fetch researchers"
      );
    }
  }
);
