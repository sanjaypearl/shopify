// src/store/actions/reportAction.js
import { createAsyncThunk } from "@reduxjs/toolkit";
import DataService from "@/services/Axios/axiosInterceptor";

// fetch existing reports
export const fetchReports = createAsyncThunk(
  "report/getReports",
  async (_, { rejectWithValue }) => {
    try {
      const res = await DataService.getAllReports();
      // API shape: { success: true, total: X, data: [...] }
      return res.data?.data || res.data || [];
    } catch (err) {
      return rejectWithValue(
        err.response?.data?.message || err.message || "Failed to fetch reports"
      );
    }
  }
);

// create new report (multipart/form-data)
export const createReport = createAsyncThunk(
  "report/createReport",
  async (formData, { rejectWithValue }) => {
    try {
      // DataService.createReport uses axios instance with baseURL -> http://localhost:4000
      const res = await DataService.createReport(formData);
      // return created report or whole response, adjust if your backend returns wrapper
      return res.data || res;
    } catch (err) {
      return rejectWithValue(
        err.response?.data?.message || err.message || "Failed to submit report"
      );
    }
  }
);
